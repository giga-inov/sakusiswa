import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

type SetupBody = {
  school: Record<string, string>;
  admin: { nama: string; email: string; password: string };
  logo?: { dataUrl: string; contentType: string };
};

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Metode tidak didukung." }, 405);

  const adminClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { autoRefreshToken: false, persistSession: false } },
  );
  const claimToken = crypto.randomUUID() + crypto.randomUUID();
  let userId: string | null = null;

  try {
    const body = await req.json() as SetupBody;
    const school = body.school;
    const admin = body.admin;
    if (!school || !admin || !admin.nama || !admin.email || !admin.password || admin.password.length < 6) {
      return json({ error: "Data setup belum lengkap." }, 400);
    }
    if (admin.nama.trim().length > 200 || admin.email.trim().length > 254 || admin.password.length > 128) {
      return json({ error: "Data setup tidak valid." }, 400);
    }
    if (body.logo && (!body.logo.dataUrl.startsWith("data:image/") || !["image/png", "image/jpeg"].includes(body.logo.contentType))) {
      return json({ error: "Format logo tidak didukung." }, 400);
    }

    const { error: claimError } = await adminClient.rpc("claim_initial_setup", {
      p_claim_token: claimToken,
      p_school: school,
    });
    if (claimError) return json({ error: "Setup sudah digunakan atau belum tersedia." }, 409);

    const { data: authData, error: authError } = await adminClient.auth.admin.createUser({
      email: admin.email.trim().toLowerCase(),
      password: admin.password,
      email_confirm: true,
      user_metadata: { nama: admin.nama.trim() },
    });
    if (authError || !authData.user) throw new Error("Unable to create administrator");
    userId = authData.user.id;

    if (body.logo) {
      const base64 = body.logo.dataUrl.split(",")[1];
      const bytes = Uint8Array.from(atob(base64), (char) => char.charCodeAt(0));
      if (bytes.byteLength > 2 * 1024 * 1024) throw new Error("Logo terlalu besar");
      const { error: logoError } = await adminClient.storage.from("logo-sekolah").upload("logo.png", bytes, {
        contentType: body.logo.contentType,
        upsert: true,
      });
      if (logoError) throw new Error("Unable to save logo");
    }

    const { error: finalizeError } = await adminClient.rpc("finalize_initial_setup", {
      p_claim_token: claimToken,
      p_admin_id: userId,
      p_nama: admin.nama,
      p_email: admin.email,
    });
    if (finalizeError) throw new Error("Unable to finalize setup");

    return json({ success: true, emailConfirmationRequired: false });
  } catch (error) {
    console.error("initial setup failed", error);
    if (userId) await adminClient.auth.admin.deleteUser(userId);
    await adminClient.rpc("release_initial_setup", { p_claim_token: claimToken });
    return json({ error: "Setup belum dapat diselesaikan. Silakan coba lagi." }, 400);
  }
});
