/*
# Audit Trail: INPUT/HAPUS log types, preserve edit logs on delete

## Changes
1. Add `change_type` column to transaksi_edit_log: 'INPUT', 'EDIT', 'HAPUS'
2. Add `delete_reason` column for HAPUS entries
3. Change FK from ON DELETE CASCADE to ON DELETE SET NULL so edit logs survive deletion
4. Add snapshot columns: siswa_nama, siswa_nisn, nominal_before, nominal_after, jenis, tanggal_trx
   so the HAPUS log retains context even after the transaction row is gone
*/

-- Add change_type column
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'change_type') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN change_type text NOT NULL DEFAULT 'EDIT';
  END IF;
END $$;

-- Add delete_reason column
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'delete_reason') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN delete_reason text;
  END IF;
END $$;

-- Add snapshot columns for context after transaction is deleted
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'siswa_nama') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN siswa_nama text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'siswa_nisn') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN siswa_nisn text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'nominal_before') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN nominal_before text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'nominal_after') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN nominal_after text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'jenis_trx') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN jenis_trx text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi_edit_log' AND column_name = 'tanggal_trx') THEN
    ALTER TABLE transaksi_edit_log ADD COLUMN tanggal_trx text;
  END IF;
END $$;

-- Change FK from CASCADE to SET NULL so edit logs survive transaction deletion
ALTER TABLE transaksi_edit_log DROP CONSTRAINT IF EXISTS transaksi_edit_log_transaksi_id_fkey;
ALTER TABLE transaksi_edit_log ALTER COLUMN transaksi_id DROP NOT NULL;
ALTER TABLE transaksi_edit_log ADD CONSTRAINT transaksi_edit_log_transaksi_id_fkey
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE SET NULL;

-- Index for change_type filtering
CREATE INDEX IF NOT EXISTS idx_transaksi_edit_log_change_type ON transaksi_edit_log(change_type);
