-- Grant execute on recompute_saldo_setelah to authenticated users
GRANT EXECUTE ON FUNCTION public.recompute_saldo_setelah(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.recompute_all_saldo(uuid) TO authenticated;
