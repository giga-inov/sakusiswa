/*
# TABURI - Tabungan Siswa Banyurip: Full Schema

## Overview
Creates the complete database schema for TABURI, a student savings management
system for SD Negeri Banyurip. Three roles (admin, guru, siswa) via Supabase Auth.

## Tables
1. profiles — links to auth.users, role + display name
2. kelas — 6 classes
3. tahun_pelajaran — academic years, one active
4. guru — teachers
5. siswa — students
6. alumni — graduated students
7. transaksi — setoran/penarikan/koreksi
8. aktivitas — audit log
9. pengaturan — app settings

## Security (RLS) — admin full CRUD, guru/siswa scoped reads
## Triggers — auto profile on signup, auto saldo update on transaksi
## Seed — 1 admin, 6 kelas, 1 active tahun, default pengaturan
*/

-- ============================================================
-- PROFILES
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  nama text NOT NULL,
  role text NOT NULL DEFAULT 'siswa' CHECK (role IN ('admin','guru','siswa')),
  must_change_password boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own_or_admin" ON profiles;
CREATE POLICY "profiles_select_own_or_admin" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_admin_insert" ON profiles;
CREATE POLICY "profiles_admin_insert" ON profiles FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "profiles_admin_delete" ON profiles;
CREATE POLICY "profiles_admin_delete" ON profiles FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- KELAS (no FK to guru yet; added after guru exists)
-- ============================================================
CREATE TABLE IF NOT EXISTS kelas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama text NOT NULL UNIQUE,
  tingkat int NOT NULL UNIQUE CHECK (tingkat BETWEEN 1 AND 6),
  wali_kelas_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE kelas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "kelas_select_all" ON kelas;
CREATE POLICY "kelas_select_all" ON kelas FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "kelas_admin_insert" ON kelas;
CREATE POLICY "kelas_admin_insert" ON kelas FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "kelas_admin_update" ON kelas;
CREATE POLICY "kelas_admin_update" ON kelas FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "kelas_admin_delete" ON kelas;
CREATE POLICY "kelas_admin_delete" ON kelas FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- TAHUN PELAJARAN
-- ============================================================
CREATE TABLE IF NOT EXISTS tahun_pelajaran (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama text NOT NULL UNIQUE,
  aktif boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE tahun_pelajaran ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tp_select_all" ON tahun_pelajaran;
CREATE POLICY "tp_select_all" ON tahun_pelajaran FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "tp_admin_insert" ON tahun_pelajaran;
CREATE POLICY "tp_admin_insert" ON tahun_pelajaran FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "tp_admin_update" ON tahun_pelajaran;
CREATE POLICY "tp_admin_update" ON tahun_pelajaran FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "tp_admin_delete" ON tahun_pelajaran;
CREATE POLICY "tp_admin_delete" ON tahun_pelajaran FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- GURU
-- ============================================================
CREATE TABLE IF NOT EXISTS guru (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama text NOT NULL,
  nip text UNIQUE,
  email text UNIQUE,
  kelas_id uuid REFERENCES kelas(id) ON DELETE SET NULL,
  alamat text,
  no_hp text,
  status text NOT NULL DEFAULT 'aktif' CHECK (status IN ('aktif','nonaktif')),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE guru ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "guru_select_all" ON guru;
CREATE POLICY "guru_select_all" ON guru FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "guru_admin_insert" ON guru;
CREATE POLICY "guru_admin_insert" ON guru FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "guru_admin_update" ON guru;
CREATE POLICY "guru_admin_update" ON guru FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "guru_admin_delete" ON guru;
CREATE POLICY "guru_admin_delete" ON guru FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- Now add FK from kelas.wali_kelas_id to guru
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name = 'kelas_wali_kelas_id_fkey') THEN
    ALTER TABLE kelas ADD CONSTRAINT kelas_wali_kelas_id_fkey FOREIGN KEY (wali_kelas_id) REFERENCES guru(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ============================================================
-- SISWA
-- ============================================================
CREATE TABLE IF NOT EXISTS siswa (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  foto text,
  nis text NOT NULL UNIQUE,
  nisn text UNIQUE,
  nama text NOT NULL,
  jenis_kelamin text NOT NULL CHECK (jenis_kelamin IN ('L','P')),
  tanggal_lahir date,
  alamat text,
  nama_orang_tua text,
  no_hp_orang_tua text,
  kelas_id uuid NOT NULL REFERENCES kelas(id) ON DELETE RESTRICT,
  tahun_pelajaran_id uuid NOT NULL REFERENCES tahun_pelajaran(id) ON DELETE RESTRICT,
  saldo numeric(14,2) NOT NULL DEFAULT 0 CHECK (saldo >= 0),
  status text NOT NULL DEFAULT 'aktif' CHECK (status IN ('aktif','nonaktif')),
  qr_code text,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  must_change_password boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE siswa ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_siswa_kelas ON siswa(kelas_id);
CREATE INDEX IF NOT EXISTS idx_siswa_tahun ON siswa(tahun_pelajaran_id);
CREATE INDEX IF NOT EXISTS idx_siswa_user ON siswa(user_id);

DROP POLICY IF EXISTS "siswa_select_scoped" ON siswa;
CREATE POLICY "siswa_select_scoped" ON siswa FOR SELECT
  TO authenticated USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'guru')
  );

DROP POLICY IF EXISTS "siswa_admin_insert" ON siswa;
CREATE POLICY "siswa_admin_insert" ON siswa FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "siswa_admin_or_own_update" ON siswa;
CREATE POLICY "siswa_admin_or_own_update" ON siswa FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (user_id = auth.uid() OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "siswa_admin_delete" ON siswa;
CREATE POLICY "siswa_admin_delete" ON siswa FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- ALUMNI
-- ============================================================
CREATE TABLE IF NOT EXISTS alumni (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  foto text,
  nis text NOT NULL,
  nisn text,
  nama text NOT NULL,
  jenis_kelamin text NOT NULL CHECK (jenis_kelamin IN ('L','P')),
  tanggal_lahir date,
  alamat text,
  nama_orang_tua text,
  no_hp_orang_tua text,
  kelas_asal text,
  tahun_pelajaran_nama text,
  saldo numeric(14,2) NOT NULL DEFAULT 0,
  alumni_tahun text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE alumni ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "alumni_select_all" ON alumni;
CREATE POLICY "alumni_select_all" ON alumni FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "alumni_admin_insert" ON alumni;
CREATE POLICY "alumni_admin_insert" ON alumni FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "alumni_admin_update" ON alumni;
CREATE POLICY "alumni_admin_update" ON alumni FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "alumni_admin_delete" ON alumni;
CREATE POLICY "alumni_admin_delete" ON alumni FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- TRANSAKSI
-- ============================================================
CREATE TABLE IF NOT EXISTS transaksi (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tanggal date NOT NULL DEFAULT CURRENT_DATE,
  siswa_id uuid NOT NULL REFERENCES siswa(id) ON DELETE RESTRICT,
  jenis text NOT NULL CHECK (jenis IN ('setoran','penarikan','koreksi')),
  nominal numeric(14,2) NOT NULL CHECK (nominal > 0),
  saldo_setelah numeric(14,2),
  petugas_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  petugas_nama text,
  keterangan text,
  bukti text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE transaksi ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_transaksi_siswa ON transaksi(siswa_id);
CREATE INDEX IF NOT EXISTS idx_transaksi_tanggal ON transaksi(tanggal);
CREATE INDEX IF NOT EXISTS idx_transaksi_jenis ON transaksi(jenis);

DROP POLICY IF EXISTS "transaksi_select_all" ON transaksi;
CREATE POLICY "transaksi_select_all" ON transaksi FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM siswa s WHERE s.id = transaksi.siswa_id AND s.user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin','guru'))
  );

DROP POLICY IF EXISTS "transaksi_admin_guru_insert" ON transaksi;
CREATE POLICY "transaksi_admin_guru_insert" ON transaksi FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin','guru')));

DROP POLICY IF EXISTS "transaksi_admin_update" ON transaksi;
CREATE POLICY "transaksi_admin_update" ON transaksi FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "transaksi_admin_delete" ON transaksi;
CREATE POLICY "transaksi_admin_delete" ON transaksi FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- AKTIVITAS
-- ============================================================
CREATE TABLE IF NOT EXISTS aktivitas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  aksi text NOT NULL,
  modul text,
  detail text,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  nama_user text,
  role text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE aktivitas ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_aktivitas_created ON aktivitas(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_aktivitas_user ON aktivitas(user_id);

DROP POLICY IF EXISTS "aktivitas_select_all" ON aktivitas;
CREATE POLICY "aktivitas_select_all" ON aktivitas FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "aktivitas_insert_all" ON aktivitas;
CREATE POLICY "aktivitas_insert_all" ON aktivitas FOR INSERT
  TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "aktivitas_admin_delete" ON aktivitas;
CREATE POLICY "aktivitas_admin_delete" ON aktivitas FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- PENGATURAN
-- ============================================================
CREATE TABLE IF NOT EXISTS pengaturan (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  logo_url text,
  nama_sekolah text NOT NULL DEFAULT 'SD Negeri Banyurip',
  alamat text NOT NULL DEFAULT 'Kecamatan Andong, Kabupaten Boyolali',
  no_telepon text,
  nama_kepala_sekolah text,
  nama_bendahara text,
  tahun_aktif_id uuid REFERENCES tahun_pelajaran(id) ON DELETE SET NULL,
  slogan text NOT NULL DEFAULT 'Menabung Ceria, Meraih Cita-cita.',
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE pengaturan ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "pengaturan_select_all" ON pengaturan;
CREATE POLICY "pengaturan_select_all" ON pengaturan FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "pengaturan_admin_update" ON pengaturan;
CREATE POLICY "pengaturan_admin_update" ON pengaturan FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- FUNCTION: handle_new_user
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, email, nama, role)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'nama', NEW.email), COALESCE(NEW.raw_user_meta_data->>'role', 'siswa'));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- FUNCTION: update_saldo_after_transaksi
-- ============================================================
CREATE OR REPLACE FUNCTION update_saldo_after_transaksi()
RETURNS trigger AS $$
DECLARE
  new_saldo numeric(14,2);
  current_saldo numeric(14,2);
BEGIN
  SELECT saldo INTO current_saldo FROM siswa WHERE id = NEW.siswa_id FOR UPDATE;
  IF NEW.jenis = 'setoran' THEN
    new_saldo := current_saldo + NEW.nominal;
  ELSIF NEW.jenis = 'penarikan' THEN
    new_saldo := current_saldo - NEW.nominal;
    IF new_saldo < 0 THEN
      RAISE EXCEPTION 'Saldo tidak mencukupi untuk penarikan';
    END IF;
  ELSIF NEW.jenis = 'koreksi' THEN
    new_saldo := NEW.nominal;
  END IF;
  UPDATE siswa SET saldo = new_saldo WHERE id = NEW.siswa_id;
  NEW.saldo_setelah := new_saldo;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_transaksi_saldo ON transaksi;
CREATE TRIGGER trg_transaksi_saldo
  BEFORE INSERT OR UPDATE OF nominal, jenis, siswa_id ON transaksi
  FOR EACH ROW EXECUTE FUNCTION update_saldo_after_transaksi();

-- ============================================================
-- FUNCTION: recompute_saldo_on_delete
-- ============================================================
CREATE OR REPLACE FUNCTION recompute_saldo_on_delete()
RETURNS trigger AS $$
DECLARE
  new_saldo numeric(14,2);
  koreksi_saldo numeric(14,2);
BEGIN
  SELECT COALESCE(SUM(CASE WHEN jenis = 'setoran' THEN nominal WHEN jenis = 'penarikan' THEN -nominal ELSE 0 END), 0)
  INTO new_saldo FROM transaksi WHERE siswa_id = OLD.siswa_id;
  SELECT saldo_setelah INTO koreksi_saldo FROM transaksi
  WHERE siswa_id = OLD.siswa_id AND jenis = 'koreksi'
  ORDER BY created_at DESC LIMIT 1;
  IF koreksi_saldo IS NOT NULL THEN
    new_saldo := koreksi_saldo + COALESCE((
      SELECT SUM(CASE WHEN jenis = 'setoran' THEN nominal WHEN jenis = 'penarikan' THEN -nominal ELSE 0 END)
      FROM transaksi WHERE siswa_id = OLD.siswa_id AND created_at > (SELECT created_at FROM transaksi WHERE siswa_id = OLD.siswa_id AND jenis = 'koreksi' ORDER BY created_at DESC LIMIT 1)
    ), 0);
  END IF;
  UPDATE siswa SET saldo = GREATEST(new_saldo, 0) WHERE id = OLD.siswa_id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_transaksi_delete_saldo ON transaksi;
CREATE TRIGGER trg_transaksi_delete_saldo
  AFTER DELETE ON transaksi
  FOR EACH ROW EXECUTE FUNCTION recompute_saldo_on_delete();

-- ============================================================
-- FUNCTION: log_aktivitas
-- ============================================================
CREATE OR REPLACE FUNCTION log_aktivitas(p_aksi text, p_modul text, p_detail text)
RETURNS void AS $$
DECLARE
  v_nama text;
  v_role text;
BEGIN
  SELECT nama, role INTO v_nama, v_role FROM profiles WHERE id = auth.uid();
  INSERT INTO aktivitas (aksi, modul, detail, user_id, nama_user, role)
  VALUES (p_aksi, p_modul, p_detail, auth.uid(), v_nama, v_role);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- FUNCTION: naik_kelas
-- ============================================================
CREATE OR REPLACE FUNCTION naik_kelas(p_tahun_baru uuid)
RETURNS void AS $$
DECLARE
  s RECORD;
  k_target uuid;
  tp_nama text;
BEGIN
  FOR s IN SELECT siswa.* FROM siswa JOIN kelas k ON k.id = siswa.kelas_id WHERE k.tingkat = 6 LOOP
    SELECT nama INTO tp_nama FROM tahun_pelajaran WHERE id = s.tahun_pelajaran_id;
    INSERT INTO alumni (foto, nis, nisn, nama, jenis_kelamin, tanggal_lahir, alamat, nama_orang_tua, no_hp_orang_tua, kelas_asal, tahun_pelajaran_nama, saldo, alumni_tahun)
    SELECT s.foto, s.nis, s.nisn, s.nama, s.jenis_kelamin, s.tanggal_lahir, s.alamat, s.nama_orang_tua, s.no_hp_orang_tua,
           k.nama, tp_nama, s.saldo, (SELECT nama FROM tahun_pelajaran WHERE id = p_tahun_baru)
    FROM kelas k WHERE k.id = s.kelas_id;
    DELETE FROM siswa WHERE id = s.id;
  END LOOP;
  FOR k_target IN SELECT id FROM kelas WHERE tingkat IN (2,3,4,5,6) ORDER BY tingkat DESC LOOP
    NULL;
  END LOOP;
  -- kelas 5->6, 4->5, ... 1->2
  UPDATE siswa SET kelas_id = (SELECT id FROM kelas WHERE tingkat = 6), tahun_pelajaran_id = p_tahun_baru WHERE kelas_id IN (SELECT id FROM kelas WHERE tingkat = 5);
  UPDATE siswa SET kelas_id = (SELECT id FROM kelas WHERE tingkat = 5), tahun_pelajaran_id = p_tahun_baru WHERE kelas_id IN (SELECT id FROM kelas WHERE tingkat = 4);
  UPDATE siswa SET kelas_id = (SELECT id FROM kelas WHERE tingkat = 4), tahun_pelajaran_id = p_tahun_baru WHERE kelas_id IN (SELECT id FROM kelas WHERE tingkat = 3);
  UPDATE siswa SET kelas_id = (SELECT id FROM kelas WHERE tingkat = 3), tahun_pelajaran_id = p_tahun_baru WHERE kelas_id IN (SELECT id FROM kelas WHERE tingkat = 2);
  UPDATE siswa SET kelas_id = (SELECT id FROM kelas WHERE tingkat = 2), tahun_pelajaran_id = p_tahun_baru WHERE kelas_id IN (SELECT id FROM kelas WHERE tingkat = 1);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- SEED DATA
-- ============================================================
INSERT INTO kelas (nama, tingkat) VALUES
  ('Kelas 1', 1), ('Kelas 2', 2), ('Kelas 3', 3),
  ('Kelas 4', 4), ('Kelas 5', 5), ('Kelas 6', 6)
ON CONFLICT (nama) DO NOTHING;

INSERT INTO tahun_pelajaran (nama, aktif) VALUES
  ('2025/2026', true)
ON CONFLICT (nama) DO NOTHING;

INSERT INTO pengaturan (id, nama_sekolah, alamat, slogan, nama_kepala_sekolah, nama_bendahara)
VALUES (1, 'SD Negeri Banyurip', 'Kecamatan Andong, Kabupaten Boyolali', 'Menabung Ceria, Meraij Cita-cita.', 'Drs. Sutrisno', 'Ibu Siti Aminah, S.Pd')
ON CONFLICT (id) DO NOTHING;
