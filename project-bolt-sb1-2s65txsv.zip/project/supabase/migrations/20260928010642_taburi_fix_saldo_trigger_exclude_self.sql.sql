-- Fix the UPDATE trigger: compute_saldo reads the table which still has OLD values in a BEFORE trigger.
-- Solution: compute sum of all OTHER transactions, then add the NEW row's nominal.

CREATE OR REPLACE FUNCTION public.fn_transaksi_after_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Compute saldo from all other transactions (excluding this row) plus the NEW nominal
  NEW.saldo_setelah := (
    SELECT COALESCE(
      SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
      SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
      0
    )
    FROM transaksi
    WHERE siswa_id = NEW.siswa_id AND id <> NEW.id
  ) + CASE WHEN NEW.jenis = 'setoran' THEN NEW.nominal ELSE -NEW.nominal END;

  -- Sync siswa.saldo
  UPDATE siswa SET saldo = NEW.saldo_setelah WHERE id = NEW.siswa_id;

  -- If siswa_id changed, also recompute saldo for the old siswa
  IF OLD.siswa_id IS DISTINCT FROM NEW.siswa_id THEN
    UPDATE siswa SET saldo = public.compute_saldo(OLD.siswa_id) WHERE id = OLD.siswa_id;
  END IF;

  RETURN NEW;
END;
$function$;

-- Also fix the INSERT trigger to use the same approach (exclude self, add NEW)
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  NEW.saldo_setelah := (
    SELECT COALESCE(
      SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
      SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
      0
    )
    FROM transaksi
    WHERE siswa_id = NEW.siswa_id AND id <> NEW.id
  ) + CASE WHEN NEW.jenis = 'setoran' THEN NEW.nominal ELSE -NEW.nominal END;
  UPDATE siswa SET saldo = NEW.saldo_setelah WHERE id = NEW.siswa_id;
  RETURN NEW;
END;
$function$;
