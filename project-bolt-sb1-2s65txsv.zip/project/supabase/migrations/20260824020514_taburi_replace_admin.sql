/*
# Replace admin account: sdnbanyurip@gmail.com

## What this migration does
1. Creates the production admin auth user with email sdnbanyurip@gmail.com
   and a secure bcrypt-hashed password.
2. The handle_new_user trigger auto-creates a profiles row; we then set
   role='admin' and nama='Administrator' on that row.
3. Deletes the old demo admin user (admin@banyurip.sch.id) from auth.users,
   which cascades to profiles via ON DELETE CASCADE.

## Security
- Only the anon key is used by the frontend. No service role keys are exposed.
- The admin password is stored as a bcrypt hash, never in plaintext in app code.
- The old demo account is removed so it can no longer authenticate.
*/

-- 1. Create the production admin user
INSERT INTO auth.users (
  instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
  created_at, updated_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data,
  email_change_confirm_status, phone, phone_change_token, phone_change, confirmation_token
)
SELECT
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'sdnbanyurip@gmail.com',
  crypt('TaburiAdmin2026!', gen_salt('bf')),
  now(),
  now(),
  now(),
  now(),
  '{"provider":"email","providers":["email"]}'::jsonb,
  '{"nama":"Administrator","role":"admin"}'::jsonb,
  0,
  NULL,
  '',
  NULL,
  ''
WHERE NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'sdnbanyurip@gmail.com');

-- 2. Ensure the profiles row for sdnbanyurip@gmail.com is admin
UPDATE profiles
SET role = 'admin',
    nama = 'Administrator',
    must_change_password = false
WHERE email = 'sdnbanyurip@gmail.com';

-- 3. Delete the old demo admin account (cascades to profiles)
DELETE FROM auth.users WHERE email = 'admin@banyurip.sch.id';
