-- get_my_kelas_id() now uses kelas.wali_kelas_id as the single source of truth
-- for the guru↔kelas relationship (instead of guru.kelas_id).
CREATE OR REPLACE FUNCTION public.get_my_kelas_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
SELECT k.id FROM kelas k WHERE k.wali_kelas_id = auth.uid() LIMIT 1;
$function$;