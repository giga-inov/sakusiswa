/*
# Fix recursive RLS on profiles and all admin policies

## Root cause — "Akun tidak ditemukan" error
The SELECT policy on profiles contains:
  auth.uid() = id OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')

This subquery on profiles INSIDE the profiles RLS policy causes
infinite recursion. Postgres silently fails, returns no rows.
The frontend gets null → "Akun tidak ditemukan."

All other tables (kelas, siswa, transaksi, etc.) have admin policies
that also query profiles, triggering the same recursion.

## Fix
1. Create is_admin() as SECURITY DEFINER — runs as owner, bypasses RLS,
   so no recursion.
2. Replace the recursive profiles SELECT policy.
3. Replace all admin policies on all tables with is_admin() calls.
*/

-- Step 1: Create SECURITY DEFINER function to check admin role
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  );
$$;

-- Step 2: Fix profiles SELECT policy (was recursive)
DROP POLICY IF EXISTS profiles_select_own_or_admin ON profiles;
CREATE POLICY profiles_select_own ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.is_admin());

-- Step 3: Fix profiles INSERT policy (was recursive)
DROP POLICY IF EXISTS profiles_admin_insert ON profiles;
CREATE POLICY profiles_admin_insert ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

-- Step 4: Fix profiles DELETE policy (was recursive)
DROP POLICY IF EXISTS profiles_admin_delete ON profiles;
CREATE POLICY profiles_admin_delete ON profiles
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- Step 5: Fix kelas admin policies
DROP POLICY IF EXISTS kelas_admin_delete ON kelas;
CREATE POLICY kelas_admin_delete ON kelas
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS kelas_admin_insert ON kelas;
CREATE POLICY kelas_admin_insert ON kelas
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS kelas_admin_update ON kelas;
CREATE POLICY kelas_admin_update ON kelas
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Step 6: Fix siswa admin policies
DROP POLICY IF EXISTS siswa_admin_delete ON siswa;
CREATE POLICY siswa_admin_delete ON siswa
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS siswa_admin_insert ON siswa;
CREATE POLICY siswa_admin_insert ON siswa
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS siswa_admin_or_own_update ON siswa;
CREATE POLICY siswa_admin_or_own_update ON siswa
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.is_admin())
  WITH CHECK (user_id = auth.uid() OR public.is_admin());

-- Step 7: Fix transaksi admin policies
DROP POLICY IF EXISTS transaksi_admin_delete ON transaksi;
CREATE POLICY transaksi_admin_delete ON transaksi
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS transaksi_admin_guru_insert ON transaksi;
CREATE POLICY transaksi_admin_guru_insert ON transaksi
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin() OR EXISTS (
    SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'guru'
  ));

DROP POLICY IF EXISTS transaksi_admin_update ON transaksi;
CREATE POLICY transaksi_admin_update ON transaksi
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Step 8: Fix guru admin policies
DROP POLICY IF EXISTS guru_admin_delete ON guru;
CREATE POLICY guru_admin_delete ON guru
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS guru_admin_insert ON guru;
CREATE POLICY guru_admin_insert ON guru
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS guru_admin_update ON guru;
CREATE POLICY guru_admin_update ON guru
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Step 9: Fix aktivitas admin policy
DROP POLICY IF EXISTS aktivitas_admin_delete ON aktivitas;
CREATE POLICY aktivitas_admin_delete ON aktivitas
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- Step 10: Fix alumni admin policies
DROP POLICY IF EXISTS alumni_admin_delete ON alumni;
CREATE POLICY alumni_admin_delete ON alumni
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS alumni_admin_insert ON alumni;
CREATE POLICY alumni_admin_insert ON alumni
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS alumni_admin_update ON alumni;
CREATE POLICY alumni_admin_update ON alumni
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Step 11: Fix tahun_pelajaran admin policies
DROP POLICY IF EXISTS tp_admin_delete ON tahun_pelajaran;
CREATE POLICY tp_admin_delete ON tahun_pelajaran
  FOR DELETE TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS tp_admin_insert ON tahun_pelajaran;
CREATE POLICY tp_admin_insert ON tahun_pelajaran
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS tp_admin_update ON tahun_pelajaran;
CREATE POLICY tp_admin_update ON tahun_pelajaran
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Step 12: Fix pengaturan admin policy
DROP POLICY IF EXISTS pengaturan_admin_update ON pengaturan;
CREATE POLICY pengaturan_admin_update ON pengaturan
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());
