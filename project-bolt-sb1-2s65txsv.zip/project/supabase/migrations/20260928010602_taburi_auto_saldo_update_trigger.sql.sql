-- Add UPDATE trigger to recompute saldo_setelah and sync siswa.saldo when a transaksi is updated
-- This complements the existing INSERT and DELETE triggers

CREATE OR REPLACE FUNCTION public.fn_transaksi_after_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  -- Recompute saldo_setelah for the updated row
  NEW.saldo_setelah := public.compute_saldo(NEW.siswa_id);
  -- Sync siswa.saldo
  UPDATE siswa SET saldo = NEW.saldo_setelah WHERE id = NEW.siswa_id;
  -- If siswa_id changed, also recompute saldo for the old siswa
  IF OLD.siswa_id IS DISTINCT FROM NEW.siswa_id THEN
    UPDATE siswa SET saldo = public.compute_saldo(OLD.siswa_id) WHERE id = OLD.siswa_id;
  END IF;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_transaksi_update ON transaksi;
CREATE TRIGGER trg_transaksi_update
  BEFORE UPDATE ON transaksi
  FOR EACH ROW EXECUTE FUNCTION public.fn_transaksi_after_update();
