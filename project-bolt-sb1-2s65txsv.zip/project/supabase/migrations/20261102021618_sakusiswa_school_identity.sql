/*
# Rebrand TABURI -> SAKU SISWA + School Identity Settings

## Summary
This migration extends the `pengaturan` table with full school identity fields
(NPSN, kecamatan, kabupaten/kota, provinsi, email sekolah) and adds a public
read policy so the login and public "cek tabungan" pages (anon-key clients) can
display the school name, slogan, and logo. It also creates a public storage
bucket `logo-sekolah` where the school logo is permanently stored, plus storage
policies allowing anyone to read the logo and only admins to upload/replace/delete it.

The default slogan is updated to the new SAKU SISWA tagline. Existing data is
preserved — all new columns are nullable, and existing rows keep their values.
No tables are dropped and no columns are deleted.

## Changes

### 1. Table `pengaturan` — new columns
- `npsn` (text) — Nomor Pokok Sekolah Nasional.
- `kecamatan` (text) — Kecamatan sekolah.
- `kabupaten_kota` (text) — Kabupaten / Kota sekolah.
- `provinsi` (text) — Provinsi sekolah.
- `email_sekolah` (text) — Email resmi sekolah.
- `app_name` (text, default 'SAKU SISWA') — Display name of the application.
- `app_tagline` (text, default 'Menabung Mudah, Terpantau dan Terpercaya.') — App tagline.
- `app_subtitle` (text, default 'Sistem Tabungan Digital Siswa') — App subtitle.

### 2. Default slogan update
- Existing default slogan column keeps its column, but the seed row is updated
  to the new tagline 'Menabung Mudah, Terpantau dan Terpercaya.' for existing
  installations. No data loss — only the slogan text of the single settings row
  is refreshed to the new brand tagline.

### 3. Storage bucket `logo-sekolah`
- Public bucket (public read). School logo is stored at path `logo.png`.
- Storage policies:
  - SELECT (read): allowed for everyone (anon + authenticated) — the logo is
    shown on the login page and public cek-tabungan page.
  - INSERT / UPDATE / DELETE: only authenticated admins (profiles.role = 'admin').

### 4. RLS policy changes on `pengaturan`
- New `pengaturan_select_anon` policy: SELECT to `anon` so the login and public
    pages (anon-key clients) can read the school identity. The existing
    `pengaturan_select_all` authenticated policy is kept.
- The admin update policy is unchanged.

### 5. Grants
- GRANT SELECT on `pengaturan` to `anon` so the anon-key client can reach it.
- Storage bucket policies handle object-level access.
*/

-- ============================================================
-- 1. Add school identity columns to pengaturan
-- ============================================================
ALTER TABLE pengaturan
  ADD COLUMN IF NOT EXISTS npsn text,
  ADD COLUMN IF NOT EXISTS kecamatan text,
  ADD COLUMN IF NOT EXISTS kabupaten_kota text,
  ADD COLUMN IF NOT EXISTS provinsi text,
  ADD COLUMN IF NOT EXISTS email_sekolah text,
  ADD COLUMN IF NOT EXISTS app_name text NOT NULL DEFAULT 'SAKU SISWA',
  ADD COLUMN IF NOT EXISTS app_tagline text NOT NULL DEFAULT 'Menabung Mudah, Terpantau dan Terpercaya.',
  ADD COLUMN IF NOT EXISTS app_subtitle text NOT NULL DEFAULT 'Sistem Tabungan Digital Siswa';

-- Refresh the single settings row's slogan + app identity to the new brand,
-- but only where the old slogan is the legacy TABURI slogan (so we never
-- overwrite an admin-customized slogan).
UPDATE pengaturan
  SET slogan = 'Menabung Mudah, Terpantau dan Terpercaya.',
      app_name = 'SAKU SISWA',
      app_tagline = 'Menabung Mudah, Terpantau dan Terpercaya.',
      app_subtitle = 'Sistem Tabungan Digital Siswa'
  WHERE id = 1
    AND slogan = 'Menabung Ceria, Meraij Cita-cita.';

-- ============================================================
-- 2. Storage bucket for school logo
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
  VALUES ('logo-sekolah', 'logo-sekolah', true)
  ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- 3. Storage policies (objects in logo-sekolah)
-- ============================================================
-- Public read: anyone can fetch the logo (login + public pages are anon).
DROP POLICY IF EXISTS "logo_sekolah_public_read" ON storage.objects;
CREATE POLICY "logo_sekolah_public_read"
  ON storage.objects FOR SELECT
  TO authenticated, anon
  USING (bucket_id = 'logo-sekolah');

-- Admin-only insert.
DROP POLICY IF EXISTS "logo_sekolah_admin_insert" ON storage.objects;
CREATE POLICY "logo_sekolah_admin_insert"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'logo-sekolah'
    AND EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Admin-only update.
DROP POLICY IF EXISTS "logo_sekolah_admin_update" ON storage.objects;
CREATE POLICY "logo_sekolah_admin_update"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'logo-sekolah'
    AND EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  )
  WITH CHECK (
    bucket_id = 'logo-sekolah'
    AND EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Admin-only delete.
DROP POLICY IF EXISTS "logo_sekolah_admin_delete" ON storage.objects;
CREATE POLICY "logo_sekolah_admin_delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'logo-sekolah'
    AND EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- 4. RLS: allow anon to read pengaturan (school identity on public pages)
-- ============================================================
GRANT SELECT ON pengaturan TO anon;

DROP POLICY IF EXISTS "pengaturan_select_anon" ON pengaturan;
CREATE POLICY "pengaturan_select_anon"
  ON pengaturan FOR SELECT
  TO anon USING (true);
