-- Auto-compute saldo_setelah on transaksi insert and sync siswa.saldo
-- Saldo = SUM(setoran) - SUM(penarikan), always derived from transactions

-- Function to compute current saldo for a siswa from all transactions
CREATE OR REPLACE FUNCTION public.compute_saldo(p_siswa_id uuid)
RETURNS numeric
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
SELECT COALESCE(
  SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
      SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
  0
)
FROM transaksi
WHERE siswa_id = p_siswa_id;
$function$;

-- Trigger: on transaksi INSERT, set saldo_setelah and update siswa.saldo
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  NEW.saldo_setelah := public.compute_saldo(NEW.siswa_id);
  UPDATE siswa SET saldo = NEW.saldo_setelah WHERE id = NEW.siswa_id;
  RETURN NEW;
END;
$function$;

-- Trigger: on transaksi DELETE, recompute siswa.saldo
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE siswa SET saldo = public.compute_saldo(OLD.siswa_id) WHERE id = OLD.siswa_id;
  RETURN OLD;
END;
$function$;

DROP TRIGGER IF EXISTS trg_transaksi_insert ON transaksi;
CREATE TRIGGER trg_transaksi_insert
  BEFORE INSERT ON transaksi
  FOR EACH ROW EXECUTE FUNCTION public.fn_transaksi_after_insert();

DROP TRIGGER IF EXISTS trg_transaksi_delete ON transaksi;
CREATE TRIGGER trg_transaksi_delete
  AFTER DELETE ON transaksi
  FOR EACH ROW EXECUTE FUNCTION public.fn_transaksi_after_delete();

-- Sync all existing siswa.saldo from transactions
UPDATE siswa s SET saldo = public.compute_saldo(s.id);