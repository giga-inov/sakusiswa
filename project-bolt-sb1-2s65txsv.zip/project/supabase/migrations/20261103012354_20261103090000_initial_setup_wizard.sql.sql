/*
# Secure first-run setup state

1. New table: app_setup_state stores one private row for setup completion and a short-lived claim token.
2. Existing data: installations with an existing admin are marked complete; new installations remain available for setup. No existing rows are deleted.
3. Security: RLS is enabled with no direct client access. Public setup uses only narrow RPC functions. The first admin role is assigned only after the server validates the one-time claim.
4. Passwords: Supabase Auth owns passwords; this database never stores them.
*/

CREATE TABLE IF NOT EXISTS public.app_setup_state (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  setup_completed boolean NOT NULL DEFAULT false,
  initial_admin_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  setup_claim_token text,
  claim_expires_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.app_setup_state ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.app_setup_state FROM anon, authenticated;
GRANT ALL ON public.app_setup_state TO service_role;

INSERT INTO public.app_setup_state (id, setup_completed, initial_admin_id, completed_at)
SELECT true,
       EXISTS (SELECT 1 FROM public.profiles WHERE role = 'admin'),
       (SELECT id FROM public.profiles WHERE role = 'admin' LIMIT 1),
       CASE WHEN EXISTS (SELECT 1 FROM public.profiles WHERE role = 'admin') THEN now() ELSE NULL END
WHERE NOT EXISTS (SELECT 1 FROM public.app_setup_state WHERE id = true);

CREATE OR REPLACE FUNCTION public.get_setup_status()
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT setup_completed FROM public.app_setup_state WHERE id = true;
$$;

CREATE OR REPLACE FUNCTION public.claim_initial_setup(p_claim_token text, p_school jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_state public.app_setup_state;
  v_name text;
BEGIN
  IF p_claim_token IS NULL OR length(p_claim_token) < 32 THEN RAISE EXCEPTION 'Invalid setup claim'; END IF;
  v_name := NULLIF(trim(p_school->>'nama_sekolah'), '');
  IF v_name IS NULL OR length(v_name) > 200 THEN RAISE EXCEPTION 'Invalid school identity'; END IF;

  SELECT * INTO v_state FROM public.app_setup_state WHERE id = true FOR UPDATE;
  IF v_state.setup_completed OR (v_state.setup_claim_token IS NOT NULL AND v_state.claim_expires_at > now()) THEN
    RAISE EXCEPTION 'Setup is unavailable';
  END IF;

  UPDATE public.app_setup_state
  SET setup_claim_token = p_claim_token, claim_expires_at = now() + interval '15 minutes', updated_at = now()
  WHERE id = true;

  UPDATE public.pengaturan SET
    nama_sekolah = v_name,
    npsn = NULLIF(trim(p_school->>'npsn'), ''),
    alamat = NULLIF(trim(p_school->>'alamat'), ''),
    kecamatan = NULLIF(trim(p_school->>'kecamatan'), ''),
    kabupaten_kota = NULLIF(trim(p_school->>'kabupaten_kota'), ''),
    provinsi = NULLIF(trim(p_school->>'provinsi'), ''),
    email_sekolah = NULLIF(trim(p_school->>'email_sekolah'), ''),
    no_telepon = NULLIF(trim(p_school->>'no_telepon'), ''),
    nama_kepala_sekolah = NULLIF(trim(p_school->>'nama_kepala_sekolah'), ''),
    nama_bendahara = NULLIF(trim(p_school->>'nama_bendahara'), ''),
    tahun_aktif = NULLIF(trim(p_school->>'tahun_aktif'), ''),
    slogan = COALESCE(NULLIF(trim(p_school->>'slogan'), ''), slogan),
    updated_at = now()
  WHERE id = 1;
END;
$$;

CREATE OR REPLACE FUNCTION public.finalize_initial_setup(p_claim_token text, p_admin_id uuid, p_nama text, p_email text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_state public.app_setup_state;
BEGIN
  SELECT * INTO v_state FROM public.app_setup_state WHERE id = true FOR UPDATE;
  IF v_state.setup_completed OR v_state.setup_claim_token IS DISTINCT FROM p_claim_token OR v_state.claim_expires_at IS NULL OR v_state.claim_expires_at <= now() THEN
    RAISE EXCEPTION 'Setup is unavailable';
  END IF;
  UPDATE public.profiles SET role = 'admin', nama = left(trim(p_nama), 200), email = lower(trim(p_email)) WHERE id = p_admin_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Administrator profile unavailable'; END IF;
  UPDATE public.app_setup_state SET setup_completed = true, initial_admin_id = p_admin_id, setup_claim_token = NULL, claim_expires_at = NULL, completed_at = now(), updated_at = now() WHERE id = true;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_initial_setup(p_claim_token text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE public.app_setup_state SET setup_claim_token = NULL, claim_expires_at = NULL, updated_at = now()
  WHERE id = true AND setup_completed = false AND setup_claim_token = p_claim_token;
$$;

REVOKE ALL ON FUNCTION public.get_setup_status() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.claim_initial_setup(text, jsonb) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.finalize_initial_setup(text, uuid, text, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.release_initial_setup(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_setup_status() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_initial_setup(text, jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.finalize_initial_setup(text, uuid, text, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.release_initial_setup(text) TO service_role;