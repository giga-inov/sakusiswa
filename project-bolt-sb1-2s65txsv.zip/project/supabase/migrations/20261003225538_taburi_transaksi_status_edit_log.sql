/*
# Transaksi Status, Edit Log, and Saldo Recalculation

## Overview
This migration adds status tracking, edit logging, and cancel functionality to the transaksi table.
It ensures cancelled transactions are excluded from saldo calculations while preserving full audit history.

## Changes to `transaksi` table
1. `status` (text, NOT NULL, DEFAULT 'aktif') — 'aktif' or 'dibatalkan'
2. `updated_at` (timestamptz, DEFAULT now()) — timestamp of last edit
3. `updated_by` (uuid, nullable) — auth.uid of the user who last edited
4. `updated_by_name` (text, nullable) — name of the user who last edited
5. `cancelled_at` (timestamptz, nullable) — when the transaction was cancelled
6. `cancelled_by` (uuid, nullable) — auth.uid of who cancelled
7. `cancelled_by_name` (text, nullable) — name of who cancelled
8. `cancel_reason` (text, nullable) — reason for cancellation

## New table: `transaksi_edit_log`
Tracks every edit to a transaction:
- `id` (uuid PK)
- `transaksi_id` (uuid FK to transaksi)
- `field_name` (text) — which field changed
- `old_value` (text) — previous value
- `new_value` (text) — new value
- `edited_by` (uuid) — auth.uid of editor
- `edited_by_name` (text) — name of editor
- `edited_by_role` (text) — role of editor
- `edit_reason` (text) — reason for the change
- `created_at` (timestamptz DEFAULT now())

## Updated functions
1. `compute_saldo(p_siswa_id)` — now only counts transactions with status='aktif'
2. `fn_transaksi_after_insert` — only counts active transactions for saldo_setelah
3. `fn_transaksi_after_update` — only counts active transactions, handles status changes
4. `recompute_saldo_on_delete` — only counts active transactions
5. `fn_transaksi_after_delete` — only counts active transactions
6. `cek_tabungan_by_nisn` — only returns active transactions, sorted by tanggal ASC then created_at ASC

## Security
- RLS enabled on `transaksi_edit_log`
- Admin can read all edit logs, guru can read for their class
- Updated transaksi UPDATE policies to allow guru to edit transactions in their class
*/

-- Create set_updated_at function first (needed by trigger)
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$function$;

-- Add status and audit columns to transaksi
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'status') THEN
    ALTER TABLE transaksi ADD COLUMN status text NOT NULL DEFAULT 'aktif';
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'updated_at') THEN
    ALTER TABLE transaksi ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'updated_by') THEN
    ALTER TABLE transaksi ADD COLUMN updated_by uuid;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'updated_by_name') THEN
    ALTER TABLE transaksi ADD COLUMN updated_by_name text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'cancelled_at') THEN
    ALTER TABLE transaksi ADD COLUMN cancelled_at timestamptz;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'cancelled_by') THEN
    ALTER TABLE transaksi ADD COLUMN cancelled_by uuid;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'cancelled_by_name') THEN
    ALTER TABLE transaksi ADD COLUMN cancelled_by_name text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'transaksi' AND column_name = 'cancel_reason') THEN
    ALTER TABLE transaksi ADD COLUMN cancel_reason text;
  END IF;
END $$;

-- Create transaksi_edit_log table
CREATE TABLE IF NOT EXISTS transaksi_edit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaksi_id uuid NOT NULL REFERENCES transaksi(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  old_value text,
  new_value text,
  edited_by uuid,
  edited_by_name text,
  edited_by_role text,
  edit_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE transaksi_edit_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "edit_log_admin_read" ON transaksi_edit_log;
CREATE POLICY "edit_log_admin_read"
ON transaksi_edit_log FOR SELECT
TO authenticated
USING (is_admin());

DROP POLICY IF EXISTS "edit_log_guru_read" ON transaksi_edit_log;
CREATE POLICY "edit_log_guru_read"
ON transaksi_edit_log FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM transaksi t
    JOIN siswa s ON s.id = t.siswa_id
    WHERE t.id = transaksi_edit_log.transaksi_id
    AND s.kelas_id = get_my_kelas_id()
  )
);

DROP POLICY IF EXISTS "edit_log_admin_insert" ON transaksi_edit_log;
CREATE POLICY "edit_log_admin_insert"
ON transaksi_edit_log FOR INSERT
TO authenticated
WITH CHECK (is_admin() OR is_guru());

-- Update compute_saldo to only count active transactions
CREATE OR REPLACE FUNCTION public.compute_saldo(p_siswa_id uuid)
RETURNS numeric
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
SELECT COALESCE(
  SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
  SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
  0
)
FROM transaksi
WHERE siswa_id = p_siswa_id AND status = 'aktif';
$function$;

-- Update fn_transaksi_after_insert to only count active
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  NEW.saldo_setelah := (
    SELECT COALESCE(
      SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
      SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
      0
    )
    FROM transaksi
    WHERE siswa_id = NEW.siswa_id AND id <> NEW.id AND status = 'aktif'
  ) + CASE WHEN NEW.jenis = 'setoran' THEN NEW.nominal ELSE -NEW.nominal END;
  UPDATE siswa SET saldo = NEW.saldo_setelah WHERE id = NEW.siswa_id;
  RETURN NEW;
END;
$function$;

-- Update fn_transaksi_after_update to only count active and handle status changes
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  NEW.saldo_setelah := (
    SELECT COALESCE(
      SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
      SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
      0
    )
    FROM transaksi
    WHERE siswa_id = NEW.siswa_id AND id <> NEW.id AND status = 'aktif'
  ) + CASE WHEN NEW.jenis = 'setoran' THEN NEW.nominal ELSE -NEW.nominal END;

  -- If cancelled, saldo_setelah should reflect removal from total
  IF NEW.status = 'dibatalkan' THEN
    NEW.saldo_setelah := (
      SELECT COALESCE(
        SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
        SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
        0
      )
      FROM transaksi
      WHERE siswa_id = NEW.siswa_id AND id <> NEW.id AND status = 'aktif'
    );
  END IF;

  UPDATE siswa SET saldo = NEW.saldo_setelah WHERE id = NEW.siswa_id;

  IF OLD.siswa_id IS DISTINCT FROM NEW.siswa_id THEN
    UPDATE siswa SET saldo = public.compute_saldo(OLD.siswa_id) WHERE id = OLD.siswa_id;
  END IF;

  RETURN NEW;
END;
$function$;

-- Update recompute_saldo_on_delete to only count active
CREATE OR REPLACE FUNCTION public.recompute_saldo_on_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  new_saldo numeric(14,2);
BEGIN
  SELECT COALESCE(
    SUM(CASE WHEN jenis = 'setoran' THEN nominal ELSE 0 END) -
    SUM(CASE WHEN jenis = 'penarikan' THEN nominal ELSE 0 END),
    0
  ) INTO new_saldo
  FROM transaksi
  WHERE siswa_id = OLD.siswa_id AND status = 'aktif';

  UPDATE siswa SET saldo = new_saldo WHERE id = OLD.siswa_id;
  RETURN OLD;
END;
$function$;

-- Update fn_transaksi_after_delete to only count active
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE siswa SET saldo = public.compute_saldo(OLD.siswa_id) WHERE id = OLD.siswa_id;
  RETURN OLD;
END;
$function$;

-- Update cek_tabungan_by_nisn to only return active transactions, sorted chronologically
CREATE OR REPLACE FUNCTION public.cek_tabungan_by_nisn(p_nisn text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_siswa RECORD;
  v_result json;
BEGIN
  SELECT s.id, s.nama, s.nis, s.nisn, s.saldo, s.kelas_id,
  k.nama as kelas_nama
  INTO v_siswa
  FROM siswa s
  LEFT JOIN kelas k ON k.id = s.kelas_id
  WHERE s.nisn = p_nisn AND s.status = 'aktif'
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN json_build_object('found', false);
  END IF;

  SELECT json_build_object(
    'found', true,
    'siswa', json_build_object(
      'id', v_siswa.id,
      'nama', v_siswa.nama,
      'nis', v_siswa.nis,
      'nisn', v_siswa.nisn,
      'saldo', v_siswa.saldo,
      'kelas_nama', v_siswa.kelas_nama
    ),
    'transaksi', COALESCE(
      (SELECT json_agg(
        json_build_object(
          'id', t.id,
          'tanggal', t.tanggal,
          'jenis', t.jenis,
          'nominal', t.nominal,
          'saldo_setelah', t.saldo_setelah,
          'keterangan', t.keterangan,
          'petugas_nama', t.petugas_nama
        )
        ORDER BY t.tanggal ASC, t.created_at ASC
      )
      FROM transaksi t
      WHERE t.siswa_id = v_siswa.id AND t.status = 'aktif'),
      '[]'::json
    )
  ) INTO v_result;

  RETURN v_result;
END;
$function$;

-- Update RLS: allow guru to update transactions in their class
DROP POLICY IF EXISTS "transaksi_admin_update" ON transaksi;
CREATE POLICY "transaksi_admin_update"
ON transaksi FOR UPDATE
TO authenticated
USING (is_admin())
WITH CHECK (is_admin());

DROP POLICY IF EXISTS "transaksi_guru_update" ON transaksi;
CREATE POLICY "transaksi_guru_update"
ON transaksi FOR UPDATE
TO authenticated
USING (
  is_guru() AND EXISTS (
    SELECT 1 FROM siswa s
    WHERE s.id = transaksi.siswa_id AND s.kelas_id = get_my_kelas_id()
  )
)
WITH CHECK (
  is_guru() AND EXISTS (
    SELECT 1 FROM siswa s
    WHERE s.id = transaksi.siswa_id AND s.kelas_id = get_my_kelas_id()
  )
);

-- Add updated_at trigger to auto-update on row change
DROP TRIGGER IF EXISTS trg_transaksi_set_updated_at ON transaksi;
CREATE TRIGGER trg_transaksi_set_updated_at
BEFORE UPDATE ON transaksi
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Index for status filtering
CREATE INDEX IF NOT EXISTS idx_transaksi_status ON transaksi(status);
CREATE INDEX IF NOT EXISTS idx_transaksi_edit_log_transaksi_id ON transaksi_edit_log(transaksi_id);
