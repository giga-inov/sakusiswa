/*
# Recompute All Saldo After Edit + Delete Policy for Guru

## Overview
When a transaction is edited, the saldo_setelah of ALL subsequent transactions for that student
must be recalculated chronologically. The old trigger only updated the edited row's saldo_setelah,
leaving subsequent transactions with stale running balances.

## Changes
1. New function `recompute_all_saldo(p_siswa_id)` — recalculates saldo_setelah for ALL active
   transactions of a student, ordered by tanggal ASC then created_at ASC, and updates siswa.saldo.
2. Updated `fn_transaksi_after_update` trigger to call recompute_all_saldo after any update.
3. Updated `fn_transaksi_after_insert` to call recompute_all_saldo for consistency.
4. Updated `fn_transaksi_after_delete` to call recompute_all_saldo.
5. New RLS policy `transaksi_guru_delete` allowing guru to delete transactions in their class.
6. New RLS policy `transaksi_admin_delete` already exists — kept as is.
*/

CREATE OR REPLACE FUNCTION public.recompute_all_saldo(p_siswa_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  running_balance numeric(14,2) := 0;
  t_rec RECORD;
BEGIN
  -- Recalculate saldo_setelah for all active transactions chronologically
  FOR t_rec IN
    SELECT id, jenis, nominal
    FROM transaksi
    WHERE siswa_id = p_siswa_id AND status = 'aktif'
    ORDER BY tanggal ASC, created_at ASC
  LOOP
    IF t_rec.jenis = 'setoran' THEN
      running_balance := running_balance + t_rec.nominal;
    ELSIF t_rec.jenis = 'penarikan' THEN
      running_balance := running_balance - t_rec.nominal;
    END IF;

    UPDATE transaksi SET saldo_setelah = running_balance WHERE id = t_rec.id;
  END LOOP;

  -- Update the student's saldo to the final running balance
  UPDATE siswa SET saldo = running_balance WHERE id = p_siswa_id;
END;
$function$;

-- Update the AFTER UPDATE trigger to recompute all saldo
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Recompute all saldo_setelah for the student (handles both same-student and transferred cases)
  PERFORM public.recompute_all_saldo(NEW.siswa_id);

  IF OLD.siswa_id IS DISTINCT FROM NEW.siswa_id THEN
    PERFORM public.recompute_all_saldo(OLD.siswa_id);
  END IF;

  -- Set the NEW.saldo_setelah to the recomputed value
  SELECT saldo_setelah INTO NEW.saldo_setelah FROM transaksi WHERE id = NEW.id;

  RETURN NEW;
END;
$function$;

-- Update the AFTER INSERT trigger to recompute all saldo
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Recompute all saldo_setelah chronologically for this student
  PERFORM public.recompute_all_saldo(NEW.siswa_id);

  -- Set the NEW.saldo_setelah to the recomputed value
  SELECT saldo_setelah INTO NEW.saldo_setelah FROM transaksi WHERE id = NEW.id;

  RETURN NEW;
END;
$function$;

-- Update the AFTER DELETE trigger to recompute all saldo
CREATE OR REPLACE FUNCTION public.fn_transaksi_after_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  PERFORM public.recompute_all_saldo(OLD.siswa_id);
  RETURN OLD;
END;
$function$;

-- Add delete policy for guru (only transactions in their class)
DROP POLICY IF EXISTS "transaksi_guru_delete" ON transaksi;
CREATE POLICY "transaksi_guru_delete"
ON transaksi FOR DELETE
TO authenticated
USING (
  is_guru() AND EXISTS (
    SELECT 1 FROM siswa s
    WHERE s.id = transaksi.siswa_id AND s.kelas_id = get_my_kelas_id()
  )
);
