-- Fix search_path on pre-existing SECURITY DEFINER functions
-- These are warnings from the security advisor

CREATE OR REPLACE FUNCTION public.log_aktivitas(
  p_user_id uuid,
  p_nama_user text,
  p_role text,
  p_aksi text,
  p_modul text,
  p_detail text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO aktivitas (user_id, nama_user, role, aksi, modul, detail)
  VALUES (p_user_id, p_nama_user, p_role, p_aksi, p_modul, p_detail);
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, email, nama, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'nama', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'guru')
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_saldo_after_transaksi()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
new_saldo numeric(14,2);
current_saldo numeric(14,2);
BEGIN
SELECT saldo INTO current_saldo FROM siswa WHERE id = NEW.siswa_id FOR UPDATE;
IF NEW.jenis = 'setoran' THEN
new_saldo := current_saldo + NEW.nominal;
ELSIF NEW.jenis = 'penarikan' THEN
new_saldo := current_saldo - NEW.nominal;
IF new_saldo < 0 THEN
RAISE EXCEPTION 'Saldo tidak mencukupi untuk penarikan';
END IF;
ELSIF NEW.jenis = 'koreksi' THEN
new_saldo := NEW.nominal;
END IF;
UPDATE siswa SET saldo = new_saldo WHERE id = NEW.siswa_id;
NEW.saldo_setelah := new_saldo;
RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.recompute_saldo_on_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_saldo numeric(14,2);
BEGIN
  SELECT COALESCE(SUM(
    CASE
      WHEN jenis = 'setoran' THEN nominal
      WHEN jenis = 'penarikan' THEN -nominal
      WHEN jenis = 'koreksi' THEN 0
      ELSE 0
    END
  ), 0) INTO new_saldo
  FROM transaksi
  WHERE siswa_id = OLD.siswa_id;

  UPDATE siswa SET saldo = new_saldo WHERE id = OLD.siswa_id;
  RETURN OLD;
END;
$$;

CREATE OR REPLACE FUNCTION public.naik_kelas()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE siswa SET kelas_id = k2.id
  FROM kelas k1, kelas k2
  WHERE siswa.kelas_id = k1.id
    AND k2.tingkat = k1.tingkat + 1;
END;
$$;
