/*
# Fix initial setup school field mapping

1. Modified function: `claim_initial_setup` now writes the existing `pengaturan.tahun_aktif_id` column only when a valid UUID is supplied.
2. Data safety: no existing tables, users, school data, transactions, or balances are deleted or recreated.
3. Security: the function remains a SECURITY DEFINER function with its existing restricted RPC grants.
*/

CREATE OR REPLACE FUNCTION public.claim_initial_setup(p_claim_token text, p_school jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_state public.app_setup_state;
  v_name text;
  v_year uuid;
BEGIN
  IF p_claim_token IS NULL OR length(p_claim_token) < 32 THEN RAISE EXCEPTION 'Invalid setup claim'; END IF;
  v_name := NULLIF(trim(p_school->>'nama_sekolah'), '');
  IF v_name IS NULL OR length(v_name) > 200 THEN RAISE EXCEPTION 'Invalid school identity'; END IF;
  BEGIN
    v_year := NULLIF(trim(p_school->>'tahun_aktif_id'), '')::uuid;
  EXCEPTION WHEN invalid_text_representation THEN
    v_year := NULL;
  END;

  SELECT * INTO v_state FROM public.app_setup_state WHERE id = true FOR UPDATE;
  IF v_state.setup_completed OR (v_state.setup_claim_token IS NOT NULL AND v_state.claim_expires_at > now()) THEN
    RAISE EXCEPTION 'Setup is unavailable';
  END IF;

  UPDATE public.app_setup_state SET setup_claim_token = p_claim_token, claim_expires_at = now() + interval '15 minutes', updated_at = now() WHERE id = true;
  UPDATE public.pengaturan SET
    nama_sekolah = v_name,
    npsn = NULLIF(trim(p_school->>'npsn'), ''),
    alamat = NULLIF(trim(p_school->>'alamat'), ''),
    kecamatan = NULLIF(trim(p_school->>'kecamatan'), ''),
    kabupaten_kota = NULLIF(trim(p_school->>'kabupaten_kota'), ''),
    provinsi = NULLIF(trim(p_school->>'provinsi'), ''),
    email_sekolah = NULLIF(trim(p_school->>'email_sekolah'), ''),
    no_telepon = NULLIF(trim(p_school->>'no_telepon'), ''),
    tahun_aktif_id = COALESCE(v_year, tahun_aktif_id),
    updated_at = now()
  WHERE id = 1;
END;
$$;

REVOKE ALL ON FUNCTION public.claim_initial_setup(text, jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_initial_setup(text, jsonb) TO anon, authenticated;