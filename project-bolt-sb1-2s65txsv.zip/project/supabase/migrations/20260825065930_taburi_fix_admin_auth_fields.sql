/*
# Fix "Database error querying schema" on login

## Root cause
The admin user was created via direct INSERT into auth.users (in the
taburi_replace_admin migration). Several NOT NULL columns with defaults
were bypassed, leaving them as NULL. When Supabase's GoTrue auth service
tries to read the user during signInWithPassword(), it encounters these
NULLs and throws "Database error querying schema".

## Fix
Set the missing NOT NULL columns to their proper defaults so GoTrue
can read the record correctly. We do NOT delete the user or the profile
— we only patch the columns that were left NULL.

## Affected columns (should not be NULL per GoTrue expectations)
- email_change       → '' (empty string)
- phone_change       → '' (empty string)
- recovery_token     → '' (empty string)
- email_change_token_new → '' (empty string)
*/

UPDATE auth.users
SET
  email_change = COALESCE(email_change, ''),
  phone_change = COALESCE(phone_change, ''),
  recovery_token = COALESCE(recovery_token, ''),
  email_change_token_new = COALESCE(email_change_token_new, ''),
  email_change_token_current = COALESCE(email_change_token_current, ''),
  reauthentication_token = COALESCE(reauthentication_token, ''),
  updated_at = now()
WHERE email = 'sdnbanyurip@gmail.com';
