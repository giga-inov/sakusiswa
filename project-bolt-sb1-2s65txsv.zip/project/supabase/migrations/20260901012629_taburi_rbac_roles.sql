/*
# Role-Based Access Control (RBAC) for TABURI

## Overview
Restructures the access control system to enforce 3 distinct roles:
- Admin: manages guru, siswa, kelas, tahun pelajaran. NO transaksi access.
- Guru: manages transaksi (setoran/penarikan) ONLY for siswa in their kelas.
- Siswa: read-only access to own data via NISN login.

## Database Changes
1. Creates `get_my_kelas_id()` SECURITY DEFINER function to find the
   authenticated guru's kelas_id without RLS recursion.
2. Updates `is_admin()` (already exists from previous migration — recreated
   with explicit search_path for security advisor compliance).
3. Creates `is_guru()` helper function.
4. Creates `is_siswa()` helper function.
5. Overhauls ALL RLS policies on ALL tables to enforce role-based access.

## Security Changes
- profiles: SELECT own + admin; UPDATE own; INSERT/DELETE admin only.
- guru: SELECT admin + own guru; INSERT/UPDATE/DELETE admin only.
- kelas: SELECT all authenticated; INSERT/UPDATE/DELETE admin only.
- siswa: SELECT admin + own siswa + guru (own kelas); INSERT/UPDATE/DELETE admin only.
- transaksi: SELECT admin + own siswa + guru (own kelas); INSERT guru + admin; UPDATE/DELETE admin only.
- tahun_pelajaran: SELECT all authenticated; INSERT/UPDATE/DELETE admin only.
- pengaturan: SELECT all authenticated; UPDATE admin only.
- aktivitas: SELECT admin only; INSERT all authenticated.
- alumni: SELECT admin only; INSERT/UPDATE/DELETE admin only.

## No data is changed. No tables dropped. No users deleted.
*/

-- ============================================================================
-- HELPER FUNCTIONS (SECURITY DEFINER — bypass RLS, no recursion)
-- ============================================================================

-- is_admin() — already exists, recreate with proper search_path
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  );
$$;

-- is_guru() — check if current user is a guru
CREATE OR REPLACE FUNCTION public.is_guru()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.role = 'guru'
  );
$$;

-- is_siswa() — check if current user is a siswa
CREATE OR REPLACE FUNCTION public.is_siswa()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.role = 'siswa'
  );
$$;

-- get_my_kelas_id() — returns the kelas_id of the authenticated guru
-- Returns NULL if user is not a guru or has no kelas assigned
CREATE OR REPLACE FUNCTION public.get_my_kelas_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT g.kelas_id FROM guru g WHERE g.user_id = auth.uid() LIMIT 1;
$$;

-- get_my_siswa_id() — returns the siswa.id of the authenticated siswa
-- Returns NULL if user is not a siswa
CREATE OR REPLACE FUNCTION public.get_my_siswa_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT s.id FROM siswa s WHERE s.user_id = auth.uid() LIMIT 1;
$$;

-- ============================================================================
-- PROFILES
-- ============================================================================
DROP POLICY IF EXISTS profiles_select_own ON profiles;
DROP POLICY IF EXISTS profiles_select_own_or_admin ON profiles;
DROP POLICY IF EXISTS profiles_admin_insert ON profiles;
DROP POLICY IF EXISTS profiles_update_own ON profiles;
DROP POLICY IF EXISTS profiles_admin_delete ON profiles;

CREATE POLICY profiles_select_own ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.is_admin());

CREATE POLICY profiles_admin_insert ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY profiles_update_own ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY profiles_admin_delete ON profiles
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- GURU
-- ============================================================================
DROP POLICY IF EXISTS guru_select_all ON guru;
DROP POLICY IF EXISTS guru_admin_insert ON guru;
DROP POLICY IF EXISTS guru_admin_update ON guru;
DROP POLICY IF EXISTS guru_admin_delete ON guru;
DROP POLICY IF EXISTS guru_select_own ON guru;

-- Admin sees all guru; guru sees own record
CREATE POLICY guru_select_own_or_admin ON guru
  FOR SELECT TO authenticated
  USING (public.is_admin() OR user_id = auth.uid());

CREATE POLICY guru_admin_insert ON guru
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY guru_admin_update ON guru
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY guru_admin_delete ON guru
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- KELAS
-- ============================================================================
DROP POLICY IF EXISTS kelas_select_all ON kelas;
DROP POLICY IF EXISTS kelas_admin_insert ON kelas;
DROP POLICY IF EXISTS kelas_admin_update ON kelas;
DROP POLICY IF EXISTS kelas_admin_delete ON kelas;

-- Admin sees all kelas; guru sees own kelas; siswa sees own kelas
CREATE POLICY kelas_select_role_scoped ON kelas
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR id = public.get_my_kelas_id()
    OR EXISTS (
      SELECT 1 FROM siswa s
      WHERE s.kelas_id = kelas.id AND s.user_id = auth.uid()
    )
  );

CREATE POLICY kelas_admin_insert ON kelas
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY kelas_admin_update ON kelas
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY kelas_admin_delete ON kelas
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- SISWA
-- ============================================================================
DROP POLICY IF EXISTS siswa_select_all ON siswa;
DROP POLICY IF EXISTS siswa_admin_insert ON siswa;
DROP POLICY IF EXISTS siswa_admin_or_own_update ON siswa;
DROP POLICY IF EXISTS siswa_admin_delete ON siswa;

-- Admin sees all siswa; guru sees siswa in own kelas; siswa sees own record
CREATE POLICY siswa_select_role_scoped ON siswa
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR kelas_id = public.get_my_kelas_id()
    OR user_id = auth.uid()
  );

CREATE POLICY siswa_admin_insert ON siswa
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY siswa_admin_update ON siswa
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY siswa_admin_delete ON siswa
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- TRANSAKSI
-- ============================================================================
DROP POLICY IF EXISTS transaksi_select_all ON transaksi;
DROP POLICY IF EXISTS transaksi_admin_guru_insert ON transaksi;
DROP POLICY IF EXISTS transaksi_admin_update ON transaksi;
DROP POLICY IF EXISTS transaksi_admin_delete ON transaksi;

-- Admin sees all; guru sees transaksi for siswa in own kelas; siswa sees own
CREATE POLICY transaksi_select_role_scoped ON transaksi
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR siswa_id = public.get_my_siswa_id()
    OR EXISTS (
      SELECT 1 FROM siswa s
      WHERE s.id = transaksi.siswa_id
        AND s.kelas_id = public.get_my_kelas_id()
    )
  );

-- Admin and guru can insert. Guru can only insert for siswa in own kelas.
CREATE POLICY transaksi_admin_guru_insert ON transaksi
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin()
    OR (
      public.is_guru()
      AND EXISTS (
        SELECT 1 FROM siswa s
        WHERE s.id = transaksi.siswa_id
          AND s.kelas_id = public.get_my_kelas_id()
      )
    )
  );

CREATE POLICY transaksi_admin_update ON transaksi
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY transaksi_admin_delete ON transaksi
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- TAHUN_PELAJARAN
-- ============================================================================
DROP POLICY IF EXISTS tp_select_all ON tahun_pelajaran;
DROP POLICY IF EXISTS tp_admin_insert ON tahun_pelajaran;
DROP POLICY IF EXISTS tp_admin_update ON tahun_pelajaran;
DROP POLICY IF EXISTS tp_admin_delete ON tahun_pelajaran;

CREATE POLICY tp_select_all ON tahun_pelajaran
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY tp_admin_insert ON tahun_pelajaran
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY tp_admin_update ON tahun_pelajaran
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY tp_admin_delete ON tahun_pelajaran
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- PENGATURAN
-- ============================================================================
DROP POLICY IF EXISTS pengaturan_select_all ON pengaturan;
DROP POLICY IF EXISTS pengaturan_admin_update ON pengaturan;

CREATE POLICY pengaturan_select_all ON pengaturan
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY pengaturan_admin_update ON pengaturan
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- ============================================================================
-- AKTIVITAS
-- ============================================================================
DROP POLICY IF EXISTS aktivitas_select_all ON aktivitas;
DROP POLICY IF EXISTS aktivitas_admin_delete ON aktivitas;
DROP POLICY IF EXISTS aktivitas_select_own ON aktivitas;

-- Admin sees all aktivitas; users see own aktivitas
CREATE POLICY aktivitas_select_own_or_admin ON aktivitas
  FOR SELECT TO authenticated
  USING (public.is_admin() OR user_id = auth.uid());

CREATE POLICY aktivitas_insert_own ON aktivitas
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY aktivitas_admin_delete ON aktivitas
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- ALUMNI
-- ============================================================================
DROP POLICY IF EXISTS alumni_select_all ON alumni;
DROP POLICY IF EXISTS alumni_admin_insert ON alumni;
DROP POLICY IF EXISTS alumni_admin_update ON alumni;
DROP POLICY IF EXISTS alumni_admin_delete ON alumni;

CREATE POLICY alumni_select_admin ON alumni
  FOR SELECT TO authenticated
  USING (public.is_admin());

CREATE POLICY alumni_admin_insert ON alumni
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY alumni_admin_update ON alumni
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY alumni_admin_delete ON alumni
  FOR DELETE TO authenticated
  USING (public.is_admin());
