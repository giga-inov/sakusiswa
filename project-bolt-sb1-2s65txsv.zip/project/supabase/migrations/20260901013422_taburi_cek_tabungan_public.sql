/*
# Public NISN lookup function for Cek Tabungan

Creates a SECURITY DEFINER RPC function that allows public (anon) users
to look up a single student's tabungan data by NISN — without exposing
the entire students/transactions tables.

Returns: student info + all transactions + summary stats
Only returns data if NISN matches exactly one student.
*/

CREATE OR REPLACE FUNCTION public.cek_tabungan_by_nisn(p_nisn text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_siswa RECORD;
  v_result json;
BEGIN
  -- Find the student by NISN (exact match)
  SELECT s.id, s.nama, s.nis, s.nisn, s.saldo, s.kelas_id,
         k.nama as kelas_nama
  INTO v_siswa
  FROM siswa s
  LEFT JOIN kelas k ON k.id = s.kelas_id
  WHERE s.nisn = p_nisn AND s.status = 'aktif'
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN json_build_object('found', false);
  END IF;

  -- Build result with student info + transactions
  SELECT json_build_object(
    'found', true,
    'siswa', json_build_object(
      'id', v_siswa.id,
      'nama', v_siswa.nama,
      'nis', v_siswa.nis,
      'nisn', v_siswa.nisn,
      'saldo', v_siswa.saldo,
      'kelas_nama', v_siswa.kelas_nama
    ),
    'transaksi', COALESCE(
      (SELECT json_agg(
        json_build_object(
          'id', t.id,
          'tanggal', t.tanggal,
          'jenis', t.jenis,
          'nominal', t.nominal,
          'saldo_setelah', t.saldo_setelah,
          'keterangan', t.keterangan,
          'petugas_nama', t.petugas_nama
        )
        ORDER BY t.created_at DESC
      )
      FROM transaksi t
      WHERE t.siswa_id = v_siswa.id),
      '[]'::json
    )
  ) INTO v_result;

  RETURN v_result;
END;
$$;

-- Grant access to anon and authenticated roles
GRANT EXECUTE ON FUNCTION public.cek_tabungan_by_nisn(text) TO anon, authenticated;
