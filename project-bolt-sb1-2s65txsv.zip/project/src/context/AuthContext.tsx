import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { Profile, Role } from '@/types';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null; profile: Profile | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  logAktivitas: (aksi: string, modul: string, detail: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (uid: string): Promise<{ data: Profile | null; error: string | null }> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', uid)
      .maybeSingle();
    if (error) {
      console.error('Error fetching profile:', error);
      return { data: null, error: error.message };
    }
    return { data: data as Profile | null, error: null };
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user) {
      const { data: p } = await fetchProfile(user.id);
      setProfile(p);
    }
  }, [user, fetchProfile]);

  const logAktivitas = useCallback(async (aksi: string, modul: string, detail: string) => {
    if (!profile) return;
    try {
      await supabase.from('aktivitas').insert({
        aksi,
        modul,
        detail,
        user_id: user?.id,
        nama_user: profile.nama,
        role: profile.role,
      });
    } catch (e) {
      console.error('Failed to log aktivitas:', e);
    }
  }, [profile, user]);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id).then(({ data: p }) => {
          if (mounted) {
            setProfile(p);
            setLoading(false);
          }
        });
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, sess) => {
      (async () => {
        setSession(sess);
        setUser(sess?.user ?? null);
        if (sess?.user) {
          const { data: p } = await fetchProfile(sess.user.id);
          if (mounted) setProfile(p);
        } else {
          if (mounted) setProfile(null);
        }
        if (mounted) setLoading(false);
      })();
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      let msg = error.message;
      if (error.message.includes('Invalid login credentials')) msg = 'Email atau password salah.';
      else if (error.message.includes('Email not confirmed')) msg = 'Email belum dikonfirmasi.';
      else if (error.message.includes('network')) msg = 'Koneksi database bermasalah.';
      else if (error.message.includes('Database error querying schema')) msg = 'Koneksi database bermasalah.';
      return { error: msg, profile: null };
    }
    if (data.user) {
      const { data: p, error: profileError } = await fetchProfile(data.user.id);
      if (profileError) {
        return { error: 'Koneksi database bermasalah.', profile: null };
      }
      if (!p) {
        return { error: 'Akun berhasil login, tetapi profil pengguna belum dikonfigurasi.', profile: null };
      }
      setProfile(p);
      try {
        await supabase.from('aktivitas').insert({
          aksi: 'Login',
          modul: 'Auth',
          detail: `Login berhasil: ${p.email}`,
          user_id: data.user.id,
          nama_user: p.nama,
          role: p.role,
        });
      } catch (e) {
        console.error('Failed to log login:', e);
      }
      return { error: null, profile: p };
    }
    return { error: null, profile: null };
  }, [fetchProfile]);

  const signOut = useCallback(async () => {
    if (profile) {
      try {
        await supabase.from('aktivitas').insert({
          aksi: 'Logout',
          modul: 'Auth',
          detail: `Logout: ${profile.email}`,
          user_id: user?.id,
          nama_user: profile.nama,
          role: profile.role,
        });
      } catch (e) {
        console.error('Failed to log logout:', e);
      }
    }
    await supabase.auth.signOut();
    setProfile(null);
    setSession(null);
    setUser(null);
  }, [profile, user]);

  return (
    <AuthContext.Provider value={{ session, user, profile, loading, signIn, signOut, refreshProfile, logAktivitas }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export function getDashboardPath(role: Role): string {
  switch (role) {
    case 'admin': return '/admin/dashboard';
    case 'guru': return '/guru/dashboard';
    case 'siswa': return '/siswa/dashboard';
    default: return '/login';
  }
}
