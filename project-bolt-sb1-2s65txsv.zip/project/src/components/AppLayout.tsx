import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '@/components/Sidebar';
import { Navbar } from '@/components/Navbar';
import { Phone, Code2 } from 'lucide-react';
import { usePengaturan } from '@/hooks/queries';
import { BRAND } from '@/lib/brand';

export function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { data: pengaturan } = usePengaturan();

  const namaSekolah = pengaturan?.nama_sekolah || BRAND.appName;
  const alamatParts = [pengaturan?.kecamatan, pengaturan?.kabupaten_kota, pengaturan?.provinsi].filter(Boolean);
  const alamatText = alamatParts.length > 0 ? alamatParts.join(' • ') : pengaturan?.alamat || '';

  return (
    <div className="min-h-screen bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="md:pl-64">
        <Navbar onToggleSidebar={() => setSidebarOpen((prev) => !prev)} />
        <main className="min-h-[calc(100vh-4rem)] animate-fade-in">
          <Outlet />
        </main>
        <footer className="border-t border-border/60 bg-muted/30 px-6 py-4">
          <div className="flex flex-col items-center justify-between gap-2 text-xs text-muted-foreground sm:flex-row">
            <p>{namaSekolah}{alamatText ? ` • ${alamatText}` : ''}</p>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <Code2 className="h-3.5 w-3.5 text-primary" />
                Dikembangkan oleh <span className="font-semibold text-primary">GIGA INNOVATION</span>
              </span>
              <a href="tel:081329200985" className="flex items-center gap-1.5 transition-colors hover:text-primary">
                <Phone className="h-3.5 w-3.5" />
                081329200985
              </a>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
