import { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Role } from '@/types';
import { InlineLoader } from '@/components/Loaders';

interface ProtectedRouteProps {
  children: ReactNode;
  roles?: Role[];
}

export function ProtectedRoute({ children, roles }: ProtectedRouteProps) {
  const { session, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <InlineLoader text="Memuat sesi..." />;
  }

  if (!session) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (!profile) {
    return <InlineLoader text="Memuat profil..." />;
  }

  if (roles && !roles.includes(profile.role)) {
    return <Navigate to={`/${profile.role}/dashboard`} replace />;
  }

  if (profile.must_change_password && !location.pathname.includes('ganti-password') && !location.pathname.includes('first-login')) {
    return <Navigate to="/first-login" replace />;
  }

  return <>{children}</>;
}
