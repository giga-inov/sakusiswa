import { PiggyBank } from 'lucide-react';
import { usePengaturan } from '@/hooks/queries';
import { BRAND, getLogoUrl } from '@/lib/brand';
import { cn } from '@/lib/utils';

interface BrandHeaderProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
  className?: string;
  align?: 'center' | 'left';
}

const sizeMap = {
  sm: { box: 'h-10 w-10', icon: 'h-6 w-6', title: 'text-lg', sub: 'text-[10px]', tag: 'text-[10px]' },
  md: { box: 'h-14 w-14', icon: 'h-8 w-8', title: 'text-xl', sub: 'text-xs', tag: 'text-xs' },
  lg: { box: 'h-16 w-16', icon: 'h-9 w-9', title: 'text-3xl', sub: 'text-sm', tag: 'text-xs' },
} as const;

export function BrandHeader({ size = 'md', showTagline = false, className, align = 'center' }: BrandHeaderProps) {
  const { data: pengaturan } = usePengaturan();
  const s = sizeMap[size];
  const appName = pengaturan?.app_name || BRAND.appName;
  const subtitle = pengaturan?.app_subtitle || BRAND.subtitle;
  const tagline = pengaturan?.app_tagline || pengaturan?.slogan || BRAND.tagline;
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;

  return (
    <div className={cn('flex flex-col gap-2', align === 'center' && 'items-center text-center', className)}>
      <div className={cn('flex items-center gap-2.5', align === 'center' && 'justify-center')}>
        {logoUrl ? (
          <img
            src={logoUrl}
            alt={`${appName} logo`}
            className={cn(s.box, 'rounded-2xl object-contain bg-primary/5 p-1 ring-1 ring-primary/20')}
            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
          />
        ) : (
          <div className={cn('flex items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg', s.box)}>
            <PiggyBank className={s.icon} />
          </div>
        )}
        <div className={align === 'center' ? 'text-left' : ''}>
          <h1 className={cn('font-bold leading-none text-primary', s.title)}>{appName}</h1>
          <p className={cn('mt-0.5 text-muted-foreground', s.sub)}>{subtitle}</p>
        </div>
      </div>
      {showTagline && <p className={cn('italic text-muted-foreground', s.tag)}>"{tagline}"</p>}
    </div>
  );
}

export function BrandLogo({ size = 'md', className }: { size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const { data: pengaturan } = usePengaturan();
  const s = sizeMap[size];
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;

  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt="Logo sekolah"
        className={cn(s.box, 'rounded-xl object-contain bg-primary/5 p-1', className)}
        onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
      />
    );
  }
  return (
    <div className={cn('flex items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-md', s.box, className)}>
      <PiggyBank className={s.icon} />
    </div>
  );
}
