import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Wallet, History, GraduationCap, Users, FileBarChart, Settings, LogOut, X, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { usePengaturan } from '@/hooks/queries';
import { BRAND, getLogoUrl } from '@/lib/brand';
import { Role } from '@/types';
import { cn } from '@/lib/utils';

interface NavItem {
  label: string;
  path: string;
  icon: typeof LayoutDashboard;
  roles: Role[];
}

const NAV_ITEMS: NavItem[] = [
  // Admin
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard, roles: ['admin'] },
  { label: 'Entri Tabungan', path: '/admin/input-tabungan', icon: Wallet, roles: ['admin'] },
  { label: 'Riwayat Tabungan', path: '/admin/transaksi', icon: History, roles: ['admin'] },
  { label: 'Siswa', path: '/admin/siswa', icon: GraduationCap, roles: ['admin'] },
  { label: 'Guru & Kelas', path: '/admin/guru-kelas', icon: Users, roles: ['admin'] },
  { label: 'Laporan', path: '/admin/laporan', icon: FileBarChart, roles: ['admin'] },
  { label: 'Pengaturan', path: '/admin/pengaturan', icon: Settings, roles: ['admin'] },

  // Guru
  { label: 'Dashboard', path: '/guru/dashboard', icon: LayoutDashboard, roles: ['guru'] },
  { label: 'Entri Tabungan', path: '/guru/tabungan', icon: Wallet, roles: ['guru'] },
  { label: 'Riwayat Tabungan', path: '/guru/transaksi', icon: History, roles: ['guru'] },
  { label: 'Siswa', path: '/guru/siswa', icon: GraduationCap, roles: ['guru'] },
  { label: 'Laporan', path: '/guru/laporan', icon: FileBarChart, roles: ['guru'] },
  { label: 'Profil', path: '/guru/profil', icon: User, roles: ['guru'] },

  // Siswa
  { label: 'Dashboard', path: '/siswa/dashboard', icon: LayoutDashboard, roles: ['siswa'] },
  { label: 'Saldo Tabungan', path: '/siswa/saldo', icon: Wallet, roles: ['siswa'] },
  { label: 'Riwayat Transaksi', path: '/siswa/transaksi', icon: History, roles: ['siswa'] },
  { label: 'Profil', path: '/siswa/profil', icon: User, roles: ['siswa'] },
];

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

function SidebarBrand() {
  const { data: pengaturan } = usePengaturan();
  const appName = pengaturan?.app_name || BRAND.appName;
  const subtitle = pengaturan?.app_subtitle || BRAND.subtitle;
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;
  return (
    <div className="flex items-center gap-2.5">
      {logoUrl ? (
        <img src={logoUrl} alt={`${appName} logo`} className="h-10 w-10 rounded-xl object-contain bg-primary/5 p-1 ring-1 ring-primary/20" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
      ) : (
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-md">
          <Wallet className="h-6 w-6" />
        </div>
      )}
      <div>
        <h1 className="text-lg font-bold leading-none text-primary">{appName}</h1>
        <p className="text-[10px] text-muted-foreground">{subtitle}</p>
      </div>
    </div>
  );
}

export function Sidebar({ open, onClose }: SidebarProps) {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  if (!profile) return null;

  const items = NAV_ITEMS.filter((item) => item.roles.includes(profile.role));

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-40 bg-black/50 md:hidden" onClick={onClose} />
      )}
      <aside
        className={cn(
          'fixed left-0 top-0 z-50 flex h-screen w-64 flex-col border-r bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex h-16 items-center justify-between border-b px-4">
          <SidebarBrand />
          <button className="md:hidden" onClick={onClose}>
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="space-y-1">
            {items.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    onClick={onClose}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
                        isActive
                          ? 'bg-primary text-primary-foreground shadow-sm'
                          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                      )
                    }
                  >
                    <Icon className="h-5 w-5 shrink-0" />
                    <span>{item.label}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t p-3">
          <button
            onClick={handleSignOut}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-destructive transition-colors hover:bg-destructive/10"
          >
            <LogOut className="h-5 w-5" />
            Logout
          </button>
        </div>
      </aside>
    </>
  );
}
