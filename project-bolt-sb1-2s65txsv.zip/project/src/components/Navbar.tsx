import { LogOut, Moon, Sun, Bell, Search, Menu } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { usePengaturan } from '@/hooks/queries';
import { BRAND, getLogoUrl } from '@/lib/brand';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { getInisial } from '@/lib/format';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useNavigate } from 'react-router-dom';

interface NavbarProps {
  onToggleSidebar: () => void;
}

export function Navbar({ onToggleSidebar }: NavbarProps) {
  const { profile, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const { data: pengaturan } = usePengaturan();

  const roleLabel = profile?.role === 'admin' ? 'Administrator' : profile?.role === 'guru' ? 'Guru' : 'Siswa';
  const namaSekolah = pengaturan?.nama_sekolah || BRAND.appName;
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60 md:px-6">
      <Button variant="ghost" size="icon" className="md:hidden" onClick={onToggleSidebar}>
        <Menu className="h-5 w-5" />
      </Button>

      <div className="flex items-center gap-2.5">
        {logoUrl && (
          <img
            src={logoUrl}
            alt="Logo sekolah"
            className="hidden h-9 w-9 rounded-lg object-contain bg-primary/5 p-0.5 ring-1 ring-primary/20 sm:block"
            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
          />
        )}
        <div className="hidden leading-tight sm:block">
          <p className="text-sm font-bold text-primary">{namaSekolah}</p>
          <p className="text-[11px] text-muted-foreground">{BRAND.subtitle}</p>
        </div>
      </div>

      <div className="flex flex-1 items-center justify-end gap-2">
        <div className="relative hidden lg:block">
          <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Cari siswa, transaksi..."
            className="h-9 w-48 rounded-md border bg-muted/40 pl-8 pr-3 text-sm outline-none transition-all focus:w-72 focus:ring-2 focus:ring-primary/30"
          />
        </div>
      </div>

      <Button variant="ghost" size="icon" onClick={toggleTheme} title="Ganti tema">
        {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
      </Button>

      <Button variant="ghost" size="icon" className="relative">
        <Bell className="h-5 w-5" />
        <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-primary" />
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2 rounded-lg p-1 transition-colors hover:bg-muted">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold">
                {getInisial(profile?.nama || 'U')}
              </AvatarFallback>
            </Avatar>
            <div className="hidden text-left sm:block">
              <p className="text-sm font-medium leading-tight">{profile?.nama}</p>
              <p className="text-xs text-muted-foreground">{roleLabel}</p>
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-52">
          <DropdownMenuLabel>{profile?.email}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => navigate('/ganti-password')}>
            Ganti Password
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => signOut()} className="text-destructive focus:text-destructive">
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
