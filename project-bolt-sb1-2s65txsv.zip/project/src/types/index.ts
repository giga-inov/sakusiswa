export type Role = 'admin' | 'guru' | 'siswa';

export interface Profile {
  id: string;
  email: string;
  nama: string;
  role: Role;
  must_change_password: boolean;
  created_at: string;
}

export interface Kelas {
  id: string;
  nama: string;
  tingkat: number;
  wali_kelas_id: string | null;
  created_at: string;
  guru?: Guru | null;
}

export interface TahunPelajaran {
  id: string;
  nama: string;
  aktif: boolean;
  created_at: string;
}

export interface Guru {
  id: string;
  nama: string;
  nip: string | null;
  email: string | null;
  kelas_id: string | null;
  alamat: string | null;
  no_hp: string | null;
  status: 'aktif' | 'nonaktif';
  user_id: string | null;
  created_at: string;
  kelas?: Kelas | null;
}

export interface Siswa {
  id: string;
  foto: string | null;
  nis: string;
  nisn: string | null;
  nama: string;
  jenis_kelamin: 'L' | 'P';
  tanggal_lahir: string | null;
  alamat: string | null;
  nama_orang_tua: string | null;
  no_hp_orang_tua: string | null;
  kelas_id: string;
  tahun_pelajaran_id: string;
  saldo: number;
  status: 'aktif' | 'nonaktif';
  qr_code: string | null;
  user_id: string | null;
  must_change_password: boolean;
  created_at: string;
  kelas?: Kelas;
  tahun_pelajaran?: TahunPelajaran;
}

export interface Alumni {
  id: string;
  foto: string | null;
  nis: string;
  nisn: string | null;
  nama: string;
  jenis_kelamin: 'L' | 'P';
  tanggal_lahir: string | null;
  alamat: string | null;
  nama_orang_tua: string | null;
  no_hp_orang_tua: string | null;
  kelas_asal: string | null;
  tahun_pelajaran_nama: string | null;
  saldo: number;
  alumni_tahun: string | null;
  created_at: string;
}

export type JenisTransaksi = 'setoran' | 'penarikan' | 'koreksi';

export type TransaksiStatus = 'aktif' | 'dibatalkan';

export interface Transaksi {
  id: string;
  tanggal: string;
  siswa_id: string;
  jenis: JenisTransaksi;
  nominal: number;
  saldo_setelah: number | null;
  petugas_id: string | null;
  petugas_nama: string | null;
  keterangan: string | null;
  bukti: string | null;
  created_at: string;
  status: TransaksiStatus;
  updated_at: string | null;
  updated_by: string | null;
  updated_by_name: string | null;
  cancelled_at: string | null;
  cancelled_by: string | null;
  cancelled_by_name: string | null;
  cancel_reason: string | null;
  siswa?: Siswa;
}

export interface TransaksiEditLog {
  id: string;
  transaksi_id: string | null;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  edited_by: string | null;
  edited_by_name: string | null;
  edited_by_role: string | null;
  edit_reason: string | null;
  change_type: string;
  delete_reason: string | null;
  siswa_nama: string | null;
  siswa_nisn: string | null;
  nominal_before: string | null;
  nominal_after: string | null;
  jenis_trx: string | null;
  tanggal_trx: string | null;
  created_at: string;
}

export interface Aktivitas {
  id: string;
  aksi: string;
  modul: string | null;
  detail: string | null;
  user_id: string | null;
  nama_user: string | null;
  role: Role | null;
  created_at: string;
}

export interface Pengaturan {
  id: number;
  logo_url: string | null;
  nama_sekolah: string;
  alamat: string;
  no_telepon: string | null;
  nama_kepala_sekolah: string | null;
  nama_bendahara: string | null;
  tahun_aktif_id: string | null;
  slogan: string;
  updated_at: string;
  tahun_aktif?: TahunPelajaran | null;
  npsn: string | null;
  kecamatan: string | null;
  kabupaten_kota: string | null;
  provinsi: string | null;
  email_sekolah: string | null;
  app_name: string;
  app_tagline: string;
  app_subtitle: string;
}
