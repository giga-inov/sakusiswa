import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Siswa, Transaksi, Guru, Kelas, TahunPelajaran, Aktivitas, Alumni, Pengaturan } from '@/types';

export function useGuruList() {
  return useQuery({
    queryKey: ['guru'],
    queryFn: async () => {
      const { data, error } = await supabase.from('guru').select('*').order('nama');
      if (error) throw error;
      return data as Guru[];
    },
  });
}

export function useKelasList() {
  return useQuery({
    queryKey: ['kelas'],
    queryFn: async () => {
      const { data, error } = await supabase.from('kelas').select('*').order('tingkat');
      if (error) throw error;
      return data as Kelas[];
    },
  });
}

export function useTahunList() {
  return useQuery({
    queryKey: ['tahun-pelajaran'],
    queryFn: async () => {
      const { data, error } = await supabase.from('tahun_pelajaran').select('*').order('nama', { ascending: false });
      if (error) throw error;
      return data as TahunPelajaran[];
    },
  });
}

export function useSiswaList(filters?: { kelas_id?: string; search?: string; tahun_id?: string; status?: string }) {
  return useQuery({
    queryKey: ['siswa', filters],
    queryFn: async () => {
      let q = supabase.from('siswa').select('*, kelas(*), tahun_pelajaran(*)').order('nama');
      if (filters?.kelas_id) q = q.eq('kelas_id', filters.kelas_id);
      if (filters?.tahun_id) q = q.eq('tahun_pelajaran_id', filters.tahun_id);
      if (filters?.status) q = q.eq('status', filters.status);
      if (filters?.search) {
        q = q.or(`nama.ilike.%${filters.search}%,nis.ilike.%${filters.search}%,nisn.ilike.%${filters.search}%`);
      }
      const { data, error } = await q;
      if (error) throw error;
      return data as Siswa[];
    },
  });
}

export function useAlumniList() {
  return useQuery({
    queryKey: ['alumni'],
    queryFn: async () => {
      const { data, error } = await supabase.from('alumni').select('*').order('nama');
      if (error) throw error;
      return data as Alumni[];
    },
  });
}

export function useTransaksiList(filters?: { siswa_id?: string; kelas_id?: string; jenis?: string; dari?: string; sampai?: string; search?: string; status?: string }) {
  return useQuery({
    queryKey: ['transaksi', filters],
    queryFn: async () => {
      let q = supabase.from('transaksi').select('*, siswa(*, kelas(*))').order('created_at', { ascending: false });
      if (filters?.siswa_id) q = q.eq('siswa_id', filters.siswa_id);
      if (filters?.jenis) q = q.eq('jenis', filters.jenis);
      if (filters?.dari) q = q.gte('tanggal', filters.dari);
      if (filters?.sampai) q = q.lte('tanggal', filters.sampai);
      if (filters?.status) q = q.eq('status', filters.status);
      if (filters?.search) {
        q = q.or(`keterangan.ilike.%${filters.search}%`);
      }
      const { data, error } = await q.limit(500);
      if (error) throw error;
      let result = data as Transaksi[];
      if (filters?.kelas_id) {
        result = result.filter((t) => t.siswa?.kelas_id === filters.kelas_id);
      }
      return result;
    },
  });
}

export function useAktivitasList() {
  return useQuery({
    queryKey: ['aktivitas'],
    queryFn: async () => {
      const { data, error } = await supabase.from('aktivitas').select('*').order('created_at', { ascending: false }).limit(200);
      if (error) throw error;
      return data as Aktivitas[];
    },
  });
}

export function usePengaturan() {
  return useQuery({
    queryKey: ['pengaturan'],
    queryFn: async () => {
      const { data, error } = await supabase.from('pengaturan').select('*, tahun_aktif:tahun_pelajaran(*)').eq('id', 1).maybeSingle();
      if (error) throw error;
      return data as Pengaturan | null;
    },
  });
}

export function useDashboardStats() {
  return useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];

      const [{ count: guruCount }, { count: siswaCount }, { data: siswaSaldo }, { count: transaksiToday }, { data: recentTransaksi }, { data: allSiswa }, { data: todayTrx }] = await Promise.all([
        supabase.from('guru').select('*', { count: 'exact', head: true }),
        supabase.from('siswa').select('*', { count: 'exact', head: true }),
        supabase.from('siswa').select('saldo'),
        supabase.from('transaksi').select('*', { count: 'exact', head: true }).eq('tanggal', today).eq('status', 'aktif'),
        supabase.from('transaksi').select('*, siswa(nama, kelas(nama))').eq('status', 'aktif').order('created_at', { ascending: false }).limit(5),
        supabase.from('siswa').select('saldo, kelas(nama)'),
        supabase.from('transaksi').select('jenis, nominal').eq('tanggal', today).eq('status', 'aktif'),
      ]);

      const totalSaldo = (siswaSaldo || []).reduce((sum, s) => sum + Number(s.saldo || 0), 0);

      const kelasSaldoMap: Record<string, number> = {};
      (allSiswa || []).forEach((s) => {
        const kelasNama = (s as any).kelas?.nama || 'Tanpa Kelas';
        kelasSaldoMap[kelasNama] = (kelasSaldoMap[kelasNama] || 0) + Number(s.saldo || 0);
      });

      const todaySetoran = (todayTrx || []).filter((t) => t.jenis === 'setoran').reduce((s, t) => s + Number(t.nominal), 0);
      const todayPenarikan = (todayTrx || []).filter((t) => t.jenis === 'penarikan').reduce((s, t) => s + Number(t.nominal), 0);

      const last7Days: { tanggal: string; setoran: number; penarikan: number }[] = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const ds = d.toISOString().split('T')[0];
        const { data: tData } = await supabase
          .from('transaksi')
          .select('jenis, nominal')
          .eq('tanggal', ds)
          .eq('status', 'aktif');
        const setoran = (tData || []).filter((t) => t.jenis === 'setoran').reduce((s, t) => s + Number(t.nominal), 0);
        const penarikan = (tData || []).filter((t) => t.jenis === 'penarikan').reduce((s, t) => s + Number(t.nominal), 0);
        last7Days.push({ tanggal: ds, setoran, penarikan });
      }

      return {
        guruCount: guruCount || 0,
        siswaCount: siswaCount || 0,
        totalSaldo,
        transaksiToday: transaksiToday || 0,
        todaySetoran,
        todayPenarikan,
        recentTransaksi: (recentTransaksi || []) as Transaksi[],
        kelasSaldo: Object.entries(kelasSaldoMap).map(([nama, saldo]) => ({ nama, saldo })),
        last7Days,
      };
    },
  });
}

export function useGuruKelas(userId?: string) {
  return useQuery({
    queryKey: ['guru-kelas', userId],
    queryFn: async () => {
      if (!userId) return { guru: null, kelas: null, kelasId: null };
      const { data: guru, error } = await supabase
        .from('guru')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();
      if (error) throw error;
      if (!guru) return { guru: null, kelas: null, kelasId: null };
      const { data: kelas, error: kErr } = await supabase
        .from('kelas')
        .select('*')
        .eq('wali_kelas_id', guru.id)
        .maybeSingle();
      if (kErr) throw kErr;
      return { guru, kelas, kelasId: kelas?.id || null };
    },
    enabled: !!userId,
  });
}

export function useKelasDetail(kelasId: string | null) {
  return useQuery({
    queryKey: ['kelas-detail', kelasId],
    queryFn: async () => {
      if (!kelasId) return null;
      const { data: siswaData, error: sErr } = await supabase
        .from('siswa')
        .select('*, kelas(*)')
        .eq('kelas_id', kelasId)
        .order('nama');
      if (sErr) throw sErr;
      const siswaList = siswaData as Siswa[];

      const siswaIds = siswaList.map((s) => s.id);
      if (siswaIds.length === 0) {
        return { siswaList: [], transaksiList: [], totalSetoran: 0, totalPenarikan: 0, totalSaldo: 0 };
      }

      const { data: trxData, error: tErr } = await supabase
        .from('transaksi')
        .select('*, siswa(nama, kelas(nama))')
        .in('siswa_id', siswaIds)
        .eq('status', 'aktif')
        .order('created_at', { ascending: false })
        .limit(100);
      if (tErr) throw tErr;
      const transaksiList = (trxData || []) as Transaksi[];

      const totalSetoran = transaksiList.filter((t) => t.jenis === 'setoran').reduce((s, t) => s + Number(t.nominal), 0);
      const totalPenarikan = transaksiList.filter((t) => t.jenis === 'penarikan').reduce((s, t) => s + Number(t.nominal), 0);
      const totalSaldo = siswaList.reduce((s, x) => s + Number(x.saldo || 0), 0);

      return { siswaList, transaksiList, totalSetoran, totalPenarikan, totalSaldo };
    },
    enabled: !!kelasId,
  });
}
