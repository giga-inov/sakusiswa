import { useState, useEffect, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useGuruKelas, useKelasList } from '@/hooks/queries';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { EmptyState } from '@/components/Loaders';
import { Wallet, Search, ArrowUpRight, ArrowDownRight, History, Save, Calendar, Plus, AlertTriangle, Edit3, Users, CheckCircle2, CheckSquare, ArrowLeft, TrendingUp, TrendingDown, GraduationCap } from 'lucide-react';
import { formatRupiah, getInisial, formatTanggalSingkat, formatTanggal } from '@/lib/format';
import { Siswa, Transaksi, Kelas } from '@/types';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';

type BatchRow = {
  setoran: string;
  penarikan: string;
  keterangan: string;
  existingId?: string;
};

type DateSummary = {
  tanggal: string;
  siswaMenabung: number;
  totalSetoran: number;
  totalPenarikan: number;
};

export function GuruTabunganPage({ isAdmin = false }: { isAdmin?: boolean }) {
  const { user, profile, logAktivitas } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [historySiswa, setHistorySiswa] = useState<Siswa | null>(null);

  // Admin class selector
  const [adminKelasId, setAdminKelasId] = useState<string | null>(null);
  const { data: kelasList } = useKelasList();

  const { data: guruKelas } = useGuruKelas(user?.id);
  const kelasId = isAdmin ? adminKelasId : guruKelas?.kelasId;
  const kelasNama = isAdmin ? (kelasList?.find((k) => k.id === adminKelasId)?.nama || '-') : (guruKelas?.kelas?.nama || '-');

  // View state: 'list' = date list, 'entri' = entri form for a specific date
  const [view, setView] = useState<'list' | 'entri'>('list');
  const [entriTanggal, setEntriTanggal] = useState(new Date().toISOString().split('T')[0]);
  const [entriMode, setEntriMode] = useState<'baru' | 'edit'>('baru');

  // Batch rows
  const [batchRows, setBatchRows] = useState<Record<string, BatchRow>>({});
  const [batchSaving, setBatchSaving] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [isiSemuaNominal, setIsiSemuaNominal] = useState('');
  const [selectedSiswaIds, setSelectedSiswaIds] = useState<Set<string>>(new Set());
  const [massNominal, setMassNominal] = useState('');

  // Save success summary
  const [saveSummary, setSaveSummary] = useState<{ tanggal: string; siswa: number; setoran: number; penarikan: number } | null>(null);

  const { data: kelasSiswaCounts } = useQuery({
    queryKey: ['kelas-siswa-counts'],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('kelas_id');
      if (error) throw error;
      const counts: Record<string, number> = {};
      for (const s of data || []) {
        counts[s.kelas_id] = (counts[s.kelas_id] || 0) + 1;
      }
      return counts;
    },
  });

  // Fetch date summaries for the list view
  const { data: dateSummaries, isLoading: datesLoading, refetch: refetchDates } = useQuery({
    queryKey: ['tabungan-date-summaries', kelasId],
    queryFn: async () => {
      const { data: siswaIds } = await supabase.from('siswa').select('id').eq('kelas_id', kelasId!);
      const ids = (siswaIds || []).map((s) => s.id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from('transaksi')
        .select('tanggal, siswa_id, jenis, nominal')
        .eq('status', 'aktif')
        .in('siswa_id', ids)
        .order('tanggal', { ascending: false })
        .limit(2000);
      if (error) throw error;
      const byDate: Record<string, DateSummary> = {};
      const siswaPerDate: Record<string, Set<string>> = {};
      for (const t of data || []) {
        if (!byDate[t.tanggal]) {
          byDate[t.tanggal] = { tanggal: t.tanggal, siswaMenabung: 0, totalSetoran: 0, totalPenarikan: 0 };
          siswaPerDate[t.tanggal] = new Set();
        }
        siswaPerDate[t.tanggal].add(t.siswa_id);
        if (t.jenis === 'setoran') byDate[t.tanggal].totalSetoran += Number(t.nominal);
        else byDate[t.tanggal].totalPenarikan += Number(t.nominal);
      }
      for (const tgl of Object.keys(byDate)) {
        byDate[tgl].siswaMenabung = siswaPerDate[tgl].size;
      }
      return Object.values(byDate).sort((a, b) => b.tanggal.localeCompare(a.tanggal));
    },
    enabled: !!kelasId,
  });

  // Fetch siswa list
  const { data: siswaList, isLoading: siswaLoading } = useQuery({
    queryKey: ['guru-tabungan-siswa', kelasId],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('*, kelas(*)').eq('kelas_id', kelasId!).order('nama');
      if (error) throw error;
      return data as Siswa[];
    },
    enabled: !!kelasId,
  });

  // Load existing transactions for the entri date
  const { data: existingTrx, refetch: refetchExisting } = useQuery({
    queryKey: ['batch-existing-trx', kelasId, entriTanggal],
    queryFn: async () => {
      const { data: siswaIds } = await supabase.from('siswa').select('id').eq('kelas_id', kelasId!);
      const ids = (siswaIds || []).map((s) => s.id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from('transaksi')
        .select('*')
        .in('siswa_id', ids)
        .eq('tanggal', entriTanggal)
        .eq('status', 'aktif');
      if (error) throw error;
      return data as Transaksi[];
    },
    enabled: !!kelasId && !!entriTanggal && view === 'entri',
  });

  // Pre-fill batch rows when existing transactions are loaded
  useEffect(() => {
    if (!existingTrx || !siswaList) return;
    const newRows: Record<string, BatchRow> = {};
    for (const t of existingTrx) {
      const existing = newRows[t.siswa_id];
      if (t.jenis === 'setoran') {
        newRows[t.siswa_id] = {
          setoran: String(t.nominal),
          penarikan: existing?.penarikan || '',
          keterangan: t.keterangan || existing?.keterangan || '',
          existingId: t.id,
        };
      } else if (t.jenis === 'penarikan') {
        newRows[t.siswa_id] = {
          setoran: existing?.setoran || '',
          penarikan: String(t.nominal),
          keterangan: t.keterangan || existing?.keterangan || '',
          existingId: existing?.existingId || t.id,
        };
      }
    }
    setBatchRows((prev) => {
      const merged: Record<string, BatchRow> = {};
      for (const s of siswaList) {
        const ex = newRows[s.id];
        const manual = prev[s.id];
        if (manual && (manual.setoran || manual.penarikan)) {
          merged[s.id] = { ...ex, ...manual, existingId: ex?.existingId || manual.existingId };
        } else if (ex) {
          merged[s.id] = ex;
        }
      }
      return merged;
    });
  }, [existingTrx, siswaList]);

  const filtered = (siswaList || []).filter((s) => {
    return s.nama.toLowerCase().includes(search.toLowerCase()) || (s.nisn || '').includes(search) || s.nis.includes(search);
  });

  const totalSaldo = filtered.reduce((sum, s) => sum + Number(s.saldo || 0), 0);

  const batchStats = useMemo(() => {
    let siswaMenabung = 0;
    let totalSetoran = 0;
    let totalPenarikan = 0;
    for (const s of filtered) {
      const row = batchRows[s.id];
      if (!row) continue;
      const setor = Number(row.setoran) || 0;
      const tarik = Number(row.penarikan) || 0;
      if (setor > 0 || tarik > 0) siswaMenabung++;
      totalSetoran += setor;
      totalPenarikan += tarik;
    }
    return { siswaMenabung, totalSetoran, totalPenarikan };
  }, [batchRows, filtered]);

  const openEntriBaru = () => {
    setEntriTanggal(new Date().toISOString().split('T')[0]);
    setEntriMode('baru');
    setBatchRows({});
    setSelectedSiswaIds(new Set());
    setView('entri');
  };

  const openEditTanggal = (tanggal: string) => {
    setEntriTanggal(tanggal);
    setEntriMode('edit');
    setBatchRows({});
    setSelectedSiswaIds(new Set());
    setView('entri');
  };

  const setBatchValue = (siswaId: string, field: keyof BatchRow, value: string) => {
    setBatchRows((prev) => ({
      ...prev,
      [siswaId]: {
        setoran: prev[siswaId]?.setoran || '',
        penarikan: prev[siswaId]?.penarikan || '',
        keterangan: prev[siswaId]?.keterangan || '',
        existingId: prev[siswaId]?.existingId,
        [field]: value,
      } as BatchRow,
    }));
  };

  const handleIsiSemua = () => {
    const n = Number(isiSemuaNominal);
    if (isNaN(n) || n <= 0) { toast.error('Masukkan nominal yang valid'); return; }
    setBatchRows((prev) => {
      const updated = { ...prev };
      for (const s of filtered) {
        const existing = updated[s.id];
        if (!existing || !existing.setoran) {
          updated[s.id] = {
            setoran: String(n),
            penarikan: existing?.penarikan || '',
            keterangan: existing?.keterangan || '',
            existingId: existing?.existingId,
          };
        }
      }
      return updated;
    });
    toast.success(`Nominal ${formatRupiah(n)} diisi ke siswa yang masih kosong`);
    setIsiSemuaNominal('');
  };

  const handleMassIsi = () => {
    const n = Number(massNominal);
    if (isNaN(n) || n <= 0) { toast.error('Masukkan nominal yang valid'); return; }
    if (selectedSiswaIds.size === 0) { toast.error('Pilih siswa terlebih dahulu'); return; }
    setBatchRows((prev) => {
      const updated = { ...prev };
      for (const id of selectedSiswaIds) {
        const existing = updated[id];
        updated[id] = {
          setoran: String(n),
          penarikan: existing?.penarikan || '',
          keterangan: existing?.keterangan || '',
          existingId: existing?.existingId,
        };
      }
      return updated;
    });
    toast.success(`Nominal ${formatRupiah(n)} diisi ke ${selectedSiswaIds.size} siswa terpilih`);
    setMassNominal('');
    setSelectedSiswaIds(new Set());
  };

  const toggleSiswaSelection = (id: string) => {
    setSelectedSiswaIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedSiswaIds.size === filtered.length) {
      setSelectedSiswaIds(new Set());
    } else {
      setSelectedSiswaIds(new Set(filtered.map((s) => s.id)));
    }
  };

  const getSaveEntries = () => {
    return Object.entries(batchRows).filter(([, row]) => {
      const s = Number(row.setoran);
      const p = Number(row.penarikan);
      return (s > 0 || p > 0);
    });
  };

  const handleBatchSaveClick = () => {
    const entries = getSaveEntries();
    if (entries.length === 0) { toast.error('Tidak ada nominal yang diisi'); return; }
    for (const [siswaId, row] of entries) {
      const siswa = siswaList?.find((s) => s.id === siswaId);
      if (!siswa) continue;
      const p = Number(row.penarikan);
      if (p > 0 && p > Number(siswa.saldo || 0)) {
        toast.error(`Saldo ${siswa.nama} tidak mencukupi untuk penarikan`);
        return;
      }
    }
    setConfirmOpen(true);
  };

  const handleBatchSaveConfirm = async () => {
    setConfirmOpen(false);
    const entries = getSaveEntries();
    if (entries.length === 0) return;

    setBatchSaving(true);
    let success = 0;
    let failed = 0;
    let updated = 0;
    try {
      for (const [siswaId, row] of entries) {
        const siswa = siswaList?.find((s) => s.id === siswaId);
        if (!siswa) continue;
        const setoran = Number(row.setoran);
        const penarikan = Number(row.penarikan);
        const ket = row.keterangan || `Tabungan harian oleh ${profile?.nama || 'Guru'}`;

        if (row.existingId) {
          if (setoran > 0) {
            const { error } = await supabase.from('transaksi').update({
              nominal: setoran,
              jenis: 'setoran',
              keterangan: ket,
              petugas_id: user?.id,
              petugas_nama: profile?.nama || 'Guru',
              updated_by: user?.id,
              updated_by_name: profile?.nama,
            }).eq('id', row.existingId);
            if (error) { failed++; toast.error(`Gagal update: ${siswa.nama}`); }
            else { updated++; success++; }
          }
          if (penarikan > 0) {
            const { error } = await supabase.from('transaksi').update({
              nominal: penarikan,
              jenis: 'penarikan',
              keterangan: ket,
              petugas_id: user?.id,
              petugas_nama: profile?.nama || 'Guru',
              updated_by: user?.id,
              updated_by_name: profile?.nama,
            }).eq('id', row.existingId);
            if (error) { failed++; toast.error(`Gagal update: ${siswa.nama}`); }
            else { updated++; success++; }
          }
        } else {
          if (setoran > 0) {
            const { data: insData, error } = await supabase.from('transaksi').insert({
              siswa_id: siswaId,
              tanggal: entriTanggal,
              jenis: 'setoran',
              nominal: setoran,
              keterangan: ket,
              petugas_id: user?.id,
              petugas_nama: profile?.nama || 'Guru',
            }).select('id').maybeSingle();
            if (error) { failed++; toast.error(`Gagal: ${siswa.nama}`); }
            else {
              success++;
              if (insData) {
                await supabase.from('transaksi_edit_log').insert({
                  transaksi_id: insData.id,
                  field_name: 'nominal',
                  old_value: null,
                  new_value: String(setoran),
                  edited_by: user?.id || null,
                  edited_by_name: profile?.nama || null,
                  edited_by_role: profile?.role || null,
                  edit_reason: 'Input tabungan harian',
                  change_type: 'INPUT',
                  siswa_nama: siswa.nama,
                  siswa_nisn: siswa.nisn || null,
                  nominal_after: String(setoran),
                  jenis_trx: 'setoran',
                  tanggal_trx: entriTanggal,
                });
              }
            }
          }
          if (penarikan > 0) {
            const { data: insData, error } = await supabase.from('transaksi').insert({
              siswa_id: siswaId,
              tanggal: entriTanggal,
              jenis: 'penarikan',
              nominal: penarikan,
              keterangan: ket,
              petugas_id: user?.id,
              petugas_nama: profile?.nama || 'Guru',
            }).select('id').maybeSingle();
            if (error) { failed++; toast.error(`Gagal: ${siswa.nama}`); }
            else {
              success++;
              if (insData) {
                await supabase.from('transaksi_edit_log').insert({
                  transaksi_id: insData.id,
                  field_name: 'nominal',
                  old_value: null,
                  new_value: String(penarikan),
                  edited_by: user?.id || null,
                  edited_by_name: profile?.nama || null,
                  edited_by_role: profile?.role || null,
                  edit_reason: 'Input tabungan harian',
                  change_type: 'INPUT',
                  siswa_nama: siswa.nama,
                  siswa_nisn: siswa.nisn || null,
                  nominal_after: String(penarikan),
                  jenis_trx: 'penarikan',
                  tanggal_trx: entriTanggal,
                });
              }
            }
          }
        }
      }
      await logAktivitas('Input Tabungan', 'Tabungan', `Batch: ${success} transaksi (${updated} update), ${failed} gagal`);
      // Recompute saldo_setelah for each affected student
      for (const [siswaId] of getSaveEntries()) {
        await supabase.rpc('recompute_saldo_setelah', { p_siswa_id: siswaId });
      }
      toast.success(`Tabungan tanggal ${formatTanggalSingkat(entriTanggal)} berhasil disimpan.`);
      setSaveSummary({ tanggal: entriTanggal, siswa: batchStats.siswaMenabung, setoran: batchStats.totalSetoran, penarikan: batchStats.totalPenarikan });
      setBatchRows({});
      refetchExisting();
      refetchDates();
      queryClient.invalidateQueries({ queryKey: ['guru-today-stats'] });
      queryClient.invalidateQueries({ queryKey: ['guru-transaksi'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
      queryClient.invalidateQueries({ queryKey: ['guru-recent-dates'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setBatchSaving(false);
  };

  const computeSaldoSetelah = (s: Siswa, row: BatchRow | undefined): number => {
    const setor = Number(row?.setoran) || 0;
    const tarik = Number(row?.penarikan) || 0;
    return Number(s.saldo || 0) + setor - tarik;
  };

  const { data: historyData, isLoading: historyLoading } = useQuery({
    queryKey: ['siswa-history', historySiswa?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transaksi')
        .select('*')
        .eq('siswa_id', historySiswa!.id)
        .eq('status', 'aktif')
        .order('tanggal', { ascending: true })
        .order('created_at', { ascending: true })
        .limit(100);
      if (error) throw error;
      return data as Transaksi[];
    },
    enabled: !!historySiswa?.id,
  });

  if (!kelasId && !siswaLoading) {
    if (isAdmin) {
      return (
        <>
          <PageHeader title="Entri Tabungan" description="Pilih kelas untuk mulai mengentri tabungan siswa" />
          <div className="p-6 space-y-4">
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="p-6">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3">
                    <Calendar className="h-6 w-6 text-primary" />
                    <div>
                      <p className="text-base font-semibold">Entri Tabungan</p>
                      <p className="text-sm text-muted-foreground">Pilih kelas untuk melihat dan mengentri tabungan</p>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">Pilih Kelas</label>
                    <select value={adminKelasId || ''} onChange={(e) => { setAdminKelasId(e.target.value || null); setBatchRows({}); setSelectedSiswaIds(new Set()); }} className="h-10 w-48 rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                      <option value="">-- Pilih Kelas --</option>
                      {(kelasList || []).map((k) => {
                        const count = kelasSiswaCounts?.[k.id] || 0;
                        return <option key={k.id} value={k.id}>{k.nama} ({count} siswa)</option>;
                      })}
                    </select>
                  </div>
                </div>
                {(kelasList || []).length === 0 && (
                  <p className="mt-4 text-sm text-amber-600">Data kelas belum tersedia di database. Tambahkan kelas terlebih dahulu.</p>
                )}
              </CardContent>
            </Card>
            <EmptyState icon={<Wallet className="h-6 w-6" />} title="Belum ada kelas dipilih" description="Pilih kelas di atas untuk mulai mengentri tabungan." />
          </div>
        </>
      );
    }
    return (
      <>
        <PageHeader title="Entri Tabungan" description="Kelola setoran dan penarikan siswa" />
        <div className="p-6">
          <EmptyState icon={<Wallet className="h-6 w-6" />} title="Belum ada kelas ditugaskan" description="Hubungi admin untuk menentukan kelas yang Anda ampu." />
        </div>
      </>
    );
  }

  // ============ ENTRI VIEW (form input for a specific date) ============
  if (view === 'entri') {
    const saveEntries = getSaveEntries();
    return (
      <>
        <PageHeader
          title={entriMode === 'baru' ? 'Entri Tabungan Baru' : 'Edit Tabungan'}
          description={`Kelas ${kelasNama} • ${formatTanggal(entriTanggal)}`}
          action={
            <Button variant="outline" className="gap-2" onClick={() => { setView('list'); setSaveSummary(null); }}>
              <ArrowLeft className="h-4 w-4" /> Kembali ke Daftar Tanggal
            </Button>
          }
        />

        <div className="p-6 space-y-4">
          {/* Save success summary */}
          {saveSummary && (
            <Card className="border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30">
                    <CheckCircle2 className="h-7 w-7" />
                  </div>
                  <div>
                    <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400">Tabungan berhasil disimpan</p>
                    <p className="text-sm text-muted-foreground">Tanggal {formatTanggal(saveSummary.tanggal)}</p>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="rounded-lg border bg-card p-3">
                    <p className="text-xs text-muted-foreground">Siswa Menabung</p>
                    <p className="text-xl font-bold">{saveSummary.siswa} siswa</p>
                  </div>
                  <div className="rounded-lg border bg-card p-3">
                    <p className="text-xs text-muted-foreground">Total Setoran</p>
                    <p className="text-xl font-bold text-primary">{formatRupiah(saveSummary.setoran)}</p>
                  </div>
                  <div className="rounded-lg border bg-card p-3">
                    <p className="text-xs text-muted-foreground">Total Penarikan</p>
                    <p className="text-xl font-bold text-destructive">{formatRupiah(saveSummary.penarikan)}</p>
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" className="gap-2" onClick={() => { setView('list'); setSaveSummary(null); refetchDates(); }}>
                    <ArrowLeft className="h-4 w-4" /> Kembali ke Daftar Tanggal
                  </Button>
                  <Button variant="outline" className="gap-2" onClick={() => setSaveSummary(null)}>
                    Lihat Detail
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Date and class info */}
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-4">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-medium">Tanggal Tabungan</p>
                    <p className="text-xs text-muted-foreground">Isi nominal untuk siswa yang menabung hari itu</p>
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium">Tanggal:</label>
                    <input type="date" value={entriTanggal} onChange={(e) => { setEntriTanggal(e.target.value); setBatchRows({}); }} className="h-9 rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span>Guru: <span className="font-medium text-foreground">{profile?.nama || '-'}</span></span>
                    <span>Kelas: <span className="font-medium text-foreground">{kelasNama}</span></span>
                  </div>
                </div>
              </div>
              {isAdmin && (
                <div className="mt-3 border-t pt-3">
                  <label className="text-xs font-medium text-muted-foreground">Pilih Kelas</label>
                  <select value={adminKelasId || ''} onChange={(e) => { setAdminKelasId(e.target.value || null); setBatchRows({}); setSelectedSiswaIds(new Set()); }} className="mt-1 h-9 w-full max-w-xs rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                    <option value="">-- Pilih Kelas --</option>
                    {(kelasList || []).map((k) => {
                      const count = kelasSiswaCounts?.[k.id] || 0;
                      return <option key={k.id} value={k.id}>{k.nama} ({count} siswa)</option>;
                    })}
                  </select>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Summary cards */}
          <div className="grid gap-3 grid-cols-2 lg:grid-cols-5">
            <Card><CardContent className="p-4">
              <div className="flex items-center gap-2"><Users className="h-4 w-4 text-muted-foreground" /><p className="text-xs text-muted-foreground">Total Siswa</p></div>
              <p className="mt-1 text-xl font-bold">{filtered.length}</p>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-primary" /><p className="text-xs text-muted-foreground">Siswa Menabung</p></div>
              <p className="mt-1 text-xl font-bold text-primary">{batchStats.siswaMenabung}</p>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <div className="flex items-center gap-2"><TrendingUp className="h-4 w-4 text-primary" /><p className="text-xs text-muted-foreground">Setoran</p></div>
              <p className="mt-1 text-xl font-bold text-primary">{formatRupiah(batchStats.totalSetoran)}</p>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <div className="flex items-center gap-2"><TrendingDown className="h-4 w-4 text-destructive" /><p className="text-xs text-muted-foreground">Penarikan</p></div>
              <p className="mt-1 text-xl font-bold text-destructive">{formatRupiah(batchStats.totalPenarikan)}</p>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <div className="flex items-center gap-2"><Wallet className="h-4 w-4 text-emerald-600" /><p className="text-xs text-muted-foreground">Total Saldo Kelas</p></div>
              <p className="mt-1 text-xl font-bold text-emerald-600">{formatRupiah(totalSaldo)}</p>
            </CardContent></Card>
          </div>

          {/* Search and mass actions */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nama, NIS, atau NISN..." className="h-10 w-full rounded-lg border bg-background pl-10 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" size="sm" className="gap-1" onClick={toggleSelectAll}>
                <CheckSquare className="h-4 w-4" /> {selectedSiswaIds.size === filtered.length && filtered.length > 0 ? 'Batal Pilih' : 'Pilih Semua'}
              </Button>
              <input type="number" value={massNominal} onChange={(e) => setMassNominal(e.target.value)} placeholder="Nominal massal" className="h-9 w-32 rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              <Button variant="outline" size="sm" className="gap-1 text-primary" onClick={handleMassIsi} disabled={selectedSiswaIds.size === 0}>
                <Users className="h-4 w-4" /> Isi Massal {selectedSiswaIds.size > 0 && `(${selectedSiswaIds.size})`}
              </Button>
              <div className="h-4 w-px bg-border" />
              <input type="number" value={isiSemuaNominal} onChange={(e) => setIsiSemuaNominal(e.target.value)} placeholder="Nominal" className="h-9 w-28 rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              <Button variant="outline" size="sm" className="gap-1" onClick={handleIsiSemua}><CheckCircle2 className="h-4 w-4" /> Isi Semua</Button>
            </div>
          </div>

          {/* Student table */}
          <Card>
            <CardContent className="p-0">
              {siswaLoading ? <div className="p-4 text-sm text-muted-foreground">Memuat data siswa...</div> : filtered.length === 0 ? (
                <EmptyState icon={<Wallet className="h-6 w-6" />} title="Belum ada siswa" description={`Kelas ${kelasNama} belum memiliki siswa.`} />
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                      <tr>
                        <th className="px-3 py-3 font-medium">No</th>
                        <th className="px-2 py-3 font-medium"><input type="checkbox" checked={selectedSiswaIds.size === filtered.length && filtered.length > 0} onChange={toggleSelectAll} className="h-4 w-4 rounded border-border accent-primary" /></th>
                        <th className="px-3 py-3 font-medium">Nama Siswa</th>
                        <th className="px-3 py-3 font-medium">NISN</th>
                        <th className="px-3 py-3 font-medium">Saldo Saat Ini</th>
                        <th className="px-3 py-3 font-medium text-primary">Setoran</th>
                        <th className="px-3 py-3 font-medium text-destructive">Penarikan</th>
                        <th className="px-3 py-3 font-medium">Saldo Setelah</th>
                        <th className="px-3 py-3 font-medium">Keterangan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {filtered.map((s, idx) => {
                        const row = batchRows[s.id] || { setoran: '', penarikan: '', keterangan: '' };
                        const saldoSetelah = computeSaldoSetelah(s, row);
                        const hasExisting = !!row.existingId;
                        return (
                          <tr key={s.id} className={`hover:bg-muted/30 ${hasExisting ? 'bg-amber-50/50 dark:bg-amber-950/10' : ''} ${selectedSiswaIds.has(s.id) ? 'bg-primary/5' : ''}`}>
                            <td className="px-3 py-3 text-xs text-muted-foreground">{idx + 1}</td>
                            <td className="px-2 py-3"><input type="checkbox" checked={selectedSiswaIds.has(s.id)} onChange={() => toggleSiswaSelection(s.id)} className="h-4 w-4 rounded border-border accent-primary" /></td>
                            <td className="px-3 py-3">
                              <div className="flex items-center gap-2">
                                <Avatar className="h-7 w-7">{s.foto ? <img src={s.foto} alt={s.nama} className="h-full w-full rounded-full object-cover" /> : <AvatarFallback className="bg-primary/10 text-primary text-[10px]">{getInisial(s.nama)}</AvatarFallback>}</Avatar>
                                <div><p className="font-medium">{s.nama}</p>{hasExisting && <p className="text-[10px] text-amber-600 flex items-center gap-0.5"><Edit3 className="h-2.5 w-2.5" /> Edit</p>}</div>
                              </div>
                            </td>
                            <td className="px-3 py-3 text-xs text-muted-foreground">{s.nisn || '-'}</td>
                            <td className="px-3 py-3 text-xs font-medium text-muted-foreground">{formatRupiah(s.saldo)}</td>
                            <td className="px-3 py-3">
                              <input type="number" value={row.setoran} onChange={(e) => setBatchValue(s.id, 'setoran', e.target.value)} placeholder="0" className="h-9 w-24 rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                            </td>
                            <td className="px-3 py-3">
                              <input type="number" value={row.penarikan} onChange={(e) => setBatchValue(s.id, 'penarikan', e.target.value)} placeholder="0" className="h-9 w-24 rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                            </td>
                            <td className="px-3 py-3 text-xs font-semibold text-primary">{formatRupiah(saldoSetelah)}</td>
                            <td className="px-3 py-3">
                              <input value={row.keterangan} onChange={(e) => setBatchValue(s.id, 'keterangan', e.target.value)} placeholder="Opsional" className="h-9 w-28 rounded-lg border bg-background px-2 text-xs outline-none focus:ring-2 focus:ring-primary/30" />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <div className="flex flex-col gap-3 border-t p-4 sm:flex-row sm:items-center sm:justify-between">
                    <p className="text-sm text-muted-foreground">
                      {saveEntries.length > 0 ? (
                        <>{saveEntries.length} siswa akan disimpan • Total setoran: <span className="font-semibold text-primary">{formatRupiah(batchStats.totalSetoran)}</span></>
                      ) : 'Isi nominal setoran atau penarikan untuk siswa yang menabung'}
                    </p>
                    <Button onClick={handleBatchSaveClick} disabled={batchSaving || saveEntries.length === 0} className="gap-2">
                      <Save className="h-4 w-4" /> {batchSaving ? 'Menyimpan...' : 'Simpan Tabungan'}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Confirmation dialog */}
        <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-amber-600" /> Konfirmasi Simpan</DialogTitle>
              <DialogDescription>
                Anda akan menyimpan tabungan untuk <span className="font-semibold text-foreground">{saveEntries.length} siswa</span> dengan total setoran <span className="font-semibold text-primary">{formatRupiah(batchStats.totalSetoran)}</span>{batchStats.totalPenarikan > 0 && <> dan total penarikan <span className="font-semibold text-destructive">{formatRupiah(batchStats.totalPenarikan)}</span></>} pada tanggal <span className="font-semibold text-foreground">{formatTanggal(entriTanggal)}</span>. Lanjutkan?
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setConfirmOpen(false)}>Batal</Button>
              <Button onClick={handleBatchSaveConfirm} disabled={batchSaving} className="gap-2">
                {batchSaving ? 'Menyimpan...' : 'Ya, Simpan'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* History dialog */}
        <Dialog open={!!historySiswa} onOpenChange={(v) => !v && setHistorySiswa(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><History className="h-5 w-5 text-primary" /> Riwayat Tabungan</DialogTitle>
              <DialogDescription>{historySiswa?.nama} • NISN: {historySiswa?.nisn || '-'} • Kelas: {historySiswa?.kelas?.nama || '-'} • Saldo: <span className="font-semibold text-primary">{formatRupiah(historySiswa?.saldo || 0)}</span></DialogDescription>
            </DialogHeader>
            {historyLoading ? (
              <div className="py-8 text-center text-sm text-muted-foreground">Memuat riwayat...</div>
            ) : (historyData || []).length === 0 ? (
              <EmptyState icon={<History className="h-6 w-6" />} title="Belum ada transaksi" description="Riwayat transaksi siswa ini akan muncul di sini." />
            ) : (
              <div className="max-h-[60vh] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 border-b bg-card text-left text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 font-medium">Tanggal</th>
                      <th className="px-3 py-2 font-medium text-primary">Setoran</th>
                      <th className="px-3 py-2 font-medium text-destructive">Penarikan</th>
                      <th className="px-3 py-2 font-medium">Keterangan</th>
                      <th className="px-3 py-2 font-medium">Saldo</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {(() => {
                      const sorted = [...(historyData || [])].sort((a, b) => new Date(a.tanggal).getTime() - new Date(b.tanggal).getTime() || new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
                      return sorted.map((t) => {
                        const isSetoran = t.jenis === 'setoran';
                        return (
                          <tr key={t.id} className="hover:bg-muted/30">
                            <td className="px-3 py-2 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                            <td className="px-3 py-2 font-medium text-primary">{isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                            <td className="px-3 py-2 font-medium text-destructive">{!isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                            <td className="px-3 py-2 text-xs text-muted-foreground">{t.keterangan || '-'}</td>
                            <td className="px-3 py-2 font-semibold">{formatRupiah(t.saldo_setelah || 0)}</td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </>
    );
  }

  // ============ LIST VIEW (default - shows dates with transactions) ============
  return (
    <>
      <PageHeader
        title="Entri Tabungan"
        description={`Kelas ${kelasNama} • Guru: ${profile?.nama || '-'}`}
        action={
          <Button className="gap-2" onClick={openEntriBaru}>
            <Plus className="h-4 w-4" /> Entri Tabungan Baru
          </Button>
        }
      />

      <div className="p-6 space-y-4">
        {isAdmin && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-4">
              <label className="text-sm font-medium">Pilih Kelas</label>
              <select value={adminKelasId || ''} onChange={(e) => { setAdminKelasId(e.target.value || null); }} className="mt-1 h-9 w-full max-w-xs rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">-- Pilih Kelas --</option>
                {(kelasList || []).map((k) => {
                  const count = kelasSiswaCounts?.[k.id] || 0;
                  return <option key={k.id} value={k.id}>{k.nama} ({count} siswa)</option>;
                })}
              </select>
            </CardContent>
          </Card>
        )}

        {/* Daftar Tanggal Tabungan */}
        <Card>
          <CardContent className="p-0">
            <div className="border-b p-4">
              <h3 className="font-semibold">Daftar Tanggal Tabungan</h3>
              <p className="text-sm text-muted-foreground">Klik tanggal untuk melihat atau mengedit tabungan</p>
            </div>
            {datesLoading ? (
              <div className="p-8 text-center text-sm text-muted-foreground">Memuat data...</div>
            ) : !dateSummaries || dateSummaries.length === 0 ? (
              <EmptyState
                icon={<Calendar className="h-6 w-6" />}
                title="Belum ada tabungan"
                description="Klik 'Entri Tabungan Baru' untuk mulai mencatat tabungan siswa."
              />
            ) : (
              <div className="divide-y">
                {dateSummaries.map((d) => (
                  <button
                    key={d.tanggal}
                    onClick={() => openEditTanggal(d.tanggal)}
                    className="flex w-full items-center justify-between p-4 transition-colors hover:bg-muted/50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                        <Calendar className="h-6 w-6" />
                      </div>
                      <div className="text-left">
                        <p className="font-semibold">{formatTanggal(d.tanggal)}</p>
                        <p className="text-sm text-muted-foreground">{d.siswaMenabung} siswa menabung</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-bold text-primary">{formatRupiah(d.totalSetoran)}</p>
                        {d.totalPenarikan > 0 && <p className="text-xs text-destructive">-{formatRupiah(d.totalPenarikan)}</p>}
                      </div>
                      <span className="rounded-lg border px-3 py-1.5 text-sm font-medium text-primary transition-colors hover:bg-primary/10">
                        Lihat/Edit
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick stats */}
        <div className="grid gap-4 sm:grid-cols-2">
          <Card>
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Wallet className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Saldo Kelas</p>
                <p className="text-2xl font-bold">{formatRupiah(totalSaldo)}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30">
                <GraduationCap className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Jumlah Siswa</p>
                <p className="text-2xl font-bold">{siswaList?.length || 0}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* History dialog */}
      <Dialog open={!!historySiswa} onOpenChange={(v) => !v && setHistorySiswa(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><History className="h-5 w-5 text-primary" /> Riwayat Tabungan</DialogTitle>
            <DialogDescription>{historySiswa?.nama} • NISN: {historySiswa?.nisn || '-'} • Saldo: <span className="font-semibold text-primary">{formatRupiah(historySiswa?.saldo || 0)}</span></DialogDescription>
          </DialogHeader>
          {historyLoading ? (
            <div className="py-8 text-center text-sm text-muted-foreground">Memuat riwayat...</div>
          ) : (historyData || []).length === 0 ? (
            <EmptyState icon={<History className="h-6 w-6" />} title="Belum ada transaksi" />
          ) : (
            <div className="max-h-[60vh] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 border-b bg-card text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 font-medium">Tanggal</th>
                    <th className="px-3 py-2 font-medium text-primary">Setoran</th>
                    <th className="px-3 py-2 font-medium text-destructive">Penarikan</th>
                    <th className="px-3 py-2 font-medium">Saldo</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {[...(historyData || [])].sort((a, b) => new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime() || new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).map((t) => {
                    const isSetoran = t.jenis === 'setoran';
                    return (
                      <tr key={t.id} className="hover:bg-muted/30">
                        <td className="px-3 py-2 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                        <td className="px-3 py-2 font-medium text-primary">{isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                        <td className="px-3 py-2 font-medium text-destructive">{!isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                        <td className="px-3 py-2 font-semibold">{formatRupiah(t.saldo_setelah || 0)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
