import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useGuruKelas, useKelasList } from '@/hooks/queries';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { EmptyState } from '@/components/Loaders';
import { Plus, ArrowLeftRight, ArrowUpRight, ArrowDownRight, ChevronLeft, ChevronRight, Search, Pencil, Eye, Ban, History, CheckCircle2, XCircle, AlertTriangle, RotateCcw, Trash2, Edit3 } from 'lucide-react';
import { formatRupiah, formatTanggalSingkat, formatWaktu } from '@/lib/format';
import { JenisTransaksi, Transaksi, Siswa, TransaksiEditLog } from '@/types';
import { toast } from 'sonner';

const PAGE_SIZE = 15;

export function GuruTransaksiPage({ isAdmin = false }: { isAdmin?: boolean }) {
  const { user, profile, logAktivitas } = useAuth();
  const queryClient = useQueryClient();
  const [adminKelasFilter, setAdminKelasFilter] = useState<string>('');
  const [filters, setFilters] = useState<{ jenis?: string; dari?: string; sampai?: string; siswa_id?: string; status?: string }>({});
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ siswa_id: '', jenis: 'setoran' as JenisTransaksi, nominal: '', tanggal: new Date().toISOString().split('T')[0], keterangan: '' });

  // Edit state
  const [editTrx, setEditTrx] = useState<Transaksi | null>(null);
  const [editForm, setEditForm] = useState({ tanggal: '', jenis: 'setoran' as JenisTransaksi, nominal: '', keterangan: '' });
  const [editReason, setEditReason] = useState('');
  const [editSaving, setEditSaving] = useState(false);
  const [editConfirm, setEditConfirm] = useState(false);

  // Cancel state
  const [cancelTrx, setCancelTrx] = useState<Transaksi | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelSaving, setCancelSaving] = useState(false);

  // Delete state
  const [deleteTrx, setDeleteTrx] = useState<Transaksi | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  const [deleteSaving, setDeleteSaving] = useState(false);

  // History per student
  const [historySiswa, setHistorySiswa] = useState<Siswa | null>(null);
  const [historyData, setHistoryData] = useState<Transaksi[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Edit log viewer
  const [logTrx, setLogTrx] = useState<Transaksi | null>(null);
  const [logData, setLogData] = useState<TransaksiEditLog[]>([]);
  const [logLoading, setLogLoading] = useState(false);

  const { data: guruKelas } = useGuruKelas(user?.id);
  const kelasId = isAdmin ? (adminKelasFilter || undefined) : guruKelas?.kelasId;
  const { data: kelasList } = useKelasList();

  const { data: siswaList } = useQuery({
    queryKey: ['guru-siswa-for-trx', kelasId, isAdmin],
    queryFn: async () => {
      let q = supabase.from('siswa').select('*, kelas(*)').order('nama');
      if (kelasId) q = q.eq('kelas_id', kelasId);
      const { data, error } = await q;
      if (error) throw error;
      return data as Siswa[];
    },
    enabled: isAdmin || !!guruKelas?.kelasId,
  });

  const { data: transaksiList, isLoading, refetch } = useQuery({
    queryKey: ['guru-transaksi-list', kelasId, filters, isAdmin],
    queryFn: async () => {
      let siswaIds: string[] = [];
      if (kelasId) {
        const { data: ids } = await supabase.from('siswa').select('id').eq('kelas_id', kelasId);
        siswaIds = (ids || []).map((s) => s.id);
      } else {
        const { data: ids } = await supabase.from('siswa').select('id');
        siswaIds = (ids || []).map((s) => s.id);
      }
      if (siswaIds.length === 0) return [];
      let q = supabase.from('transaksi').select('*, siswa(nama, nisn, kelas(nama))').in('siswa_id', siswaIds).order('created_at', { ascending: false });
      if (filters.siswa_id) q = q.eq('siswa_id', filters.siswa_id);
      if (filters.jenis) q = q.eq('jenis', filters.jenis);
      if (filters.status) q = q.eq('status', filters.status);
      if (filters.dari) q = q.gte('tanggal', filters.dari);
      if (filters.sampai) q = q.lte('tanggal', filters.sampai);
      const { data, error } = await q.limit(500);
      if (error) throw error;
      return data as Transaksi[];
    },
    enabled: isAdmin || !!guruKelas?.kelasId,
  });

  // Fetch which transactions have been edited
  const { data: editedTrxIds } = useQuery({
    queryKey: ['edited-trx-ids', transaksiList?.map((t) => t.id)],
    queryFn: async () => {
      const ids = (transaksiList || []).map((t) => t.id);
      if (ids.length === 0) return new Set<string>();
      const { data, error } = await supabase
        .from('transaksi_edit_log')
        .select('transaksi_id')
        .in('transaksi_id', ids)
        .eq('change_type', 'EDIT');
      if (error) return new Set<string>();
      return new Set((data || []).map((d) => d.transaksi_id).filter(Boolean) as string[]);
    },
    enabled: !!(transaksiList && transaksiList.length > 0),
  });

  const filtered = (transaksiList || []).filter((t) => {
    if (!search) return true;
    const nama = t.siswa?.nama || '';
    const nisn = t.siswa?.nisn || '';
    return nama.toLowerCase().includes(search.toLowerCase()) || nisn.includes(search);
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const totalSetoran = filtered.filter((t) => t.jenis === 'setoran' && t.status === 'aktif').reduce((s, t) => s + Number(t.nominal), 0);
  const totalPenarikan = filtered.filter((t) => t.jenis === 'penarikan' && t.status === 'aktif').reduce((s, t) => s + Number(t.nominal), 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.siswa_id) { toast.error('Pilih siswa'); return; }
    const n = Number(form.nominal);
    if (isNaN(n) || n <= 0) { toast.error('Nominal harus angka positif'); return; }
    const selectedSiswa = siswaList?.find((s) => s.id === form.siswa_id);
    if (form.jenis === 'penarikan' && selectedSiswa && n > selectedSiswa.saldo) {
      toast.error('Saldo siswa tidak mencukupi');
      return;
    }
    setSaving(true);
    try {
      const { error } = await supabase.from('transaksi').insert({
        siswa_id: form.siswa_id, jenis: form.jenis, nominal: n,
        tanggal: form.tanggal, keterangan: form.keterangan || `${form.jenis}`,
        petugas_id: user?.id, petugas_nama: profile?.nama || 'Guru',
        status: 'aktif',
      });
      if (error) throw error;
      // Log INPUT entry in audit trail
      const { data: insertedTrx } = await supabase.from('transaksi').select('id').eq('siswa_id', form.siswa_id).order('created_at', { ascending: false }).limit(1).maybeSingle();
      if (insertedTrx) {
        await supabase.from('transaksi_edit_log').insert({
          transaksi_id: insertedTrx.id,
          field_name: 'nominal',
          old_value: null,
          new_value: String(n),
          edited_by: user?.id || null,
          edited_by_name: profile?.nama || null,
          edited_by_role: profile?.role || null,
          edit_reason: 'Input awal transaksi',
          change_type: 'INPUT',
          siswa_nama: selectedSiswa?.nama || null,
          siswa_nisn: selectedSiswa?.nisn || null,
          nominal_after: String(n),
          jenis_trx: form.jenis,
          tanggal_trx: form.tanggal,
        });
      }
      await logAktivitas('Tambah', 'Transaksi', `${form.jenis}: ${formatRupiah(n)} untuk ${selectedSiswa?.nama || ''}`);
      toast.success('Transaksi berhasil ditambahkan');
      setOpen(false);
      setForm({ siswa_id: '', jenis: 'setoran', nominal: '', tanggal: new Date().toISOString().split('T')[0], keterangan: '' });
      refetch();
      queryClient.invalidateQueries({ queryKey: ['guru-tabungan-siswa'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setSaving(false);
  };

  const openEdit = (t: Transaksi) => {
    setEditTrx(t);
    setEditForm({
      tanggal: t.tanggal,
      jenis: t.jenis,
      nominal: String(t.nominal),
      keterangan: t.keterangan || '',
    });
    setEditReason('');
    setEditConfirm(false);
  };

  const handleEditConfirm = () => {
    if (!editReason.trim()) { toast.error('Alasan perubahan wajib diisi'); return; }
    if (!editForm.tanggal) { toast.error('Tanggal wajib diisi'); return; }
    const n = Number(editForm.nominal);
    if (isNaN(n) || n <= 0) { toast.error('Nominal harus angka positif'); return; }
    if (editForm.jenis === 'penarikan' && editTrx) {
      const otherActiveSaldo = (transaksiList || []).filter((t) => t.siswa_id === editTrx.siswa_id && t.id !== editTrx.id && t.status === 'aktif').reduce((s, t) => s + (t.jenis === 'setoran' ? Number(t.nominal) : -Number(t.nominal)), 0);
      if (n > otherActiveSaldo) { toast.error('Penarikan melebihi saldo yang tersedia'); return; }
    }
    setEditConfirm(true);
  };

  const handleEditSave = async () => {
    if (!editTrx) return;
    setEditSaving(true);
    try {
      const n = Number(editForm.nominal);
      const changes: Array<{ field: string; old: string; neu: string }> = [];
      if (editTrx.tanggal !== editForm.tanggal) changes.push({ field: 'tanggal', old: editTrx.tanggal, neu: editForm.tanggal });
      if (editTrx.jenis !== editForm.jenis) changes.push({ field: 'jenis', old: editTrx.jenis, neu: editForm.jenis });
      if (String(editTrx.nominal) !== editForm.nominal) changes.push({ field: 'nominal', old: String(editTrx.nominal), neu: editForm.nominal });
      if ((editTrx.keterangan || '') !== editForm.keterangan) changes.push({ field: 'keterangan', old: editTrx.keterangan || '', neu: editForm.keterangan });

      const { error: updError } = await supabase.from('transaksi').update({
        tanggal: editForm.tanggal,
        jenis: editForm.jenis,
        nominal: n,
        keterangan: editForm.keterangan,
        updated_by: user?.id,
        updated_by_name: profile?.nama,
      }).eq('id', editTrx.id);
      if (updError) throw updError;

      // Recompute saldo_setelah for all transactions of this student (safe, non-recursive)
      await supabase.rpc('recompute_saldo_setelah', { p_siswa_id: editTrx.siswa_id });

      if (changes.length > 0) {
        const logRows = changes.map((c) => ({
          transaksi_id: editTrx.id,
          field_name: c.field,
          old_value: c.old,
          new_value: c.neu,
          edited_by: user?.id || null,
          edited_by_name: profile?.nama || null,
          edited_by_role: profile?.role || null,
          edit_reason: editReason,
        }));
        const { error: logError } = await supabase.from('transaksi_edit_log').insert(logRows);
        if (logError) console.error('Edit log error:', logError.message);
      }

      await logAktivitas('Edit', 'Transaksi', `Mengubah transaksi ${editTrx.siswa?.nama || ''}: ${changes.map((c) => `${c.field} ${c.old}→${c.neu}`).join(', ')}`);
      toast.success('Transaksi berhasil diperbarui dan saldo telah dihitung ulang');
      setEditTrx(null);
      setEditConfirm(false);
      refetch();
      queryClient.invalidateQueries({ queryKey: ['guru-tabungan-siswa'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
      queryClient.invalidateQueries({ queryKey: ['transaksi'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setEditSaving(false);
  };

  const handleCancel = async () => {
    if (!cancelTrx) return;
    if (!cancelReason.trim()) { toast.error('Alasan pembatalan wajib diisi'); return; }
    setCancelSaving(true);
    try {
      const { error } = await supabase.from('transaksi').update({
        status: 'dibatalkan',
        cancelled_at: new Date().toISOString(),
        cancelled_by: user?.id,
        cancelled_by_name: profile?.nama,
        cancel_reason: cancelReason,
      }).eq('id', cancelTrx.id);
      if (error) throw error;

      // Log BATAL entry in audit trail
      await supabase.from('transaksi_edit_log').insert({
        transaksi_id: cancelTrx.id,
        field_name: 'status',
        old_value: 'aktif',
        new_value: 'dibatalkan',
        edited_by: user?.id || null,
        edited_by_name: profile?.nama || null,
        edited_by_role: profile?.role || null,
        edit_reason: cancelReason,
        change_type: 'BATAL',
        delete_reason: cancelReason,
        siswa_nama: cancelTrx.siswa?.nama || null,
        siswa_nisn: cancelTrx.siswa?.nisn || null,
        nominal_before: String(cancelTrx.nominal),
        jenis_trx: cancelTrx.jenis,
        tanggal_trx: cancelTrx.tanggal,
      });

      // Recompute saldo_setelah for all transactions of this student (safe, non-recursive)
      await supabase.rpc('recompute_saldo_setelah', { p_siswa_id: cancelTrx.siswa_id });
      await logAktivitas('Batalkan', 'Transaksi', `Membatalkan transaksi ${cancelTrx.siswa?.nama || ''} ${cancelTrx.jenis} ${formatRupiah(Number(cancelTrx.nominal))}. Alasan: ${cancelReason}`);
      toast.success('Transaksi dibatalkan, saldo dihitung ulang');
      setCancelTrx(null);
      setCancelReason('');
      refetch();
      queryClient.invalidateQueries({ queryKey: ['guru-tabungan-siswa'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
      queryClient.invalidateQueries({ queryKey: ['transaksi'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setCancelSaving(false);
  };

  const handleRestore = async (t: Transaksi) => {
    try {
      const { error } = await supabase.from('transaksi').update({
        status: 'aktif',
        cancelled_at: null,
        cancelled_by: null,
        cancelled_by_name: null,
        cancel_reason: null,
      }).eq('id', t.id);
      if (error) throw error;

      // Recompute saldo_setelah for all transactions of this student
      await supabase.rpc('recompute_saldo_setelah', { p_siswa_id: t.siswa_id });
      await logAktivitas('Pulihkan', 'Transaksi', `Memulihkan transaksi ${t.siswa?.nama || ''} ${t.jenis} ${formatRupiah(Number(t.nominal))}`);
      toast.success('Transaksi dipulihkan, saldo dihitung ulang');
      refetch();
      queryClient.invalidateQueries({ queryKey: ['guru-tabungan-siswa'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
      queryClient.invalidateQueries({ queryKey: ['transaksi'] });
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleDelete = async () => {
    if (!deleteTrx) return;
    setDeleteSaving(true);
    try {
      // Log HAPUS entry BEFORE deleting (so FK is still valid)
      await supabase.from('transaksi_edit_log').insert({
        transaksi_id: deleteTrx.id,
        field_name: 'nominal',
        old_value: String(deleteTrx.nominal),
        new_value: null,
        edited_by: user?.id || null,
        edited_by_name: profile?.nama || null,
        edited_by_role: profile?.role || null,
        edit_reason: deleteReason || 'Hapus transaksi',
        change_type: 'HAPUS',
        delete_reason: deleteReason || null,
        siswa_nama: deleteTrx.siswa?.nama || null,
        siswa_nisn: deleteTrx.siswa?.nisn || null,
        nominal_before: String(deleteTrx.nominal),
        jenis_trx: deleteTrx.jenis,
        tanggal_trx: deleteTrx.tanggal,
      });
      const { error } = await supabase.from('transaksi').delete().eq('id', deleteTrx.id);
      if (error) throw error;
      await logAktivitas('Hapus', 'Transaksi', `Menghapus transaksi ${deleteTrx.siswa?.nama || ''} ${deleteTrx.jenis} ${formatRupiah(Number(deleteTrx.nominal))}${deleteReason ? `. Alasan: ${deleteReason}` : ''}`);
      toast.success('Transaksi berhasil dihapus dan saldo telah dihitung ulang');
      setDeleteTrx(null);
      setDeleteReason('');
      refetch();
      queryClient.invalidateQueries({ queryKey: ['guru-tabungan-siswa'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
      queryClient.invalidateQueries({ queryKey: ['transaksi'] });
    } catch (err: any) {
      toast.error(err.message);
    }
    setDeleteSaving(false);
  };

  const openHistory = async (s: Siswa) => {
    setHistorySiswa(s);
    setHistoryLoading(true);
    try {
      const { data, error } = await supabase
        .from('transaksi')
        .select('*')
        .eq('siswa_id', s.id)
        .order('tanggal', { ascending: true })
        .order('created_at', { ascending: true });
      if (error) throw error;
      setHistoryData((data || []) as Transaksi[]);
    } catch (err: any) {
      toast.error(err.message);
    }
    setHistoryLoading(false);
  };

  const openEditLog = async (t: Transaksi) => {
    setLogTrx(t);
    setLogLoading(true);
    try {
      const { data, error } = await supabase
        .from('transaksi_edit_log')
        .select('*')
        .eq('transaksi_id', t.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setLogData((data || []) as TransaksiEditLog[]);
    } catch (err: any) {
      toast.error(err.message);
    }
    setLogLoading(false);
  };

  if (!kelasId && !isLoading && !isAdmin) {
    return (
      <>
        <PageHeader title="Riwayat Tabungan" description="Riwayat setoran dan penarikan" />
        <div className="p-6">
          <EmptyState icon={<ArrowLeftRight className="h-6 w-6" />} title="Belum ada kelas ditugaskan" description="Hubungi admin untuk menentukan kelas yang Anda ampu." />
        </div>
      </>
    );
  }

  const kelasNamaLabel = isAdmin
    ? (adminKelasFilter ? (kelasList?.find((k) => k.id === adminKelasFilter)?.nama || 'Semua Kelas') : 'Semua Kelas')
    : (guruKelas?.kelas?.nama || '-');

  return (
    <>
      <PageHeader title="Riwayat Tabungan" description={`Kelas ${kelasNamaLabel} • Riwayat setoran & penarikan`}
        action={<Button onClick={() => setOpen(true)} className="gap-2"><Plus className="h-4 w-4" /> Tambah Transaksi</Button>}
      />

      <div className="p-6 space-y-4">
        {isAdmin && (
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium">Filter Kelas:</label>
              <select value={adminKelasFilter} onChange={(e) => { setAdminKelasFilter(e.target.value); setFilters({ ...filters, siswa_id: undefined }); setPage(1); }} className="h-9 w-48 rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">Semua Kelas</option>
                {(kelasList || []).map((k) => <option key={k.id} value={k.id}>{k.nama}</option>)}
              </select>
            </div>
          </Card>
        )}

        <div className="grid gap-4 sm:grid-cols-3">
          <Card><CardContent className="p-4"><p className="text-sm text-muted-foreground">Total Transaksi Aktif</p><p className="text-2xl font-bold">{filtered.filter((t) => t.status === 'aktif').length}</p></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2"><ArrowUpRight className="h-5 w-5 text-primary" /><div><p className="text-sm text-muted-foreground">Total Setoran Aktif</p><p className="text-lg font-bold text-primary">{formatRupiah(totalSetoran)}</p></div></div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2"><ArrowDownRight className="h-5 w-5 text-destructive" /><div><p className="text-sm text-muted-foreground">Total Penarikan Aktif</p><p className="text-lg font-bold text-destructive">{formatRupiah(totalPenarikan)}</p></div></div></CardContent></Card>
        </div>

        {/* Filters */}
        <Card className="p-4">
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Siswa</label>
              <select value={filters.siswa_id || ''} onChange={(e) => { setFilters({ ...filters, siswa_id: e.target.value || undefined }); setPage(1); }} className="mt-1 h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">Semua Siswa</option>
                {(siswaList || []).map((s) => <option key={s.id} value={s.id}>{s.nama}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Jenis</label>
              <select value={filters.jenis || ''} onChange={(e) => { setFilters({ ...filters, jenis: e.target.value || undefined }); setPage(1); }} className="mt-1 h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">Semua</option>
                <option value="setoran">Setoran</option>
                <option value="penarikan">Penarikan</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Status</label>
              <select value={filters.status || ''} onChange={(e) => { setFilters({ ...filters, status: e.target.value || undefined }); setPage(1); }} className="mt-1 h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">Semua Status</option>
                <option value="aktif">Aktif</option>
                <option value="dibatalkan">Dibatalkan</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Dari Tanggal</label>
              <input type="date" value={filters.dari || ''} onChange={(e) => { setFilters({ ...filters, dari: e.target.value || undefined }); setPage(1); }} className="mt-1 h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Sampai Tanggal</label>
              <input type="date" value={filters.sampai || ''} onChange={(e) => { setFilters({ ...filters, sampai: e.target.value || undefined }); setPage(1); }} className="mt-1 h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Cari nama atau NISN siswa..." className="h-9 w-full rounded-lg border bg-background pl-10 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <Button variant="outline" size="sm" onClick={() => { setFilters({}); setSearch(''); setPage(1); }}>Reset Filter</Button>
          </div>
        </Card>

        {/* Transaction table */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? <div className="p-4 text-sm text-muted-foreground">Memuat data transaksi...</div> : paged.length === 0 ? (
              <EmptyState icon={<ArrowLeftRight className="h-6 w-6" />} title="Belum ada transaksi" description="Transaksi kelas Anda akan muncul di sini." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-3 py-3 font-medium">Tgl Tabungan</th>
                      <th className="px-3 py-3 font-medium">Waktu Input</th>
                      <th className="px-3 py-3 font-medium">NISN</th>
                      <th className="px-3 py-3 font-medium">Nama</th>
                      <th className="px-3 py-3 font-medium text-primary">Setoran</th>
                      <th className="px-3 py-3 font-medium text-destructive">Penarikan</th>
                      <th className="px-3 py-3 font-medium">Saldo</th>
                      <th className="px-3 py-3 font-medium">Diinput Oleh</th>
                      <th className="px-3 py-3 font-medium">Terakhir Diubah</th>
                      <th className="px-3 py-3 font-medium">Status</th>
                      <th className="px-3 py-3 text-right font-medium">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {paged.map((t) => {
                      const isSetoran = t.jenis === 'setoran';
                      const isCancelled = t.status === 'dibatalkan';
                      return (
                        <tr key={t.id} className={`hover:bg-muted/30 ${isCancelled ? 'opacity-60' : ''}`}>
                          <td className="px-3 py-3 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                          <td className="px-3 py-3 text-xs text-muted-foreground">{formatWaktu(t.created_at)}</td>
                          <td className="px-3 py-3 text-xs text-muted-foreground">{t.siswa?.nisn || '-'}</td>
                          <td className="px-3 py-3 font-medium">{t.siswa?.nama || '-'}</td>
                          <td className="px-3 py-3 font-medium text-primary">{isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                          <td className="px-3 py-3 font-medium text-destructive">{!isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                          <td className="px-3 py-3 text-xs font-semibold">{t.saldo_setelah != null ? formatRupiah(t.saldo_setelah) : '-'}</td>
                          <td className="px-3 py-3 text-xs">{t.petugas_nama || '-'}</td>
                          <td className="px-3 py-3 text-xs text-muted-foreground">{t.updated_at && t.updated_at !== t.created_at ? formatWaktu(t.updated_at) : '-'}</td>
                          <td className="px-3 py-3">
                            <div className="flex flex-col gap-1">
                              {isCancelled ? (
                                <span className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
                                  <XCircle className="h-3 w-3" /> Dibatalkan
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                                  <CheckCircle2 className="h-3 w-3" /> Aktif
                                </span>
                              )}
                              {editedTrxIds?.has(t.id) && (
                                <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700 dark:bg-amber-950/30 dark:text-amber-400">
                                  <Edit3 className="h-3 w-3" /> Pernah diedit
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="flex justify-end gap-1">
                              <button onClick={() => openHistory(siswaList?.find((s) => s.id === t.siswa_id) || t.siswa as any)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-primary" title="Lihat Riwayat Siswa"><Eye className="h-4 w-4" /></button>
                              <button onClick={() => openEdit(t)} disabled={isCancelled} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-primary disabled:opacity-30" title="Edit"><Pencil className="h-4 w-4" /></button>
                              <button onClick={() => openEditLog(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-amber-600" title="Log Perubahan"><History className="h-4 w-4" /></button>
                              {isCancelled ? (
                                <button onClick={() => handleRestore(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-primary" title="Pulihkan"><RotateCcw className="h-4 w-4" /></button>
                              ) : (
                                <button onClick={() => setCancelTrx(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-destructive" title="Batalkan"><Ban className="h-4 w-4" /></button>
                              )}
                              <button onClick={() => setDeleteTrx(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive" title="Hapus"><Trash2 className="h-4 w-4" /></button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{(page - 1) * PAGE_SIZE + 1}-{Math.min(page * PAGE_SIZE, filtered.length)} dari {filtered.length}</p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" disabled={page === 1} onClick={() => setPage(page - 1)}><ChevronLeft className="h-4 w-4" /></Button>
              <span className="text-sm">{page} / {totalPages}</span>
              <Button variant="outline" size="icon" disabled={page === totalPages} onClick={() => setPage(page + 1)}><ChevronRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}
      </div>

      {/* Add transaction dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Tambah Transaksi</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Siswa *</label>
              <select value={form.siswa_id} onChange={(e) => setForm({ ...form, siswa_id: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">Pilih Siswa</option>
                {siswaList?.map((s) => <option key={s.id} value={s.id}>{s.nama} ({formatRupiah(s.saldo)})</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><label className="text-sm font-medium">Jenis</label><select value={form.jenis} onChange={(e) => setForm({ ...form, jenis: e.target.value as JenisTransaksi })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="setoran">Setoran</option><option value="penarikan">Penarikan</option></select></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Tanggal</label><input type="date" value={form.tanggal} onChange={(e) => setForm({ ...form, tanggal: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
            </div>
            <div className="space-y-1.5"><label className="text-sm font-medium">Nominal *</label><input type="number" value={form.nominal} onChange={(e) => setForm({ ...form, nominal: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
            <div className="space-y-1.5"><label className="text-sm font-medium">Keterangan</label><input value={form.keterangan} onChange={(e) => setForm({ ...form, keterangan: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
            <DialogFooter><Button type="button" variant="outline" onClick={() => setOpen(false)}>Batal</Button><Button type="submit" disabled={saving}>{saving ? 'Memproses...' : 'Simpan'}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit transaction dialog */}
      <Dialog open={!!editTrx} onOpenChange={(v) => !v && setEditTrx(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Pencil className="h-5 w-5 text-primary" /> Edit Transaksi</DialogTitle>
            <DialogDescription>{editTrx?.siswa?.nama || '-'} • Saldo saat ini: {formatRupiah(editTrx?.saldo_setelah || 0)}</DialogDescription>
          </DialogHeader>
          {!editConfirm ? (
            <div className="space-y-4">
              <div className="rounded-lg border bg-muted/30 p-3 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div><span className="text-muted-foreground">Nama:</span> <span className="font-medium">{editTrx?.siswa?.nama || '-'}</span></div>
                  <div><span className="text-muted-foreground">NISN:</span> <span className="font-medium">{editTrx?.siswa?.nisn || '-'}</span></div>
                  <div><span className="text-muted-foreground">Kelas:</span> <span className="font-medium">{(editTrx as any)?.siswa?.kelas?.nama || '-'}</span></div>
                  <div><span className="text-muted-foreground">Saldo Saat Ini:</span> <span className="font-semibold text-primary">{formatRupiah(editTrx?.saldo_setelah || 0)}</span></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><label className="text-sm font-medium">Jenis</label><select value={editForm.jenis} onChange={(e) => setEditForm({ ...editForm, jenis: e.target.value as JenisTransaksi })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="setoran">Setoran</option><option value="penarikan">Penarikan</option></select></div>
                <div className="space-y-1.5"><label className="text-sm font-medium">Tanggal</label><input type="date" value={editForm.tanggal} onChange={(e) => setEditForm({ ...editForm, tanggal: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              </div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Nominal *</label><input type="number" value={editForm.nominal} onChange={(e) => setEditForm({ ...editForm, nominal: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Keterangan</label><input value={editForm.keterangan} onChange={(e) => setEditForm({ ...editForm, keterangan: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Alasan Perubahan *</label><textarea value={editReason} onChange={(e) => setEditReason(e.target.value)} placeholder="Jelaskan alasan perubahan..." rows={2} className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <DialogFooter><Button variant="outline" onClick={() => setEditTrx(null)}>Batal</Button><Button onClick={handleEditConfirm}>Lanjut</Button></DialogFooter>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 dark:bg-amber-950/20">
                <div className="flex items-center gap-2 mb-3"><AlertTriangle className="h-5 w-5 text-amber-600" /><p className="font-semibold text-amber-700">Konfirmasi Perubahan</p></div>
                <div className="space-y-2 text-sm">
                  {editTrx!.tanggal !== editForm.tanggal && <p>Tanggal: <span className="line-through text-muted-foreground">{formatTanggalSingkat(editTrx!.tanggal)}</span> → <span className="font-semibold">{formatTanggalSingkat(editForm.tanggal)}</span></p>}
                  {editTrx!.jenis !== editForm.jenis && <p>Jenis: <span className="line-through text-muted-foreground">{editTrx!.jenis}</span> → <span className="font-semibold">{editForm.jenis}</span></p>}
                  {String(editTrx!.nominal) !== editForm.nominal && <p>Nominal: <span className="line-through text-muted-foreground">{formatRupiah(Number(editTrx!.nominal))}</span> → <span className="font-semibold">{formatRupiah(Number(editForm.nominal))}</span></p>}
                  {(editTrx!.keterangan || '') !== editForm.keterangan && <p>Keterangan: <span className="line-through text-muted-foreground">{editTrx!.keterangan || '-'}</span> → <span className="font-semibold">{editForm.keterangan || '-'}</span></p>}
                  <p className="pt-2 border-t">Alasan: <span className="font-semibold">{editReason}</span></p>
                  <p>Perubahan oleh: <span className="font-semibold">{profile?.nama}</span></p>
                </div>
              </div>
              <DialogFooter><Button variant="outline" onClick={() => setEditConfirm(false)}>Kembali</Button><Button onClick={handleEditSave} disabled={editSaving} className="gap-2">{editSaving ? 'Menyimpan...' : 'Simpan Perubahan'}</Button></DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Cancel transaction dialog */}
      <Dialog open={!!cancelTrx} onOpenChange={(v) => !v && setCancelTrx(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive"><Ban className="h-5 w-5" /> Batalkan Transaksi</DialogTitle>
            <DialogDescription>
              {cancelTrx?.siswa?.nama} • {cancelTrx?.jenis === 'setoran' ? 'Setoran' : 'Penarikan'} {formatRupiah(Number(cancelTrx?.nominal || 0))} • {formatTanggalSingkat(cancelTrx?.tanggal || '')}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-3 text-sm text-muted-foreground">
              Transaksi yang dibatalkan tidak dihitung dalam saldo, tetapi tetap terlihat dalam riwayat dengan status "Dibatalkan". Saldo siswa akan dihitung ulang otomatis.
            </div>
            <div className="space-y-1.5"><label className="text-sm font-medium">Alasan Pembatalan *</label><textarea value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} placeholder="Jelaskan alasan pembatalan..." rows={2} className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
            <DialogFooter><Button variant="outline" onClick={() => setCancelTrx(null)}>Batal</Button><Button variant="destructive" onClick={handleCancel} disabled={cancelSaving}>{cancelSaving ? 'Memproses...' : 'Ya, Batalkan'}</Button></DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation dialog */}
      <Dialog open={!!deleteTrx} onOpenChange={(v) => !v && setDeleteTrx(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive"><Trash2 className="h-5 w-5" /> Hapus Transaksi</DialogTitle>
            <DialogDescription>
              {deleteTrx?.siswa?.nama} • {deleteTrx?.jenis === 'setoran' ? 'Setoran' : 'Penarikan'} {formatRupiah(Number(deleteTrx?.nominal || 0))} • {formatTanggalSingkat(deleteTrx?.tanggal || '')}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-3 text-sm text-muted-foreground">
              <p className="flex items-center gap-2 font-medium text-destructive"><AlertTriangle className="h-4 w-4" /> Perhatian</p>
              <p className="mt-1">Transaksi akan dihapus permanen. Saldo siswa akan dihitung ulang otomatis. Data siswa tidak akan terpengaruh. Riwayat perubahan tetap tersimpan untuk audit.</p>
            </div>
            <div className="space-y-1.5"><label className="text-sm font-medium">Alasan Penghapusan</label><textarea value={deleteReason} onChange={(e) => setDeleteReason(e.target.value)} placeholder="Jelaskan alasan penghapusan (opsional)..." rows={2} className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
            <DialogFooter><Button variant="outline" onClick={() => { setDeleteTrx(null); setDeleteReason(''); }}>Batal</Button><Button variant="destructive" onClick={handleDelete} disabled={deleteSaving} className="gap-2"><Trash2 className="h-4 w-4" /> {deleteSaving ? 'Menghapus...' : 'Ya, Hapus'}</Button></DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Student history dialog */}
      <Dialog open={!!historySiswa} onOpenChange={(v) => !v && setHistorySiswa(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><History className="h-5 w-5 text-primary" /> Riwayat Tabungan</DialogTitle>
            <DialogDescription>
              {historySiswa?.nama} • NISN: {historySiswa?.nisn || '-'} • Kelas: {historySiswa?.kelas?.nama || '-'} • Saldo: <span className="font-semibold text-primary">{formatRupiah(historySiswa?.saldo || 0)}</span>
            </DialogDescription>
          </DialogHeader>
          {historyLoading ? (
            <div className="py-8 text-center text-sm text-muted-foreground">Memuat riwayat...</div>
          ) : historyData.length === 0 ? (
            <EmptyState icon={<History className="h-6 w-6" />} title="Belum ada transaksi" description="Riwayat transaksi siswa ini akan muncul di sini." />
          ) : (
            <div className="max-h-[60vh] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 border-b bg-card text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 font-medium">Tanggal</th>
                    <th className="px-3 py-2 font-medium text-primary">Setoran</th>
                    <th className="px-3 py-2 font-medium text-destructive">Penarikan</th>
                    <th className="px-3 py-2 font-medium">Saldo</th>
                    <th className="px-3 py-2 font-medium">Diinput Oleh</th>
                    <th className="px-3 py-2 font-medium">Waktu Input</th>
                    <th className="px-3 py-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {historyData.map((t) => {
                    const isSetoran = t.jenis === 'setoran';
                    return (
                      <tr key={t.id} className={`hover:bg-muted/30 ${t.status === 'dibatalkan' ? 'opacity-60' : ''}`}>
                        <td className="px-3 py-2 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                        <td className="px-3 py-2 font-medium text-primary">{isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                        <td className="px-3 py-2 font-medium text-destructive">{!isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                        <td className="px-3 py-2 font-semibold">{t.saldo_setelah != null ? formatRupiah(t.saldo_setelah) : '-'}</td>
                        <td className="px-3 py-2 text-xs">{t.petugas_nama || '-'}</td>
                        <td className="px-3 py-2 text-xs text-muted-foreground">{formatWaktu(t.created_at)}</td>
                        <td className="px-3 py-2">
                          {t.status === 'dibatalkan' ? (
                            <span className="inline-flex items-center gap-1 text-xs text-destructive"><XCircle className="h-3 w-3" /> Dibatalkan</span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs text-primary"><CheckCircle2 className="h-3 w-3" /> Aktif</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit log dialog */}
      <Dialog open={!!logTrx} onOpenChange={(v) => !v && setLogTrx(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><History className="h-5 w-5 text-amber-600" /> Log Perubahan Transaksi</DialogTitle>
            <DialogDescription>{logTrx?.siswa?.nama} • {logTrx?.jenis === 'setoran' ? 'Setoran' : 'Penarikan'} {formatRupiah(Number(logTrx?.nominal || 0))}</DialogDescription>
          </DialogHeader>
          {logLoading ? (
            <div className="py-8 text-center text-sm text-muted-foreground">Memuat log...</div>
          ) : logData.length === 0 ? (
            <EmptyState icon={<History className="h-6 w-6" />} title="Belum ada perubahan" description="Transaksi ini belum pernah diubah." />
          ) : (
            <div className="max-h-[60vh] space-y-3 overflow-y-auto">
              {logData.map((log) => {
            const isInput = log.change_type === 'INPUT';
            const isHapus = log.change_type === 'HAPUS';
            const isBatal = log.change_type === 'BATAL';
            const badgeColor = isInput ? 'bg-primary/10 text-primary' : isHapus ? 'bg-destructive/10 text-destructive' : isBatal ? 'bg-orange-100 text-orange-700 dark:bg-orange-950/30' : 'bg-amber-100 text-amber-700 dark:bg-amber-950/30';
            const badgeLabel = isInput ? 'INPUT AWAL' : isHapus ? 'HAPUS' : isBatal ? 'DIBATALKAN' : 'EDIT';
            const namaSiswa = log.siswa_nama || logTrx?.siswa?.nama || '-';
            const nisnSiswa = log.siswa_nisn || logTrx?.siswa?.nisn || '-';
            return (
                <div key={log.id} className="rounded-lg border p-3">
                  <div className="flex items-center justify-between">
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${badgeColor}`}>{badgeLabel}</span>
                    <span className="text-xs text-muted-foreground">{formatWaktu(log.created_at)}</span>
                  </div>
                  <div className="mt-2 flex items-center gap-2 text-sm">
                    {isInput ? (
                      <span className="font-semibold text-primary">{formatRupiah(Number(log.new_value || 0))}</span>
                    ) : isHapus ? (
                      <span className="line-through text-destructive">{formatRupiah(Number(log.old_value || 0))}</span>
                    ) : isBatal ? (
                      <span className="line-through text-orange-600">{formatRupiah(Number(log.old_value || 0))}</span>
                    ) : (
                      <><span className="line-through text-muted-foreground">{log.old_value || '-'}</span><span className="text-muted-foreground">→</span><span className="font-semibold">{log.new_value || '-'}</span></>
                    )}
                    {log.field_name !== 'nominal' && log.field_name !== 'status' && !isInput && !isHapus && !isBatal && <span className="text-xs text-muted-foreground">({log.field_name})</span>}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Siswa: {namaSiswa} ({nisnSiswa}) • Jenis: {log.jenis_trx || '-'} • Tgl Transaksi: {log.tanggal_trx ? formatTanggalSingkat(log.tanggal_trx) : '-'}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Oleh: {log.edited_by_name || '-'} ({log.edited_by_role || '-'}) • Alasan: {log.edit_reason || (isHapus || isBatal ? log.delete_reason : '-') || '-'}
                  </div>
                </div>
              );
            })}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
