import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useGuruKelas } from '@/hooks/queries';
import { PageHeader } from '@/components/PageHeader';
import { BrandLogo } from '@/components/BrandHeader';
import { usePengaturan } from '@/hooks/queries';
import { BRAND } from '@/lib/brand';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PageSkeleton, EmptyState } from '@/components/Loaders';
import { Wallet, GraduationCap, ArrowUpRight, ArrowDownRight, CalendarPlus, ChevronRight, TrendingUp } from 'lucide-react';
import { formatRupiah, formatTanggal, formatTanggalSingkat } from '@/lib/format';
import { Siswa, Transaksi } from '@/types';

export function GuruDashboard() {
  const { profile, user } = useAuth();
  const { data: pengaturan } = usePengaturan();
  const navigate = useNavigate();

  const { data: guruKelas, isLoading: guruLoading } = useGuruKelas(user?.id);
  const kelasId = guruKelas?.kelasId;
  const kelasNama = guruKelas?.kelas?.nama;

  const { data: siswaList } = useQuery({
    queryKey: ['guru-siswa', kelasId],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('*, kelas(*)').eq('kelas_id', kelasId!).order('nama');
      if (error) throw error;
      return data as Siswa[];
    },
    enabled: !!kelasId,
  });

  const today = new Date().toISOString().split('T')[0];

  const { data: todayData, isLoading: todayLoading } = useQuery({
    queryKey: ['guru-today-stats', kelasId, today],
    queryFn: async () => {
      const { data: siswaIds } = await supabase.from('siswa').select('id').eq('kelas_id', kelasId!);
      const ids = (siswaIds || []).map((s) => s.id);
      if (ids.length === 0) return { setoran: 0, penarikan: 0, siswaMenabung: 0, transaksiList: [] as Transaksi[] };
      const { data, error } = await supabase
        .from('transaksi')
        .select('*, siswa(nama)')
        .eq('tanggal', today)
        .eq('status', 'aktif')
        .in('siswa_id', ids)
        .order('created_at', { ascending: false });
      if (error) throw error;
      const trx = (data || []) as Transaksi[];
      const setoran = trx.filter((t) => t.jenis === 'setoran').reduce((s, t) => s + Number(t.nominal), 0);
      const penarikan = trx.filter((t) => t.jenis === 'penarikan').reduce((s, t) => s + Number(t.nominal), 0);
      const siswaMenabung = new Set(trx.map((t) => t.siswa_id)).size;
      return { setoran, penarikan, siswaMenabung, transaksiList: trx };
    },
    enabled: !!kelasId,
  });

  const { data: recentDates } = useQuery({
    queryKey: ['guru-recent-dates', kelasId],
    queryFn: async () => {
      const { data: siswaIds } = await supabase.from('siswa').select('id').eq('kelas_id', kelasId!);
      const ids = (siswaIds || []).map((s) => s.id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from('transaksi')
        .select('tanggal, siswa_id, jenis, nominal, status')
        .eq('status', 'aktif')
        .in('siswa_id', ids)
        .order('tanggal', { ascending: false })
        .limit(500);
      if (error) throw error;
      const byDate: Record<string, { siswaCount: number; setoran: number; penarikan: number }> = {};
      for (const t of data || []) {
        if (!byDate[t.tanggal]) byDate[t.tanggal] = { siswaCount: 0, setoran: 0, penarikan: 0 };
        const d = byDate[t.tanggal];
        const siswaSet = new Set<string>();
        siswaSet.add(t.siswa_id);
        d.siswaCount = (d.siswaCount || 0);
        if (t.jenis === 'setoran') d.setoran += Number(t.nominal);
        else d.penarikan += Number(t.nominal);
      }
      const dates = Object.entries(byDate).map(([tanggal, stats]) => ({
        tanggal,
        siswaMenabung: new Set((data || []).filter((t) => t.tanggal === tanggal).map((t) => t.siswa_id)).size,
        setoran: stats.setoran,
        penarikan: stats.penarikan,
      }));
      return dates.sort((a, b) => b.tanggal.localeCompare(a.tanggal)).slice(0, 5);
    },
    enabled: !!kelasId,
  });

  if (guruLoading) return <PageSkeleton />;

  const totalSaldo = (siswaList || []).reduce((s, x) => s + Number(x.saldo), 0);

  return (
    <>
      <PageHeader
        title={`Selamat datang, ${profile?.nama}`}
        description={kelasNama ? `Kelas ${kelasNama}` : 'Belum ada kelas ditugaskan'}
        action={
          <Button className="gap-2" onClick={() => navigate('/guru/tabungan')}>
            <CalendarPlus className="h-4 w-4" /> Entri Tabungan Hari Ini
          </Button>
        }
      />

      <div className="space-y-6 p-6">
        <Card className="border-primary/20 bg-gradient-to-r from-primary/5 via-card to-blue-50/60 dark:to-blue-950/20">
          <CardContent className="flex items-center gap-4 p-4 sm:p-5">
            <BrandLogo size="md" />
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Selamat datang di</p>
              <p className="truncate text-lg font-bold">{pengaturan?.nama_sekolah || `Selamat Datang di ${BRAND.appName}`}</p>
              <p className="text-sm text-muted-foreground">{pengaturan?.app_name || BRAND.appName} · {pengaturan?.app_subtitle || BRAND.subtitle}</p>
              <p className="mt-1 text-xs italic text-muted-foreground">"{pengaturan?.app_tagline || BRAND.tagline}"</p>
            </div>
          </CardContent>
        </Card>

        {!kelasId ? (
          <EmptyState
            icon={<Wallet className="h-6 w-6" />}
            title="Belum ada kelas ditugaskan"
            description="Hubungi admin untuk menentukan kelas yang Anda ampu."
          />
        ) : (
          <>
            {/* Tabungan Hari Ini - main focus */}
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Wallet className="h-5 w-5 text-primary" />
                  Tabungan Hari Ini
                </CardTitle>
                <CardDescription>{formatTanggal(today)}</CardDescription>
              </CardHeader>
              <CardContent>
                {todayLoading ? (
                  <div className="h-20 animate-pulse rounded-lg bg-muted/50" />
                ) : (
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="rounded-xl border bg-card p-4">
                      <div className="flex items-center gap-2">
                        <GraduationCap className="h-5 w-5 text-primary" />
                        <p className="text-sm text-muted-foreground">Siswa Menabung</p>
                      </div>
                      <p className="mt-1 text-2xl font-bold">{todayData?.siswaMenabung || 0}<span className="text-base font-normal text-muted-foreground"> siswa</span></p>
                    </div>
                    <div className="rounded-xl border bg-card p-4">
                      <div className="flex items-center gap-2">
                        <ArrowUpRight className="h-5 w-5 text-primary" />
                        <p className="text-sm text-muted-foreground">Total Setoran</p>
                      </div>
                      <p className="mt-1 text-2xl font-bold text-primary">{formatRupiah(todayData?.setoran || 0)}</p>
                    </div>
                    <div className="rounded-xl border bg-card p-4">
                      <div className="flex items-center gap-2">
                        <ArrowDownRight className="h-5 w-5 text-destructive" />
                        <p className="text-sm text-muted-foreground">Total Penarikan</p>
                      </div>
                      <p className="mt-1 text-2xl font-bold text-destructive">{formatRupiah(todayData?.penarikan || 0)}</p>
                    </div>
                  </div>
                )}
                <div className="mt-4">
                  <Button className="w-full gap-2" onClick={() => navigate('/guru/tabungan')}>
                    <CalendarPlus className="h-4 w-4" /> Entri Tabungan Hari Ini
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Total Saldo Kelas */}
            <div className="grid gap-4 sm:grid-cols-2">
              <Card>
                <CardContent className="flex items-center gap-4 p-5">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30">
                    <Wallet className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Saldo Kelas</p>
                    <p className="text-2xl font-bold">{formatRupiah(totalSaldo)}</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="flex items-center gap-4 p-5">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <GraduationCap className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Jumlah Siswa</p>
                    <p className="text-2xl font-bold">{siswaList?.length || 0}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tabungan Terakhir */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Tabungan Terakhir
                </CardTitle>
                <CardDescription>5 tanggal terakhir yang sudah diinput</CardDescription>
              </CardHeader>
              <CardContent>
                {!recentDates || recentDates.length === 0 ? (
                  <EmptyState icon={<TrendingUp className="h-6 w-6" />} title="Belum ada tabungan" description="Mulai entri tabungan hari ini." />
                ) : (
                  <div className="space-y-2">
                    {recentDates.map((d) => (
                      <button
                        key={d.tanggal}
                        onClick={() => navigate('/guru/tabungan')}
                        className="flex w-full items-center justify-between rounded-lg border p-4 transition-colors hover:bg-muted/50"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                            <Wallet className="h-5 w-5" />
                          </div>
                          <div className="text-left">
                            <p className="font-semibold">{formatTanggalSingkat(d.tanggal)}</p>
                            <p className="text-xs text-muted-foreground">{d.siswaMenabung} siswa menabung</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-primary">{formatRupiah(d.setoran)}</span>
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </>
  );
}

export function GuruSiswaPage() {
  const { user } = useAuth();
  const { data: guruKelas } = useGuruKelas(user?.id);

  const { data: siswaList, isLoading } = useQuery({
    queryKey: ['guru-siswa-list', guruKelas?.kelasId],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('*, kelas(*)').eq('kelas_id', guruKelas!.kelasId!).order('nama');
      if (error) throw error;
      return data as Siswa[];
    },
    enabled: !!guruKelas?.kelasId,
  });

  return (
    <>
      <PageHeader title="Siswa" description={`Kelas ${guruKelas?.kelas?.nama || '-'}`} />
      <div className="p-6">
        <Card>
          <CardContent className="p-0">
            {isLoading ? <div className="p-4"><div className="h-8 w-full animate-pulse rounded bg-muted" /></div> : (siswaList || []).length === 0 ? (
              <EmptyState icon={<GraduationCap className="h-6 w-6" />} title="Belum ada siswa" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr><th className="px-4 py-3 font-medium">Nama</th><th className="px-4 py-3 font-medium">NISN</th><th className="px-4 py-3 font-medium">Saldo</th><th className="px-4 py-3 font-medium">Status</th></tr>
                  </thead>
                  <tbody className="divide-y">
                    {(siswaList || []).map((s) => (
                      <tr key={s.id} className="hover:bg-muted/30"><td className="px-4 py-3 font-medium">{s.nama}</td><td className="px-4 py-3 text-xs">{s.nisn || s.nis}</td><td className="px-4 py-3 font-semibold text-primary">{formatRupiah(s.saldo)}</td><td className="px-4 py-3"><span className={`rounded-full px-2 py-0.5 text-xs ${s.status === 'aktif' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{s.status}</span></td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
