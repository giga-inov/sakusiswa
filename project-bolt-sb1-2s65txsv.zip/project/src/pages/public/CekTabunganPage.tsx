import { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Search, ArrowUpRight, ArrowDownRight, Loader2, Phone, Code2, ArrowLeft, Wallet, User, School } from 'lucide-react';
import { formatRupiah, formatTanggalSingkat } from '@/lib/format';
import { usePengaturan } from '@/hooks/queries';
import { BRAND, getLogoUrl } from '@/lib/brand';

interface CekTabunganResult {
  found: boolean;
  siswa?: {
    id: string;
    nama: string;
    nis: string;
    nisn: string;
    saldo: number;
    kelas_nama: string | null;
  };
  transaksi?: Array<{
    id: string;
    tanggal: string;
    jenis: string;
    nominal: number;
    saldo_setelah: number | null;
    keterangan: string | null;
    petugas_nama: string | null;
    created_at: string;
  }>;
}

export function CekTabunganPage() {
  const { data: pengaturan } = usePengaturan();
  const appName = pengaturan?.app_name || BRAND.appName;
  const subtitle = pengaturan?.app_subtitle || BRAND.subtitle;
  const tagline = pengaturan?.app_tagline || pengaturan?.slogan || BRAND.tagline;
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;
  const namaSekolah = pengaturan?.nama_sekolah || BRAND.appName;
  const alamatParts = [pengaturan?.kecamatan, pengaturan?.kabupaten_kota, pengaturan?.provinsi].filter(Boolean);
  const alamatText = alamatParts.length > 0 ? alamatParts.join(' • ') : pengaturan?.alamat || '';

  const [nisn, setNisn] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CekTabunganResult | null>(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nisn.trim()) return;
    setLoading(true);
    setSearched(true);
    try {
      const { data, error } = await supabase.rpc('cek_tabungan_by_nisn', { p_nisn: nisn.trim() });
      if (error) throw error;
      setResult(data as CekTabunganResult);
    } catch {
      setResult({ found: false });
    }
    setLoading(false);
  };

  const totalSetoran = (result?.transaksi || []).filter((t) => t.jenis === 'setoran').reduce((s, t) => s + Number(t.nominal), 0);
  const totalPenarikan = (result?.transaksi || []).filter((t) => t.jenis === 'penarikan').reduce((s, t) => s + Number(t.nominal), 0);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-primary/5 via-background to-emerald-50 p-4 dark:to-emerald-950/20">
      <div className="w-full max-w-2xl animate-slide-up">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
            {logoUrl ? (
              <img src={logoUrl} alt={`${appName} logo`} className="h-16 w-16 rounded-2xl object-contain p-1" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
            ) : (
              <span className="text-2xl font-bold">S</span>
            )}
          </div>
          <h1 className="text-3xl font-bold text-primary">{appName}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
          <p className="mt-3 text-xs italic text-muted-foreground">"{tagline}"</p>
        </div>

        <div className="rounded-2xl border bg-card p-6 shadow-xl sm:p-8">
          <h2 className="flex items-center gap-2 text-xl font-semibold">
            <Search className="h-5 w-5 text-primary" />
            Cek Tabungan Siswa
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">Masukkan NISN anak untuk melihat saldo dan riwayat tabungan.</p>

          <form onSubmit={handleSearch} className="mt-6 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">NISN Siswa</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={nisn}
                  onChange={(e) => setNisn(e.target.value)}
                  placeholder="Masukkan 10 digit NISN"
                  required
                  className="h-11 w-full rounded-lg border bg-background pl-10 pr-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/40"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 disabled:opacity-60"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              {loading ? 'Mencari...' : 'Cek Tabungan'}
            </button>
          </form>

          <div className="mt-4 flex items-center justify-center">
            <Link to="/login" className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary">
              <ArrowLeft className="h-4 w-4" /> Masuk sebagai Admin / Guru
            </Link>
          </div>

          {/* Results */}
          {searched && !loading && result && (
            <div className="mt-6 border-t pt-6">
              {!result.found ? (
                <div className="flex flex-col items-center py-8 text-center">
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
                    <Search className="h-7 w-7" />
                  </div>
                  <p className="text-lg font-semibold">NISN tidak ditemukan</p>
                  <p className="mt-1 text-sm text-muted-foreground">Pastikan NISN yang dimasukkan benar. Jika masalah berlanjut, hubungi pihak sekolah.</p>
                </div>
              ) : (
                <div className="space-y-5">
                  {/* Student Info */}
                  <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                          <User className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Nama Siswa</p>
                          <p className="font-bold">{result.siswa?.nama}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                          <School className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Kelas</p>
                          <p className="font-bold">{result.siswa?.kelas_nama || '-'}</p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center justify-center gap-3 rounded-lg bg-card p-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                        <Wallet className="h-6 w-6" />
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Saldo Tabungan Saat Ini</p>
                        <p className="text-3xl font-bold text-primary">{formatRupiah(result.siswa?.saldo || 0)}</p>
                      </div>
                    </div>
                  </div>

                  {/* Summary Stats */}
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-lg border p-4">
                      <div className="flex items-center gap-2">
                        <ArrowUpRight className="h-5 w-5 text-primary" />
                        <p className="text-sm text-muted-foreground">Total Setoran</p>
                      </div>
                      <p className="mt-1 text-xl font-bold text-primary">{formatRupiah(totalSetoran)}</p>
                    </div>
                    <div className="rounded-lg border p-4">
                      <div className="flex items-center gap-2">
                        <ArrowDownRight className="h-5 w-5 text-destructive" />
                        <p className="text-sm text-muted-foreground">Total Penarikan</p>
                      </div>
                      <p className="mt-1 text-xl font-bold text-destructive">{formatRupiah(totalPenarikan)}</p>
                    </div>
                  </div>

                  {/* Transaction History */}
                  <div>
                    <h3 className="mb-3 text-base font-semibold">Riwayat Tabungan</h3>
                    {(result.transaksi || []).length === 0 ? (
                      <div className="rounded-lg border py-8 text-center text-sm text-muted-foreground">
                        Belum ada transaksi.
                      </div>
                    ) : (
                      <div className="overflow-hidden rounded-lg border">
                        <table className="w-full text-sm">
                          <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                            <tr>
                              <th className="px-3 py-2 font-medium">Tanggal</th>
                              <th className="px-3 py-2 font-medium text-primary">Setoran</th>
                              <th className="px-3 py-2 font-medium text-destructive">Penarikan</th>
                              <th className="px-3 py-2 font-medium">Saldo</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y">
                            {(() => {
                              const sorted = [...(result.transaksi || [])].sort((a, b) => new Date(a.tanggal).getTime() - new Date(b.tanggal).getTime() || new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
                              return sorted.map((t) => {
                                const isSetoran = t.jenis === 'setoran';
                                return (
                                  <tr key={t.id} className="hover:bg-muted/30">
                                    <td className="px-3 py-2 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                                    <td className="px-3 py-2 font-medium text-primary">{isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                                    <td className="px-3 py-2 font-medium text-destructive">{!isSetoran ? formatRupiah(t.nominal) : '-'}</td>
                                    <td className="px-3 py-2 font-semibold">{formatRupiah(t.saldo_setelah || 0)}</td>
                                  </tr>
                                );
                              });
                            })()}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-6 flex flex-col items-center gap-2 text-center text-xs text-muted-foreground">
          <p>{namaSekolah}{alamatText ? ` • ${alamatText}` : ''}</p>
          <div className="flex flex-col items-center gap-1 sm:flex-row sm:gap-4">
            <span className="flex items-center gap-1.5">
              <Code2 className="h-3.5 w-3.5 text-primary" />
              Dikembangkan oleh <span className="font-semibold text-primary">GIGA INNOVATION</span>
            </span>
            <a href="tel:081329200985" className="flex items-center gap-1.5 transition-colors hover:text-primary">
              <Phone className="h-3.5 w-3.5" />
              081329200985
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
