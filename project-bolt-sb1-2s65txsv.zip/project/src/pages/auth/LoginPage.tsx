import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Mail, Lock, Eye, EyeOff, Loader2, ArrowLeft, Phone, Code2, Search } from 'lucide-react';
import { useAuth, getDashboardPath } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { usePengaturan } from '@/hooks/queries';
import { BRAND, getLogoUrl } from '@/lib/brand';
import { toast } from 'sonner';

const loginSchema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(1, 'Password wajib diisi'),
});

type LoginValues = z.infer<typeof loginSchema>;

function SchoolFooter() {
  const { data: pengaturan } = usePengaturan();
  const namaSekolah = pengaturan?.nama_sekolah || BRAND.appName;
  const alamatParts = [pengaturan?.kecamatan, pengaturan?.kabupaten_kota, pengaturan?.provinsi].filter(Boolean);
  const alamatText = alamatParts.length > 0 ? alamatParts.join(' • ') : pengaturan?.alamat || '';
  return (
    <div className="mt-6 flex flex-col items-center gap-2 text-center text-xs text-muted-foreground">
      {namaSekolah && <p>{namaSekolah}{alamatText ? ` • ${alamatText}` : ''}</p>}
      <div className="flex flex-col items-center gap-1 sm:flex-row sm:gap-4">
        <span className="flex items-center gap-1.5">
          <Code2 className="h-3.5 w-3.5 text-primary" />
          Dikembangkan oleh <span className="font-semibold text-primary">GIGA INNOVATION</span>
        </span>
        <a href="tel:081329200985" className="flex items-center gap-1.5 transition-colors hover:text-primary">
          <Phone className="h-3.5 w-3.5" />
          081329200985
        </a>
      </div>
    </div>
  );
}

function AppBrand({ showTagline = false }: { showTagline?: boolean }) {
  const { data: pengaturan } = usePengaturan();
  const appName = pengaturan?.app_name || BRAND.appName;
  const subtitle = pengaturan?.app_subtitle || BRAND.subtitle;
  const tagline = pengaturan?.app_tagline || pengaturan?.slogan || BRAND.tagline;
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;
  return (
    <div className="mb-8 text-center">
      <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
        {logoUrl ? (
          <img src={logoUrl} alt={`${appName} logo`} className="h-16 w-16 rounded-2xl object-contain p-1" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
        ) : null}
        {!logoUrl && <span className="text-2xl font-bold">S</span>}
      </div>
      <h1 className="text-3xl font-bold text-primary">{appName}</h1>
      <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
      {showTagline && <p className="mt-3 text-xs italic text-muted-foreground">"{tagline}"</p>}
    </div>
  );
}

export function LoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (values: LoginValues) => {
    setLoading(true);
    const { error, profile: loggedInProfile } = await signIn(values.email, values.password);
    setLoading(false);
    if (error) {
      toast.error(error);
      return;
    }
    if (loggedInProfile) {
      navigate(getDashboardPath(loggedInProfile.role));
    }
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-primary/5 via-background to-emerald-50 p-4 dark:to-emerald-950/20">
      <div className="w-full max-w-md animate-slide-up">
        <AppBrand showTagline />

        <div className="rounded-2xl border bg-card p-6 shadow-xl sm:p-8">
          <h2 className="text-xl font-semibold">Masuk ke Akun</h2>
          <p className="mt-1 text-sm text-muted-foreground">Silakan masuk untuk mengakses dashboard.</p>

          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  {...register('email')}
                  placeholder="email@example.com"
                  className="h-11 w-full rounded-lg border bg-background pl-10 pr-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/40"
                />
              </div>
              {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  {...register('password')}
                  placeholder="••••••••"
                  className="h-11 w-full rounded-lg border bg-background pl-10 pr-10 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/40"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-destructive">{errors.password.message}</p>}
            </div>

            <div className="flex justify-end">
              <Link to="/lupa-password" className="text-xs font-medium text-primary hover:underline">
                Lupa Password?
              </Link>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 disabled:opacity-60"
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              {loading ? 'Memproses...' : 'Masuk'}
            </button>
          </form>

          <p className="mt-4 text-center text-xs text-muted-foreground">
            Silakan masuk dengan akun yang terdaftar di sistem.
          </p>

          <div className="mt-4 border-t pt-4">
            <Link to="/cek-tabungan" className="flex items-center justify-center gap-2 rounded-lg border border-primary/30 bg-primary/5 px-4 py-3 text-sm font-medium text-primary transition-all hover:bg-primary/10">
              <Search className="h-4 w-4" />
              Cek Tabungan Siswa
            </Link>
            <p className="mt-2 text-center text-xs text-muted-foreground">Orang tua dapat mengecek tabungan tanpa login.</p>
          </div>
        </div>

        <SchoolFooter />
      </div>
    </div>
  );
}

function AppLogo() {
  const { data: pengaturan } = usePengaturan();
  const logoUrl = pengaturan?.logo_url ? getLogoUrl() : null;
  return (
    <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
      {logoUrl ? (
        <img src={logoUrl} alt="Logo" className="h-16 w-16 rounded-2xl object-contain p-1" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
      ) : (
        <span className="text-2xl font-bold">S</span>
      )}
    </div>
  );
}

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setSent(true);
    toast.success('Link reset password telah dikirim ke email Anda.');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-emerald-50 p-4 dark:to-emerald-950/20">
      <div className="w-full max-w-md animate-slide-up">
        <div className="mb-6 text-center">
          <AppLogo />
          <h1 className="text-2xl font-bold text-primary">Lupa Password</h1>
        </div>

        <div className="rounded-2xl border bg-card p-6 shadow-xl">
          {sent ? (
            <div className="text-center space-y-3">
              <p className="text-sm text-muted-foreground">
                Link reset password telah dikirim ke <strong>{email}</strong>. Silakan cek email Anda.
              </p>
              <Link to="/login" className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline">
                <ArrowLeft className="h-4 w-4" /> Kembali ke Login
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-sm text-muted-foreground">Masukkan email Anda. Kami akan mengirim link untuk reset password.</p>
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="email@example.com"
                    className="h-11 w-full rounded-lg border bg-background pl-10 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
              </div>
              <button type="submit" disabled={loading} className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {loading ? 'Mengirim...' : 'Kirim Link Reset'}
              </button>
              <Link to="/login" className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                <ArrowLeft className="h-4 w-4" /> Kembali ke Login
              </Link>
            </form>
          )}
        </div>
        <SchoolFooter />
      </div>
    </div>
  );
}

export function ResetPasswordPage() {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      toast.error('Password tidak cocok');
      return;
    }
    if (password.length < 6) {
      toast.error('Password minimal 6 karakter');
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success('Password berhasil diubah. Silakan login kembali.');
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-emerald-50 p-4 dark:to-emerald-950/20">
      <div className="w-full max-w-md animate-slide-up">
        <div className="mb-6 text-center">
          <AppLogo />
          <h1 className="text-2xl font-bold text-primary">Reset Password</h1>
        </div>
        <div className="rounded-2xl border bg-card p-6 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Password Baru</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="h-11 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Konfirmasi Password</label>
              <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required className="h-11 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
            </div>
            <button type="submit" disabled={loading} className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60">
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              {loading ? 'Menyimpan...' : 'Simpan Password Baru'}
            </button>
          </form>
        </div>
        <SchoolFooter />
      </div>
    </div>
  );
}
