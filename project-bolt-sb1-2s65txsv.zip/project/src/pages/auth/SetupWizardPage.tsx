import { useState, type ChangeEvent, type FormEvent } from 'react';
import { Building2, Check, Eye, EyeOff, ImagePlus, LockKeyhole, Mail, MapPin, ShieldCheck, UserRound } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { BRAND } from '@/lib/brand';
import { toast } from 'sonner';

type SchoolForm = {
  nama_sekolah: string;
  npsn: string;
  alamat: string;
  kecamatan: string;
  kabupaten_kota: string;
  provinsi: string;
  email_sekolah: string;
  no_telepon: string;
};

type AdminForm = { nama: string; email: string; password: string; confirm: string };
type Logo = { dataUrl: string; contentType: string; name: string } | null;

const initialSchool: SchoolForm = { nama_sekolah: '', npsn: '', alamat: '', kecamatan: '', kabupaten_kota: '', provinsi: '', email_sekolah: '', no_telepon: '' };

export function SetupWizardPage({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(1);
  const [school, setSchool] = useState<SchoolForm>(initialSchool);
  const [admin, setAdmin] = useState<AdminForm>({ nama: '', email: '', password: '', confirm: '' });
  const [logo, setLogo] = useState<Logo>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const updateSchool = (key: keyof SchoolForm, value: string) => setSchool((current) => ({ ...current, [key]: value }));
  const updateAdmin = (key: keyof AdminForm, value: string) => setAdmin((current) => ({ ...current, [key]: value }));

  const handleLogo = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg'].includes(file.type) || file.size > 2 * 1024 * 1024) {
      toast.error('Logo harus PNG atau JPG dengan ukuran maksimal 2 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setLogo({ dataUrl: String(reader.result), contentType: file.type, name: file.name });
    reader.readAsDataURL(file);
  };

  const continueToAdmin = (event: FormEvent) => {
    event.preventDefault();
    if (Object.values(school).some((value) => !value.trim())) {
      toast.error('Lengkapi seluruh identitas sekolah terlebih dahulu.');
      return;
    }
    setStep(2);
  };

  const submitSetup = async (event: FormEvent) => {
    event.preventDefault();
    if (admin.password.length < 6) return toast.error('Password minimal 6 karakter.');
    if (admin.password !== admin.confirm) return toast.error('Konfirmasi password belum sama.');
    setLoading(true);
    const { data, error } = await supabase.functions.invoke('initial-setup', {
      body: { school, admin: { nama: admin.nama.trim(), email: admin.email.trim(), password: admin.password }, logo: logo ? { dataUrl: logo.dataUrl, contentType: logo.contentType } : undefined },
    });
    setLoading(false);
    if (error || !data?.success) {
      toast.error('Pendaftaran administrator belum berhasil. Silakan periksa data dan coba lagi.');
      return;
    }
    toast.success('Setup berhasil. Silakan masuk dengan akun administrator Anda.');
    onComplete();
  };

  const inputClass = 'h-11 w-full rounded-xl border border-border bg-background px-3 text-sm outline-none transition focus:border-primary focus:ring-4 focus:ring-primary/10';
  const field = (label: string, key: keyof SchoolForm, placeholder: string, icon: typeof Building2) => {
    const Icon = icon;
    return <label className="space-y-2"><span className="text-sm font-medium">{label}</span><span className="relative block"><Icon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input required value={school[key]} onChange={(event) => updateSchool(key, event.target.value)} placeholder={placeholder} className={`${inputClass} pl-10`} /></span></label>;
  };

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_right,_rgba(16,185,129,0.16),_transparent_36%),linear-gradient(135deg,hsl(var(--background)),hsl(var(--primary)/0.06))] px-4 py-8 sm:py-12">
      <div className="mx-auto grid max-w-6xl overflow-hidden rounded-3xl border bg-card shadow-2xl lg:grid-cols-[0.8fr_1.2fr]">
        <aside className="hidden bg-primary p-10 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
          <div><p className="text-sm font-semibold uppercase tracking-[0.24em] text-primary-foreground/70">Setup awal</p><h1 className="mt-6 text-4xl font-semibold leading-tight">{BRAND.appName}</h1><p className="mt-3 text-lg text-primary-foreground/80">{BRAND.subtitle}</p><p className="mt-10 max-w-xs text-sm leading-6 text-primary-foreground/75">Bangun pengelolaan tabungan sekolah yang rapi, mudah dipantau, dan dipercaya bersama.</p></div>
          <div className="flex items-center gap-3 text-sm text-primary-foreground/80"><ShieldCheck className="h-5 w-5" /> Data setup tersimpan aman di server sekolah</div>
        </aside>
        <section className="p-6 sm:p-10">
          <div className="mb-8 flex items-center gap-3"><div className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>{step > 1 ? <Check className="h-4 w-4" /> : '1'}</div><div className="h-px flex-1 bg-border" /><div className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold ${step === 2 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>2</div></div>
          {step === 1 ? <form onSubmit={continueToAdmin} className="space-y-5"><div><p className="text-sm font-semibold text-primary">SELAMAT DATANG DI SAKU SISWA</p><h2 className="mt-2 text-3xl font-semibold tracking-tight">Identitas sekolah</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Lengkapi identitas sekolah Anda untuk memulai penggunaan aplikasi.</p></div><div className="grid gap-4 sm:grid-cols-2">{field('Nama lengkap sekolah', 'nama_sekolah', 'Nama sekolah', Building2)}{field('NPSN', 'npsn', 'Nomor pokok sekolah', ShieldCheck)}<label className="space-y-2 sm:col-span-2"><span className="text-sm font-medium">Alamat sekolah</span><span className="relative block"><MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><textarea required value={school.alamat} onChange={(event) => updateSchool('alamat', event.target.value)} placeholder="Alamat lengkap sekolah" className={`${inputClass} h-20 py-3 pl-10`} /></span></label>{field('Kecamatan', 'kecamatan', 'Kecamatan', MapPin)}{field('Kabupaten/Kota', 'kabupaten_kota', 'Kabupaten atau kota', MapPin)}{field('Provinsi', 'provinsi', 'Provinsi', MapPin)}{field('Email sekolah', 'email_sekolah', 'sekolah@contoh.id', Mail)}{field('Nomor telepon', 'no_telepon', 'Nomor telepon sekolah', Building2)}</div><label className="flex cursor-pointer items-center gap-4 rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-4"><div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-xl bg-background">{logo ? <img src={logo.dataUrl} alt="Pratinjau logo sekolah" className="h-full w-full object-contain" /> : <ImagePlus className="h-5 w-5 text-primary" />}</div><div className="min-w-0 flex-1"><p className="text-sm font-medium">Logo sekolah <span className="font-normal text-muted-foreground">(opsional)</span></p><p className="mt-1 truncate text-xs text-muted-foreground">{logo?.name || 'PNG atau JPG, maksimal 2 MB'}</p></div><span className="rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground">Pilih file</span><input type="file" accept="image/png,image/jpeg" onChange={handleLogo} className="sr-only" /></label><button className="h-12 w-full rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition hover:bg-primary/90">Lanjutkan</button></form> : <form onSubmit={submitSetup} className="space-y-5"><div><p className="text-sm font-semibold text-primary">LANGKAH TERAKHIR</p><h2 className="mt-2 text-3xl font-semibold tracking-tight">Buat akun administrator</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Buat akun administrator untuk mengelola tabungan siswa di sekolah Anda.</p></div><label className="space-y-2"><span className="text-sm font-medium">Nama lengkap administrator</span><span className="relative block"><UserRound className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input required value={admin.nama} onChange={(event) => updateAdmin('nama', event.target.value)} className={`${inputClass} pl-10`} placeholder="Nama lengkap" /></span></label><label className="space-y-2"><span className="text-sm font-medium">Email untuk login</span><span className="relative block"><Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input required type="email" value={admin.email} onChange={(event) => updateAdmin('email', event.target.value)} className={`${inputClass} pl-10`} placeholder="admin@sekolah.id" /></span></label><label className="space-y-2"><span className="text-sm font-medium">Password</span><span className="relative block"><LockKeyhole className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input required type={showPassword ? 'text' : 'password'} value={admin.password} onChange={(event) => updateAdmin('password', event.target.value)} className={`${inputClass} pl-10 pr-10`} placeholder="Minimal 6 karakter" /><button type="button" onClick={() => setShowPassword((visible) => !visible)} className="absolute right-3 top-3 text-muted-foreground">{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></span></label><label className="space-y-2"><span className="text-sm font-medium">Konfirmasi password</span><input required type="password" value={admin.confirm} onChange={(event) => updateAdmin('confirm', event.target.value)} className={inputClass} placeholder="Ulangi password" /></label><div className="rounded-xl bg-muted/60 p-4 text-xs leading-5 text-muted-foreground">Akun ini akan menjadi administrator pertama secara otomatis melalui proses server yang aman. Password tidak disimpan di data sekolah.</div><div className="flex gap-3"><button type="button" onClick={() => setStep(1)} className="h-12 flex-1 rounded-xl border text-sm font-semibold transition hover:bg-muted">Kembali</button><button disabled={loading} className="h-12 flex-[2] rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition hover:bg-primary/90 disabled:opacity-60">{loading ? 'Mendaftarkan...' : 'Daftarkan administrator'}</button></div></form>}
        </section>
      </div>
    </main>
  );
}
