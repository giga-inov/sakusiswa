import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Loader2, PiggyBank, Phone, Code2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export function ChangePasswordPage() {
  const { user, profile, refreshProfile, logAktivitas } = useAuth();
  const navigate = useNavigate();
  const [current, setCurrent] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);

  const isFirstLogin = window.location.pathname.includes('first-login');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass !== confirm) {
      toast.error('Password baru tidak cocok');
      return;
    }
    if (newPass.length < 6) {
      toast.error('Password minimal 6 karakter');
      return;
    }
    setLoading(true);

    if (!isFirstLogin) {
      const { error: verifyError } = await supabase.auth.signInWithPassword({
        email: user?.email || '',
        password: current,
      });
      if (verifyError) {
        setLoading(false);
        toast.error('Password saat ini salah');
        return;
      }
    }

    const { error } = await supabase.auth.updateUser({ password: newPass });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }

    await supabase.from('profiles').update({ must_change_password: false }).eq('id', user?.id);
    if (profile?.role === 'siswa') {
      await supabase.from('siswa').update({ must_change_password: false }).eq('user_id', user?.id);
    }
    await refreshProfile();
    await logAktivitas('Ganti Password', 'Auth', 'Password berhasil diubah');
    toast.success('Password berhasil diubah');
    navigate(profile ? `/${profile.role}/dashboard` : '/login');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-emerald-50 p-4 dark:to-emerald-950/20">
      <div className="w-full max-w-md animate-slide-up">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
            <PiggyBank className="h-9 w-9" />
          </div>
          <h1 className="text-2xl font-bold text-primary">
            {isFirstLogin ? 'Ubah Password Awal' : 'Ganti Password'}
          </h1>
          {isFirstLogin && (
            <p className="mt-2 text-sm text-muted-foreground">
              Untuk keamanan, silakan ganti password awal (123456) dengan password baru.
            </p>
          )}
        </div>

        <div className="rounded-2xl border bg-card p-6 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isFirstLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Password Saat Ini</label>
                <input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} required className="h-11 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
              </div>
            )}
            <div className="space-y-2">
              <label className="text-sm font-medium">Password Baru</label>
              <input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} required className="h-11 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Konfirmasi Password Baru</label>
              <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required className="h-11 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
            </div>
            <button type="submit" disabled={loading} className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
              {loading ? 'Menyimpan...' : 'Simpan Password Baru'}
            </button>
          </form>
        </div>
        <div className="mt-6 flex flex-col items-center gap-2 text-center text-xs text-muted-foreground">
          <div className="flex flex-col items-center gap-1 sm:flex-row sm:gap-4">
            <span className="flex items-center gap-1.5">
              <Code2 className="h-3.5 w-3.5 text-primary" />
              Dikembangkan oleh <span className="font-semibold text-primary">GIGA INNOVATION</span>
            </span>
            <a href="tel:081329200985" className="flex items-center gap-1.5 transition-colors hover:text-primary">
              <Phone className="h-3.5 w-3.5" />
              081329200985
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
