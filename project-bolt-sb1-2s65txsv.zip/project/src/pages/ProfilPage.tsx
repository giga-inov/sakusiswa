import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useGuruKelas } from '@/hooks/queries';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { User, Mail, School, Phone, MapPin, BadgeCheck, Wallet, Calendar } from 'lucide-react';
import { formatRupiah, getInisial, formatTanggal } from '@/lib/format';

export function ProfilPage() {
  const { profile, user } = useAuth();

  const { data: guruKelas } = useGuruKelas(user?.id);
  const guru = guruKelas?.guru;
  const guruKelasNama = guruKelas?.kelas?.nama;

  const { data: siswa } = useQuery({
    queryKey: ['profil-siswa', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('*, kelas(*), tahun_pelajaran(*)').eq('user_id', user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user && profile?.role === 'siswa',
  });

  if (!profile) return null;

  const isGuru = profile.role === 'guru';
  const isSiswa = profile.role === 'siswa';

  return (
    <>
      <PageHeader title="Profil" description="Informasi akun Anda" />
      <div className="p-6">
        <div className="mx-auto max-w-2xl space-y-6">
          {/* Profile Header */}
          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 text-center sm:flex-row sm:text-left">
              <Avatar className="h-20 w-20 border-4 border-primary/20">
                <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">{getInisial(profile.nama)}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="text-xl font-bold">{profile.nama}</h2>
                <p className="text-sm text-muted-foreground">{profile.email}</p>
                <span className={`mt-2 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-medium ${isGuru ? 'bg-primary/10 text-primary' : isSiswa ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30' : 'bg-amber-100 text-amber-700'}`}>
                  <BadgeCheck className="h-3 w-3" />
                  {isGuru ? 'Guru Kelas' : isSiswa ? 'Siswa' : 'Administrator'}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Account Info */}
          <Card>
            <CardContent className="p-6">
              <h3 className="mb-4 text-base font-semibold">Informasi Akun</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><User className="h-4 w-4" /></div>
                  <div><p className="text-xs text-muted-foreground">Nama</p><p className="text-sm font-medium">{profile.nama}</p></div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><Mail className="h-4 w-4" /></div>
                  <div><p className="text-xs text-muted-foreground">Email</p><p className="text-sm font-medium">{profile.email}</p></div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><Calendar className="h-4 w-4" /></div>
                  <div><p className="text-xs text-muted-foreground">Bergabung sejak</p><p className="text-sm font-medium">{formatTanggal(profile.created_at)}</p></div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Guru-specific Info */}
          {isGuru && (
            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 text-base font-semibold">Informasi Guru</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><School className="h-4 w-4" /></div>
                    <div><p className="text-xs text-muted-foreground">Kelas yang Diampu</p><p className="text-sm font-medium">{guruKelasNama || 'Belum ditentukan'}</p></div>
                  </div>
                  {guru?.nip && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><BadgeCheck className="h-4 w-4" /></div>
                      <div><p className="text-xs text-muted-foreground">NIP</p><p className="text-sm font-medium">{guru.nip}</p></div>
                    </div>
                  )}
                  {guru?.no_hp && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><Phone className="h-4 w-4" /></div>
                      <div><p className="text-xs text-muted-foreground">No. HP</p><p className="text-sm font-medium">{guru.no_hp}</p></div>
                    </div>
                  )}
                  {guru?.alamat && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><MapPin className="h-4 w-4" /></div>
                      <div><p className="text-xs text-muted-foreground">Alamat</p><p className="text-sm font-medium">{guru.alamat}</p></div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Siswa-specific Info */}
          {isSiswa && (
            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 text-base font-semibold">Informasi Siswa</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><School className="h-4 w-4" /></div>
                    <div><p className="text-xs text-muted-foreground">Kelas</p><p className="text-sm font-medium">{siswa?.kelas?.nama || '-'}</p></div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><BadgeCheck className="h-4 w-4" /></div>
                    <div><p className="text-xs text-muted-foreground">NIS / NISN</p><p className="text-sm font-medium">{siswa?.nis} {siswa?.nisn ? `/ ${siswa.nisn}` : ''}</p></div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary"><Wallet className="h-4 w-4" /></div>
                    <div><p className="text-xs text-muted-foreground">Saldo Tabungan</p><p className="text-sm font-bold text-primary">{formatRupiah(siswa?.saldo || 0)}</p></div>
                  </div>
                  {siswa?.nama_orang_tua && (
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-muted-foreground"><User className="h-4 w-4" /></div>
                      <div><p className="text-xs text-muted-foreground">Nama Orang Tua</p><p className="text-sm font-medium">{siswa.nama_orang_tua}</p></div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
