import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PageSkeleton, EmptyState } from '@/components/Loaders';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Wallet, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { formatRupiah, formatTanggalSingkat, getInisial } from '@/lib/format';
import { Transaksi } from '@/types';

export function SiswaDashboard() {
  const { user, profile } = useAuth();

  const { data: siswa, isLoading } = useQuery({
    queryKey: ['siswa-by-user', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('*, kelas(*), tahun_pelajaran(*)').eq('user_id', user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: transaksiList } = useQuery({
    queryKey: ['siswa-transaksi', siswa?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from('transaksi').select('*').eq('siswa_id', siswa!.id).eq('status', 'aktif').order('created_at', { ascending: false }).limit(10);
      if (error) throw error;
      return data as Transaksi[];
    },
    enabled: !!siswa?.id,
  });

  if (isLoading) return <PageSkeleton />;

  return (
    <>
      <PageHeader title="Dashboard Siswa" description={`Selamat datang, ${profile?.nama}`} />
      <div className="space-y-6 p-6">
        <div className="grid gap-4 sm:grid-cols-3">
          <Card className="sm:col-span-1">
            <CardContent className="flex flex-col items-center gap-3 p-6 text-center">
              <Avatar className="h-20 w-20 border-4 border-primary/20">
                {siswa?.foto ? <img src={siswa.foto} alt={siswa.nama} className="h-full w-full rounded-full object-cover" /> : <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">{getInisial(siswa?.nama || 'S')}</AvatarFallback>}
              </Avatar>
              <div><p className="font-bold">{siswa?.nama}</p><p className="text-sm text-muted-foreground">{siswa?.kelas?.nama} • NIS: {siswa?.nis}</p></div>
            </CardContent>
          </Card>
          <Card className="sm:col-span-2">
            <CardContent className="flex h-full flex-col items-center justify-center gap-2 p-6">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Wallet className="h-7 w-7" /></div>
              <p className="text-sm text-muted-foreground">Saldo Tabungan Anda</p>
              <p className="text-4xl font-bold text-primary">{formatRupiah(siswa?.saldo || 0)}</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle className="text-base">Riwayat Transaksi Terakhir</CardTitle><CardDescription>10 transaksi terbaru</CardDescription></CardHeader>
          <CardContent>
            {(transaksiList || []).length === 0 ? (
              <EmptyState icon={<Wallet className="h-6 w-6" />} title="Belum ada transaksi" description="Riwayat tabungan Anda akan muncul di sini." />
            ) : (
              <div className="space-y-2">
                {(transaksiList || []).map((t) => {
                  const isSetoran = t.jenis === 'setoran';
                  return (
                    <div key={t.id} className="flex items-center justify-between rounded-lg border p-3 hover:bg-muted/50">
                      <div className="flex items-center gap-3">
                        <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${isSetoran ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>{isSetoran ? <ArrowUpRight className="h-5 w-5" /> : <ArrowDownRight className="h-5 w-5" />}</div>
                        <div><p className="text-sm font-medium capitalize">{t.jenis}</p><p className="text-xs text-muted-foreground">{t.keterangan} • {formatTanggalSingkat(t.tanggal)}</p></div>
                      </div>
                      <span className={`text-sm font-semibold ${isSetoran ? 'text-primary' : 'text-destructive'}`}>{isSetoran ? '+' : '-'}{formatRupiah(t.nominal)}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}

export function SiswaTransaksiPage() {
  const { user } = useAuth();
  const { data: siswa } = useQuery({
    queryKey: ['siswa-by-user', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('*').eq('user_id', user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: transaksiList, isLoading } = useQuery({
    queryKey: ['siswa-all-transaksi', siswa?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from('transaksi').select('*').eq('siswa_id', siswa!.id).eq('status', 'aktif').order('created_at', { ascending: false });
      if (error) throw error;
      return data as Transaksi[];
    },
    enabled: !!siswa?.id,
  });

  return (
    <>
      <PageHeader title="Riwayat Tabungan" description="Semua transaksi tabungan Anda" />
      <div className="p-6">
        <Card>
          <CardContent className="p-0">
            {isLoading ? <div className="p-4"><div className="h-8 w-full animate-pulse rounded bg-muted" /></div> : (transaksiList || []).length === 0 ? (
              <EmptyState icon={<Wallet className="h-6 w-6" />} title="Belum ada transaksi" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr><th className="px-4 py-3 font-medium">Tanggal</th><th className="px-4 py-3 font-medium">Jenis</th><th className="px-4 py-3 font-medium">Nominal</th><th className="px-4 py-3 font-medium">Saldo Setelah</th><th className="px-4 py-3 font-medium">Keterangan</th></tr>
                  </thead>
                  <tbody className="divide-y">
                    {(transaksiList || []).map((t) => (
                      <tr key={t.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                        <td className="px-4 py-3"><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${t.jenis === 'setoran' ? 'bg-primary/10 text-primary' : t.jenis === 'koreksi' ? 'bg-amber-100 text-amber-700' : 'bg-destructive/10 text-destructive'}`}>{t.jenis}</span></td>
                        <td className={`px-4 py-3 font-semibold ${t.jenis === 'setoran' ? 'text-primary' : t.jenis === 'koreksi' ? 'text-amber-600' : 'text-destructive'}`}>{t.jenis === 'setoran' ? '+' : t.jenis === 'koreksi' ? '=' : '-'}{formatRupiah(t.nominal)}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{t.saldo_setelah != null ? formatRupiah(t.saldo_setelah) : '-'}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{t.keterangan || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
