import { useState } from 'react';
import { useGuruList, useKelasList } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { TableSkeleton, EmptyState } from '@/components/Loaders';
import { Plus, Pencil, Trash2, Users, BadgeCheck, KeyRound, Mail } from 'lucide-react';
import { Guru } from '@/types';

interface FormState {
  nama: string;
  nip: string;
  email: string;
  password: string;
  alamat: string;
  no_hp: string;
  status: 'aktif' | 'nonaktif';
}

const empty: FormState = { nama: '', nip: '', email: '', password: '', alamat: '', no_hp: '', status: 'aktif' };

export function GuruPage() {
  const { data: guruList, isLoading, refetch } = useGuruList();
  const { data: kelasList } = useKelasList();
  const { logAktivitas } = useAuth();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Guru | null>(null);
  const [form, setForm] = useState<FormState>(empty);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const filtered = (guruList || []).filter((g) =>
    g.nama.toLowerCase().includes(search.toLowerCase()) || (g.nip || '').includes(search)
  );

  const openCreate = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (g: Guru) => {
    setEditing(g);
    setForm({ nama: g.nama, nip: g.nip || '', email: g.email || '', password: '', alamat: g.alamat || '', no_hp: g.no_hp || '', status: g.status });
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nama.trim()) { toast.error('Nama wajib diisi'); return; }
    setSaving(true);
    try {
      if (editing) {
        const updates: Record<string, any> = {
          nama: form.nama,
          nip: form.nip || null,
          email: form.email || null,
          alamat: form.alamat || null,
          no_hp: form.no_hp || null,
          status: form.status,
        };

        if (form.email && form.password && !editing.user_id) {
          const { data: session } = await supabase.auth.getSession();
          const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-guru`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${session.session?.access_token}`,
            },
            body: JSON.stringify({
              email: form.email, password: form.password, nama: form.nama,
              nip: form.nip || null, no_hp: form.no_hp || null, alamat: form.alamat || null,
              guru_id: editing.id,
            }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || 'Gagal membuat akun login');
          updates.user_id = result.user_id;
          toast.success(`Akun login dibuat: ${form.email}`);
        } else {
          const { error } = await supabase.from('guru').update(updates).eq('id', editing.id);
          if (error) throw error;
        }

        await logAktivitas('Edit', 'Guru', `Edit guru: ${form.nama}`);
        toast.success('Guru berhasil diperbarui');
      } else {
        if (form.email && form.password) {
          if (form.password.length < 6) {
            toast.error('Password minimal 6 karakter');
            setSaving(false);
            return;
          }
          const { data: session } = await supabase.auth.getSession();
          const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-guru`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${session.session?.access_token}`,
            },
            body: JSON.stringify({
              email: form.email, password: form.password, nama: form.nama,
              nip: form.nip || null, no_hp: form.no_hp || null, alamat: form.alamat || null,
            }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || 'Gagal membuat akun guru');
          await logAktivitas('Tambah', 'Guru', `Tambah guru: ${form.nama} (${form.email})`);
          toast.success(`Guru berhasil ditambahkan dengan akun login: ${form.email}`);
        } else {
          const { error } = await supabase.from('guru').insert({
            nama: form.nama,
            nip: form.nip || null,
            email: form.email || null,
            alamat: form.alamat || null,
            no_hp: form.no_hp || null,
            status: form.status,
          });
          if (error) throw error;

          await logAktivitas('Tambah', 'Guru', `Tambah guru: ${form.nama}`);
          toast.success('Guru berhasil ditambahkan');
        }
      }
      setOpen(false);
      refetch();
    } catch (err: any) {
      console.error('Guru save error:', err);
      toast.error(err.message || 'Gagal menyimpan guru');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const g = guruList?.find((x) => x.id === deleteId);
    await supabase.from('kelas').update({ wali_kelas_id: null }).eq('wali_kelas_id', deleteId);
    const { error } = await supabase.from('guru').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    await logAktivitas('Hapus', 'Guru', `Hapus guru: ${g?.nama || deleteId}`);
    toast.success('Guru berhasil dihapus');
    setDeleteId(null);
    refetch();
  };

  return (
    <>
      <PageHeader
        title="Manajemen Guru"
        description="Kelola data guru dan wali kelas"
        action={
          <Button onClick={openCreate} className="gap-2">
            <Plus className="h-4 w-4" /> Tambah Guru
          </Button>
        }
      />

      <div className="p-6">
        <div className="mb-4 flex items-center gap-2">
          <input
            type="text"
            placeholder="Cari nama atau NIP..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-10 w-full max-w-sm rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>

        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-4"><TableSkeleton /></div>
            ) : filtered.length === 0 ? (
              <EmptyState icon={<Users className="h-6 w-6" />} title="Belum ada guru" description="Klik Tambah Guru untuk menambahkan data guru." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 font-medium">Nama</th>
                      <th className="px-4 py-3 font-medium">NIP</th>
                      <th className="px-4 py-3 font-medium">Wali Kelas</th>
                      <th className="px-4 py-3 font-medium">Akun Login</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 text-right font-medium">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filtered.map((g) => (
                      <tr key={g.id} className="transition-colors hover:bg-muted/30">
                        <td className="px-4 py-3">
                          <p className="font-medium">{g.nama}</p>
                          <p className="text-xs text-muted-foreground">{g.no_hp || '-'}</p>
                        </td>
                        <td className="px-4 py-3">{g.nip || '-'}</td>
                        <td className="px-4 py-3">{kelasList?.find((k) => k.wali_kelas_id === g.id)?.nama || '-'}</td>
                        <td className="px-4 py-3">
                          {g.user_id ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-600 dark:bg-emerald-950/30">
                              <BadgeCheck className="h-3 w-3" /> Aktif
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                              <Mail className="h-3 w-3" /> {g.email || 'Belum ada'}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${g.status === 'aktif' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                            {g.status === 'aktif' && <BadgeCheck className="h-3 w-3" />}
                            {g.status}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" onClick={() => openEdit(g)}><Pencil className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" onClick={() => setDeleteId(g.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Guru' : 'Tambah Guru'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Nama Lengkap *</label>
                <input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">NIP</label>
                <input value={form.nip} onChange={(e) => setForm({ ...form, nip: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Email</label>
                <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">No. HP</label>
                <input value={form.no_hp} onChange={(e) => setForm({ ...form, no_hp: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Status</label>
                <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                  <option value="aktif">Aktif</option>
                  <option value="nonaktif">Nonaktif</option>
                </select>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-sm font-medium">Alamat</label>
                <textarea value={form.alamat} onChange={(e) => setForm({ ...form, alamat: e.target.value })} rows={2} className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
            </div>

            {/* Auth account section — only for new guru or guru without existing account */}
            {!editing?.user_id && (
              <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <KeyRound className="h-4 w-4 text-primary" />
                  <p className="text-sm font-medium">Akun Login Guru (Opsional)</p>
                </div>
                <p className="mb-3 text-xs text-muted-foreground">
                  Isi password (min. 6 karakter) jika ingin membuat akun login untuk guru. Jika dikosongkan, guru hanya tersimpan sebagai data tanpa akun login.
                </p>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Kosongkan jika belum perlu akun login" className="h-10 w-full rounded-lg border bg-background pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Batal</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Menyimpan...' : 'Simpan'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Guru?</AlertDialogTitle>
            <AlertDialogDescription>Tindakan ini tidak dapat dibatalkan. Data guru akan dihapus permanen.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
