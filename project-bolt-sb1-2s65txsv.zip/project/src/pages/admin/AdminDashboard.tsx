import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDashboardStats, useKelasList, useKelasDetail, usePengaturan } from '@/hooks/queries';
import { PageHeader } from '@/components/PageHeader';
import { BrandLogo } from '@/components/BrandHeader';
import { BRAND } from '@/lib/brand';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Users, GraduationCap, Wallet, ArrowLeftRight, TrendingUp, ArrowUpRight, ArrowDownRight, School, ChevronRight, Pencil } from 'lucide-react';
import { formatRupiah, formatTanggalSingkat, getInisial } from '@/lib/format';
import { PageSkeleton, EmptyState } from '@/components/Loaders';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, Legend,
} from 'recharts';

export function AdminDashboard() {
  const { data, isLoading } = useDashboardStats();
  const { data: kelasList } = useKelasList();
  const { data: pengaturan } = usePengaturan();
  const [selectedKelasId, setSelectedKelasId] = useState<string | null>(null);
  const { data: kelasDetail, isLoading: kelasLoading } = useKelasDetail(selectedKelasId);
  const navigate = useNavigate();

  if (isLoading) return <PageSkeleton />;

  const stats = data!;

  const statCards = [
    { label: 'Total Guru', value: stats.guruCount.toString(), icon: Users, color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/30' },
    { label: 'Total Siswa', value: stats.siswaCount.toString(), icon: GraduationCap, color: 'text-primary bg-primary/10' },
    { label: 'Total Saldo', value: formatRupiah(stats.totalSaldo), icon: Wallet, color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30' },
    { label: 'Setoran Hari Ini', value: formatRupiah(stats.todaySetoran), icon: ArrowUpRight, color: 'text-primary bg-primary/10' },
    { label: 'Penarikan Hari Ini', value: formatRupiah(stats.todayPenarikan), icon: ArrowDownRight, color: 'text-destructive bg-destructive/10' },
    { label: 'Transaksi Hari Ini', value: stats.transaksiToday.toString(), icon: ArrowLeftRight, color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30' },
  ];

  const chartData = stats.last7Days.map((d) => ({
    ...d,
    tanggal: formatTanggalSingkat(d.tanggal).slice(0, 5),
  }));

  return (
    <>
      <PageHeader title="Dashboard Admin" description={`Ringkasan data tabungan siswa ${pengaturan?.nama_sekolah || ''}`} />

      <div className="space-y-6 p-6">
        <Card className="border-primary/20 bg-gradient-to-r from-primary/5 via-card to-blue-50/60 dark:to-blue-950/20">
          <CardContent className="flex items-center gap-4 p-4 sm:p-5">
            <BrandLogo size="md" />
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Selamat datang di</p>
              <p className="truncate text-lg font-bold">{pengaturan?.nama_sekolah || `Selamat Datang di ${BRAND.appName}`}</p>
              <p className="text-sm text-muted-foreground">{pengaturan?.app_name || BRAND.appName} · {pengaturan?.app_subtitle || BRAND.subtitle}</p>
              <p className="mt-1 text-xs italic text-muted-foreground">"{pengaturan?.app_tagline || BRAND.tagline}"</p>
            </div>
          </CardContent>
        </Card>

        {/* Stat cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {statCards.map((card) => {
            const Icon = card.icon;
            return (
              <Card key={card.label} className="animate-slide-up transition-shadow hover:shadow-md">
                <CardContent className="flex items-center gap-4 p-5">
                  <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${card.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-muted-foreground">{card.label}</p>
                    <p className="text-xl font-bold leading-tight break-words whitespace-normal">{card.value}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Class selector */}
        <Card className="animate-slide-up">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <School className="h-5 w-5 text-primary" />
              Pilih Kelas
            </CardTitle>
            <CardDescription>Pilih kelas untuk melihat siswa, saldo, dan riwayat transaksi</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {(kelasList || []).map((k) => {
                const isActive = selectedKelasId === k.id;
                return (
                  <button
                    key={k.id}
                    onClick={() => setSelectedKelasId(isActive ? null : k.id)}
                    className={`flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition-all ${
                      isActive
                        ? 'border-primary bg-primary/5 shadow-md'
                        : 'border-border hover:border-primary/40 hover:bg-muted/50'
                    }`}
                  >
                    <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                      <School className="h-6 w-6" />
                    </div>
                    <span className={`text-sm font-semibold ${isActive ? 'text-primary' : ''}`}>{k.nama}</span>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Per-class detail */}
        {selectedKelasId && (
          <div className="animate-slide-up space-y-4">
            {kelasLoading ? (
              <PageSkeleton />
            ) : kelasDetail ? (
              <>
                <div className="grid gap-4 sm:grid-cols-3">
                  <Card>
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary"><GraduationCap className="h-5 w-5" /></div>
                        <div><p className="text-sm text-muted-foreground">Jumlah Siswa</p><p className="text-xl font-bold">{kelasDetail.siswaList.length}</p></div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary"><ArrowUpRight className="h-5 w-5" /></div>
                        <div><p className="text-sm text-muted-foreground">Total Setoran</p><p className="text-lg font-bold text-primary">{formatRupiah(kelasDetail.totalSetoran)}</p></div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10 text-destructive"><ArrowDownRight className="h-5 w-5" /></div>
                        <div><p className="text-sm text-muted-foreground">Total Penarikan</p><p className="text-lg font-bold text-destructive">{formatRupiah(kelasDetail.totalPenarikan)}</p></div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-base">Daftar Siswa</CardTitle>
                        <CardDescription>Siswa di kelas ini dan saldo tabungan mereka</CardDescription>
                      </div>
                      <div className="flex items-center gap-1 text-sm font-medium text-muted-foreground">
                        Lihat Data <ChevronRight className="h-4 w-4" />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    {kelasDetail.siswaList.length === 0 ? (
                      <EmptyState icon={<GraduationCap className="h-6 w-6" />} title="Belum ada siswa" description="Tambahkan siswa ke kelas ini di menu Siswa." />
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                            <tr>
                              <th className="px-4 py-3 font-medium">Siswa</th>
                              <th className="px-4 py-3 font-medium">NIS / NISN</th>
                              <th className="px-4 py-3 font-medium">Saldo</th>
                              <th className="px-4 py-3 font-medium">Status</th>
                              <th className="px-4 py-3 text-right font-medium">Aksi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y">
                            {kelasDetail.siswaList.map((s) => (
                              <tr key={s.id} className="transition-colors hover:bg-muted/30">
                                <td className="px-4 py-3">
                                  <div className="flex items-center gap-3">
                                    <Avatar className="h-8 w-8">
                                      {s.foto ? <img src={s.foto} alt={s.nama} className="h-full w-full rounded-full object-cover" /> : <AvatarFallback className="bg-primary/10 text-primary text-xs">{getInisial(s.nama)}</AvatarFallback>}
                                    </Avatar>
                                    <span className="font-medium">{s.nama}</span>
                                  </div>
                                </td>
                                <td className="px-4 py-3 text-xs">
                                  <p>{s.nis}</p>
                                  <p className="text-muted-foreground">{s.nisn || '-'}</p>
                                </td>
                                <td className="px-4 py-3 font-semibold text-primary">{formatRupiah(s.saldo)}</td>
                                <td className="px-4 py-3">
                                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${s.status === 'aktif' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{s.status}</span>
                                </td>
                                <td className="px-4 py-3">
                                  <div className="flex justify-end gap-1">
                                    <button onClick={() => navigate('/admin/siswa')} className="rounded-lg p-2 text-muted-foreground hover:bg-muted" title="Edit"><Pencil className="h-4 w-4" /></button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Riwayat Transaksi Kelas Ini</CardTitle>
                    <CardDescription>Transaksi terbaru siswa di kelas ini</CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">
                    {kelasDetail.transaksiList.length === 0 ? (
                      <EmptyState icon={<ArrowLeftRight className="h-6 w-6" />} title="Belum ada transaksi" description="Transaksi siswa kelas ini akan muncul di sini." />
                    ) : (
                      <div className="divide-y">
                        {kelasDetail.transaksiList.slice(0, 10).map((t) => {
                          const isSetoran = t.jenis === 'setoran';
                          return (
                            <div key={t.id} className="flex items-center justify-between p-3 transition-colors hover:bg-muted/50">
                              <div className="flex items-center gap-3">
                                <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${isSetoran ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>
                                  {isSetoran ? <ArrowUpRight className="h-5 w-5" /> : <ArrowDownRight className="h-5 w-5" />}
                                </div>
                                <div>
                                  <p className="text-sm font-medium">{t.siswa?.nama || 'Siswa'}</p>
                                  <p className="text-xs text-muted-foreground">{t.keterangan || t.jenis} • {formatTanggalSingkat(t.tanggal)}</p>
                                </div>
                              </div>
                              <span className={`text-sm font-semibold ${isSetoran ? 'text-primary' : 'text-destructive'}`}>
                                {isSetoran ? '+' : '-'}{formatRupiah(t.nominal)}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : null}
          </div>
        )}

        {/* Charts - always visible */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <TrendingUp className="h-5 w-5 text-primary" />
                Grafik Transaksi (7 Hari)
              </CardTitle>
              <CardDescription>Setoran dan penarikan dalam 7 hari terakhir</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorSetoran" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorPenarikan" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="tanggal" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '12px' }}
                    formatter={(value: number) => formatRupiah(value)}
                  />
                  <Legend wrapperStyle={{ fontSize: '12px' }} />
                  <Area type="monotone" dataKey="setoran" name="Setoran" stroke="hsl(var(--chart-1))" fill="url(#colorSetoran)" strokeWidth={2} />
                  <Area type="monotone" dataKey="penarikan" name="Penarikan" stroke="hsl(var(--destructive))" fill="url(#colorPenarikan)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Wallet className="h-5 w-5 text-primary" />
                Grafik Tabungan per Kelas
              </CardTitle>
              <CardDescription>Total saldo tabungan siswa per kelas</CardDescription>
            </CardHeader>
            <CardContent>
              {stats.kelasSaldo.length === 0 ? (
                <EmptyState icon={<Wallet className="h-6 w-6" />} title="Belum ada data" description="Data tabungan akan muncul di sini." />
              ) : (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={stats.kelasSaldo}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="nama" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '12px' }}
                      formatter={(value: number) => formatRupiah(value)}
                    />
                    <Bar dataKey="saldo" name="Total Saldo" fill="hsl(var(--chart-1))" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Per-class saldo summary */}
        <Card className="animate-slide-up">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Wallet className="h-5 w-5 text-primary" />
              Ringkasan Saldo per Kelas
            </CardTitle>
            <CardDescription>Total saldo tabungan siswa per kelas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {(stats.kelasSaldo || []).map((k) => (
                <div key={k.nama} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <School className="h-5 w-5" />
                    </div>
                    <span className="font-medium">{k.nama}</span>
                  </div>
                  <span className="text-lg font-bold text-primary">{formatRupiah(k.saldo)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="animate-slide-up">
          <CardHeader>
            <CardTitle className="text-base">Transaksi Terbaru</CardTitle>
            <CardDescription>5 transaksi terakhir seluruh sekolah</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.recentTransaksi.length === 0 ? (
              <EmptyState icon={<ArrowLeftRight className="h-6 w-6" />} title="Belum ada transaksi" description="Transaksi akan muncul di sini." />
            ) : (
              <div className="space-y-2">
                {stats.recentTransaksi.map((t) => {
                  const isSetoran = t.jenis === 'setoran';
                  return (
                    <div key={t.id} className="flex items-center justify-between rounded-lg border p-3 transition-colors hover:bg-muted/50">
                      <div className="flex items-center gap-3">
                        <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${isSetoran ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>
                          {isSetoran ? <ArrowUpRight className="h-5 w-5" /> : <ArrowDownRight className="h-5 w-5" />}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{t.siswa?.nama || 'Siswa'}</p>
                          <p className="text-xs text-muted-foreground">{t.keterangan || t.jenis} • {formatTanggalSingkat(t.tanggal)}</p>
                        </div>
                      </div>
                      <span className={`text-sm font-semibold ${isSetoran ? 'text-primary' : 'text-destructive'}`}>
                        {isSetoran ? '+' : '-'}{formatRupiah(t.nominal)}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
