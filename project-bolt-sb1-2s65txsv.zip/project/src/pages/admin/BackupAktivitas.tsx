import { useState, useRef, useMemo } from 'react';
import { useAktivitasList, useSiswaList, useGuruList, useKelasList, useTahunList, useAlumniList } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EmptyState, TableSkeleton } from '@/components/Loaders';
import { DatabaseBackup, Download, Upload, History, LogIn, LogOut, Plus, Pencil, Trash2, KeyRound, FileBarChart, Search, Ban, RotateCcw, ArrowUpRight, ArrowDownRight, CalendarPlus, Filter } from 'lucide-react';
import { formatWaktu } from '@/lib/format';

const AKSI_ICONS: Record<string, typeof History> = {
  Login: LogIn, Logout: LogOut, Tambah: Plus, Edit: Pencil, Hapus: Trash2,
  'Ganti Password': KeyRound, Laporan: FileBarChart, Export: Download, Import: Upload,
  Backup: DatabaseBackup, Restore: Upload, 'Kenaikan Kelas': DatabaseBackup,
  Setoran: ArrowUpRight, Penarikan: ArrowDownRight, Batalkan: Ban, Pulihkan: RotateCcw,
  'Input Tabungan': CalendarPlus,
};

export function BackupPage() {
  const { logAktivitas } = useAuth();
  const [restoring, setRestoring] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleBackup = async () => {
    try {
      const tables = ['profiles', 'guru', 'kelas', 'tahun_pelajaran', 'siswa', 'alumni', 'transaksi', 'aktivitas', 'pengaturan'];
      const backup: Record<string, any> = { _meta: { app: 'SAKU SISWA', timestamp: new Date().toISOString() } };
      for (const t of tables) {
        const { data, error } = await supabase.from(t).select('*');
        if (error) console.warn(`Backup ${t}:`, error.message);
        backup[t] = data || [];
      }
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-sakusiswa-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      await logAktivitas('Backup', 'Database', 'Backup database diunduh');
      toast.success('Backup database berhasil diunduh');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setRestoring(true);
    try {
      const text = await file.text();
      const backup = JSON.parse(text);
      const tables = ['guru', 'kelas', 'tahun_pelajaran', 'siswa', 'alumni', 'transaksi', 'aktivitas', 'pengaturan'];
      for (const t of tables) {
        if (backup[t] && Array.isArray(backup[t])) {
          for (const row of backup[t]) {
            const { id, ...rest } = row;
            const { error } = await supabase.from(t).upsert(rest);
            if (error) console.warn(`Restore ${t}:`, error.message);
          }
        }
      }
      await logAktivitas('Restore', 'Database', 'Restore database dari file');
      toast.success('Restore database berhasil');
    } catch (err: any) {
      toast.error('File backup tidak valid: ' + err.message);
    }
    setRestoring(false);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <>
      <PageHeader title="Backup & Restore" description="Cadangkan dan pulihkan data database" />
      <div className="p-6">
        <div className="grid gap-6 sm:grid-cols-2">
          <Card className="animate-slide-up">
            <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Download className="h-8 w-8" /></div>
              <div><h3 className="text-lg font-semibold">Backup Database</h3><p className="mt-1 text-sm text-muted-foreground">Unduh seluruh data dalam format JSON</p></div>
              <Button onClick={handleBackup} className="gap-2"><DatabaseBackup className="h-4 w-4" /> Download Backup</Button>
            </CardContent>
          </Card>
          <Card className="animate-slide-up">
            <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-100 text-amber-600 dark:bg-amber-950/30"><Upload className="h-8 w-8" /></div>
              <div><h3 className="text-lg font-semibold">Restore Database</h3><p className="mt-1 text-sm text-muted-foreground">Unggah file backup untuk memulihkan data</p></div>
              <input ref={fileRef} type="file" accept=".json" onChange={handleRestore} className="hidden" />
              <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={restoring} className="gap-2"><Upload className="h-4 w-4" /> {restoring ? 'Memulihkan...' : 'Pilih File Backup'}</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

export function AktivitasPage() {
  const { data, isLoading } = useAktivitasList();
  const [filterAksi, setFilterAksi] = useState('');
  const [filterModul, setFilterModul] = useState('');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    return (data || []).filter((a) => {
      if (filterAksi && a.aksi !== filterAksi) return false;
      if (filterModul && a.modul !== filterModul) return false;
      if (search) {
        const q = search.toLowerCase();
        return (a.detail || '').toLowerCase().includes(q) || (a.nama_user || '').toLowerCase().includes(q);
      }
      return true;
    });
  }, [data, filterAksi, filterModul, search]);

  const aksiOptions = [...new Set((data || []).map((a) => a.aksi))].sort();
  const modulOptions = [...new Set((data || []).map((a) => a.modul).filter(Boolean))] as string[];
  modulOptions.sort();

  return (
    <>
      <PageHeader title="Riwayat Aktivitas" description="Log semua aktivitas pengguna" />
      <div className="p-6 space-y-4">
        <Card className="p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filter:</span>
            </div>
            <select value={filterAksi} onChange={(e) => setFilterAksi(e.target.value)} className="h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30 sm:w-40">
              <option value="">Semua Aksi</option>
              {aksiOptions.map((a) => <option key={a} value={a}>{a}</option>)}
            </select>
            <select value={filterModul} onChange={(e) => setFilterModul(e.target.value)} className="h-9 w-full rounded-lg border bg-background px-2 text-sm outline-none focus:ring-2 focus:ring-primary/30 sm:w-40">
              <option value="">Semua Modul</option>
              {modulOptions.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari detail atau nama user..." className="h-9 w-full rounded-lg border bg-background pl-10 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <Button variant="outline" size="sm" onClick={() => { setFilterAksi(''); setFilterModul(''); setSearch(''); }}>Reset</Button>
          </div>
        </Card>

        <Card>
          <CardContent className="p-0">
            {isLoading ? <div className="p-4"><TableSkeleton /></div> : filtered.length === 0 ? (
              <EmptyState icon={<History className="h-6 w-6" />} title="Belum ada aktivitas" description="Tidak ada aktivitas yang sesuai dengan filter." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr><th className="px-4 py-3 font-medium">Waktu</th><th className="px-4 py-3 font-medium">Aksi</th><th className="px-4 py-3 font-medium">Modul</th><th className="px-4 py-3 font-medium">User</th><th className="px-4 py-3 font-medium">Detail</th></tr>
                  </thead>
                  <tbody className="divide-y">
                    {filtered.map((a) => {
                      const Icon = AKSI_ICONS[a.aksi] || History;
                      return (
                        <tr key={a.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3 text-xs text-muted-foreground">{formatWaktu(a.created_at)}</td>
                          <td className="px-4 py-3"><span className="inline-flex items-center gap-1.5"><Icon className="h-3.5 w-3.5 text-muted-foreground" /><span className="font-medium">{a.aksi}</span></span></td>
                          <td className="px-4 py-3 text-xs">{a.modul || '-'}</td>
                          <td className="px-4 py-3"><p className="text-xs font-medium">{a.nama_user || '-'}</p><p className="text-xs text-muted-foreground">{a.role}</p></td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{a.detail || '-'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
