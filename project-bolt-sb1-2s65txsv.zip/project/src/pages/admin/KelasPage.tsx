import { useKelasList, useGuruList } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { useState } from 'react';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { Skeleton, EmptyState } from '@/components/Loaders';
import { School, Users, Pencil, Plus, Trash2 } from 'lucide-react';
import { Kelas } from '@/types';

interface FormState {
  nama: string;
  tingkat: string;
  wali_kelas_id: string;
}

const empty: FormState = { nama: '', tingkat: '1', wali_kelas_id: '' };

export function KelasPage() {
  const { data: kelasList, isLoading, refetch } = useKelasList();
  const { data: guruList } = useGuruList();
  const { logAktivitas } = useAuth();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Kelas | null>(null);
  const [form, setForm] = useState<FormState>(empty);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const openCreate = () => {
    setEditing(null);
    setForm(empty);
    setOpen(true);
  };

  const openEdit = (k: Kelas) => {
    setEditing(k);
    setForm({ nama: k.nama, tingkat: String(k.tingkat), wali_kelas_id: k.wali_kelas_id || '' });
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nama.trim()) { toast.error('Nama kelas wajib diisi'); return; }
    const tingkat = parseInt(form.tingkat, 10);
    if (isNaN(tingkat) || tingkat < 1 || tingkat > 6) { toast.error('Tingkat harus antara 1-6'); return; }
    setSaving(true);
    try {
      if (editing) {
        const { error } = await supabase.from('kelas')
          .update({ nama: form.nama, tingkat, wali_kelas_id: form.wali_kelas_id || null })
          .eq('id', editing.id);
        if (error) throw error;

        await logAktivitas('Edit', 'Kelas', `Edit kelas: ${form.nama}`);
        toast.success('Kelas berhasil diperbarui');
      } else {
        const { error } = await supabase.from('kelas')
          .insert({ nama: form.nama, tingkat, wali_kelas_id: form.wali_kelas_id || null });
        if (error) throw error;

        await logAktivitas('Tambah', 'Kelas', `Tambah kelas: ${form.nama}`);
        toast.success('Kelas berhasil ditambahkan');
      }
      setOpen(false);
      refetch();
    } catch (err: any) {
      console.error('Kelas save error:', err);
      toast.error(err.message || 'Gagal menyimpan kelas');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const k = kelasList?.find((x) => x.id === deleteId);
    const { error } = await supabase.from('kelas').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    await logAktivitas('Hapus', 'Kelas', `Hapus kelas: ${k?.nama || deleteId}`);
    toast.success('Kelas berhasil dihapus');
    setDeleteId(null);
    refetch();
  };

  return (
    <>
      <PageHeader
        title="Manajemen Kelas"
        description="Kelola data kelas dan wali kelas"
        action={
          <Button onClick={openCreate} className="gap-2">
            <Plus className="h-4 w-4" /> Tambah Kelas
          </Button>
        }
      />

      <div className="p-6">
        {isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-40" />)}</div>
        ) : (kelasList || []).length === 0 ? (
          <EmptyState icon={<School className="h-6 w-6" />} title="Belum ada kelas" description="Klik Tambah Kelas untuk menambahkan data kelas." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {kelasList?.map((k) => {
              const wali = guruList?.find((g) => g.id === k.wali_kelas_id);
              return (
                <Card key={k.id} className="animate-slide-up transition-shadow hover:shadow-md">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                          <School className="h-6 w-6" />
                        </div>
                        <div>
                          <h3 className="font-bold">{k.nama}</h3>
                          <p className="text-xs text-muted-foreground">Tingkat {k.tingkat}</p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(k)}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => setDeleteId(k.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center gap-2 rounded-lg bg-muted/50 p-3">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Wali Kelas</p>
                        <p className="text-sm font-medium">{wali?.nama || 'Belum ditentukan'}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Kelas' : 'Tambah Kelas'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Nama Kelas *</label>
              <input
                value={form.nama}
                onChange={(e) => setForm({ ...form, nama: e.target.value })}
                placeholder="Contoh: Kelas 1"
                required
                className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Tingkat (1-6) *</label>
              <select
                value={form.tingkat}
                onChange={(e) => setForm({ ...form, tingkat: e.target.value })}
                className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
              >
                {[1, 2, 3, 4, 5, 6].map((t) => (
                  <option key={t} value={t}>Tingkat {t}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Wali Kelas</label>
              <select
                value={form.wali_kelas_id}
                onChange={(e) => setForm({ ...form, wali_kelas_id: e.target.value })}
                className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
              >
                <option value="">- Belum ditentukan -</option>
                {guruList?.filter((g) => g.status === 'aktif').map((g) => (
                  <option key={g.id} value={g.id}>{g.nama}</option>
                ))}
              </select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Batal</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Menyimpan...' : 'Simpan'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Kelas?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan. Pastikan tidak ada siswa di kelas ini sebelum menghapus.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
