import { GuruTabunganPage } from '@/pages/guru/GuruTabunganPage';
import { GuruTransaksiPage } from '@/pages/guru/GuruTransaksiPage';

export function InputTabunganAdminPage() {
  return <GuruTabunganPage isAdmin />;
}

export function TransaksiAdminPage() {
  return <GuruTransaksiPage isAdmin />;
}
