import { useState } from 'react';
import { GuruPage } from '@/pages/admin/GuruPage';
import { KelasPage } from '@/pages/admin/KelasPage';
import { Users, School } from 'lucide-react';
import { cn } from '@/lib/utils';

export function GuruKelasPage() {
  const [tab, setTab] = useState<'guru' | 'kelas'>('guru');

  return (
    <div className="flex flex-col gap-1">
      <div className="flex gap-2 border-b px-6 pt-4">
        <button
          onClick={() => setTab('guru')}
          className={cn(
            'flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-all',
            tab === 'guru' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
          )}
        >
          <Users className="h-4 w-4" /> Guru
        </button>
        <button
          onClick={() => setTab('kelas')}
          className={cn(
            'flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-all',
            tab === 'kelas' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
          )}
        >
          <School className="h-4 w-4" /> Kelas
        </button>
      </div>
      {tab === 'guru' ? <GuruPage /> : <KelasPage />}
    </div>
  );
}
