import { useState } from 'react';
import { useSiswaList, useKelasList, useTahunList } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { TableSkeleton, EmptyState } from '@/components/Loaders';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Plus, Pencil, Trash2, GraduationCap, QrCode, ChevronLeft, ChevronRight } from 'lucide-react';
import { Siswa } from '@/types';
import { formatRupiah, getInisial } from '@/lib/format';
import { QRCodeSVG } from 'qrcode.react';

const PAGE_SIZE = 10;

interface FormState {
  nis: string;
  nisn: string;
  nama: string;
  jenis_kelamin: 'L' | 'P';
  tanggal_lahir: string;
  alamat: string;
  nama_orang_tua: string;
  no_hp_orang_tua: string;
  kelas_id: string;
  tahun_pelajaran_id: string;
  saldo: string;
  status: 'aktif' | 'nonaktif';
}

export function SiswaPage() {
  const { data: kelasList } = useKelasList();
  const { data: tahunList } = useTahunList();
  const activeTahun = tahunList?.find((t) => t.aktif);
  const { data: siswaList, isLoading, refetch } = useSiswaList({ tahun_id: activeTahun?.id });
  const { logAktivitas } = useAuth();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Siswa | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [page, setPage] = useState(1);
  const [qrSiswa, setQrSiswa] = useState<Siswa | null>(null);

  const emptyForm: FormState = {
    nis: '', nisn: '', nama: '', jenis_kelamin: 'L', tanggal_lahir: '', alamat: '',
    nama_orang_tua: '', no_hp_orang_tua: '', kelas_id: kelasList?.[0]?.id || '',
    tahun_pelajaran_id: activeTahun?.id || '', saldo: '0', status: 'aktif',
  };
  const [form, setForm] = useState<FormState>(emptyForm);

  const filtered = (siswaList || []).filter((s) => {
    const matchSearch = s.nama.toLowerCase().includes(search.toLowerCase()) || s.nis.includes(search) || (s.nisn || '').includes(search);
    const matchKelas = !filterKelas || s.kelas_id === filterKelas;
    return matchSearch && matchKelas;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (s: Siswa) => {
    setEditing(s);
    setForm({
      nis: s.nis, nisn: s.nisn || '', nama: s.nama, jenis_kelamin: s.jenis_kelamin,
      tanggal_lahir: s.tanggal_lahir || '', alamat: s.alamat || '', nama_orang_tua: s.nama_orang_tua || '',
      no_hp_orang_tua: s.no_hp_orang_tua || '', kelas_id: s.kelas_id, tahun_pelajaran_id: s.tahun_pelajaran_id,
      saldo: String(s.saldo), status: s.status,
    });
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nis.trim() || !form.nama.trim()) { toast.error('NIS dan Nama wajib diisi'); return; }
    if (!form.kelas_id || !form.tahun_pelajaran_id) { toast.error('Kelas dan Tahun Pelajaran wajib dipilih'); return; }
    setSaving(true);
    try {
      if (editing) {
        const { error } = await supabase.from('siswa').update({
          nis: form.nis, nisn: form.nisn || null, nama: form.nama, jenis_kelamin: form.jenis_kelamin,
          tanggal_lahir: form.tanggal_lahir || null, alamat: form.alamat || null,
          nama_orang_tua: form.nama_orang_tua || null, no_hp_orang_tua: form.no_hp_orang_tua || null,
          kelas_id: form.kelas_id, tahun_pelajaran_id: form.tahun_pelajaran_id,
          status: form.status,
        }).eq('id', editing.id);
        if (error) throw error;
        await logAktivitas('Edit', 'Siswa', `Edit siswa: ${form.nama}`);
        toast.success('Siswa berhasil diperbarui');
      } else {
        const qrValue = `SAKUSISWA-${form.nis}-${Date.now()}`;
        const { error } = await supabase.from('siswa').insert({
          nis: form.nis, nisn: form.nisn || null, nama: form.nama, jenis_kelamin: form.jenis_kelamin,
          tanggal_lahir: form.tanggal_lahir || null, alamat: form.alamat || null,
          nama_orang_tua: form.nama_orang_tua || null, no_hp_orang_tua: form.no_hp_orang_tua || null,
          kelas_id: form.kelas_id, tahun_pelajaran_id: form.tahun_pelajaran_id,
          saldo: Number(form.saldo) || 0, status: form.status, qr_code: qrValue,
          must_change_password: true,
        });
        if (error) throw error;
        await logAktivitas('Tambah', 'Siswa', `Tambah siswa: ${form.nama}`);
        toast.success('Siswa berhasil ditambahkan');
      }
      setOpen(false);
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Gagal menyimpan siswa');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const s = siswaList?.find((x) => x.id === deleteId);
    const { error } = await supabase.from('siswa').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    await logAktivitas('Hapus', 'Siswa', `Hapus siswa: ${s?.nama || deleteId}`);
    toast.success('Siswa berhasil dihapus');
    setDeleteId(null);
    refetch();
  };

  return (
    <>
      <PageHeader
        title="Manajemen Siswa"
        description="Kelola data siswa dan tabungan"
        action={<Button onClick={openCreate} className="gap-2"><Plus className="h-4 w-4" /> Tambah Siswa</Button>}
      />

      <div className="p-6">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <input
            type="text"
            placeholder="Cari nama, NIS, atau NISN..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="h-10 flex-1 max-w-sm rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
          />
          <select value={filterKelas} onChange={(e) => { setFilterKelas(e.target.value); setPage(1); }} className="h-10 rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30">
            <option value="">Semua Kelas</option>
            {kelasList?.map((k) => <option key={k.id} value={k.id}>{k.nama}</option>)}
          </select>
        </div>

        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-4"><TableSkeleton /></div>
            ) : paged.length === 0 ? (
              <EmptyState icon={<GraduationCap className="h-6 w-6" />} title="Belum ada siswa" description="Tambahkan data siswa untuk mulai mengelola tabungan." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 font-medium">Siswa</th>
                      <th className="px-4 py-3 font-medium">NIS / NISN</th>
                      <th className="px-4 py-3 font-medium">Kelas</th>
                      <th className="px-4 py-3 font-medium">Saldo</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 text-right font-medium">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {paged.map((s) => (
                      <tr key={s.id} className="transition-colors hover:bg-muted/30">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-9 w-9">
                              {s.foto ? <img src={s.foto} alt={s.nama} className="h-full w-full rounded-full object-cover" /> : <AvatarFallback className="bg-primary/10 text-primary text-xs">{getInisial(s.nama)}</AvatarFallback>}
                            </Avatar>
                            <div>
                              <p className="font-medium">{s.nama}</p>
                              <p className="text-xs text-muted-foreground">{s.jenis_kelamin === 'L' ? 'Laki-laki' : 'Perempuan'}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs">
                          <p>{s.nis}</p>
                          <p className="text-muted-foreground">{s.nisn || '-'}</p>
                        </td>
                        <td className="px-4 py-3">{s.kelas?.nama || '-'}</td>
                        <td className="px-4 py-3 font-semibold text-primary">{formatRupiah(s.saldo)}</td>
                        <td className="px-4 py-3">
                          <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${s.status === 'aktif' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{s.status}</span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" onClick={() => setQrSiswa(s)} title="QR Code"><QrCode className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" onClick={() => openEdit(s)}><Pencil className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" onClick={() => setDeleteId(s.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="mt-4 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">Menampilkan {(page - 1) * PAGE_SIZE + 1}-{Math.min(page * PAGE_SIZE, filtered.length)} dari {filtered.length}</p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" disabled={page === 1} onClick={() => setPage(page - 1)}><ChevronLeft className="h-4 w-4" /></Button>
              <span className="text-sm">{page} / {totalPages}</span>
              <Button variant="outline" size="icon" disabled={page === totalPages} onClick={() => setPage(page + 1)}><ChevronRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Siswa' : 'Tambah Siswa'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5"><label className="text-sm font-medium">NIS *</label><input value={form.nis} onChange={(e) => setForm({ ...form, nis: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">NISN</label><input value={form.nisn} onChange={(e) => setForm({ ...form, nisn: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5 sm:col-span-2"><label className="text-sm font-medium">Nama Lengkap *</label><input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Jenis Kelamin</label><select value={form.jenis_kelamin} onChange={(e) => setForm({ ...form, jenis_kelamin: e.target.value as any })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="L">Laki-laki</option><option value="P">Perempuan</option></select></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Tanggal Lahir</label><input type="date" value={form.tanggal_lahir} onChange={(e) => setForm({ ...form, tanggal_lahir: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Kelas *</label><select value={form.kelas_id} onChange={(e) => setForm({ ...form, kelas_id: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="">Pilih Kelas</option>{kelasList?.map((k) => <option key={k.id} value={k.id}>{k.nama}</option>)}</select></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Tahun Pelajaran *</label><select value={form.tahun_pelajaran_id} onChange={(e) => setForm({ ...form, tahun_pelajaran_id: e.target.value })} required className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="">Pilih Tahun</option>{tahunList?.map((t) => <option key={t.id} value={t.id}>{t.nama}</option>)}</select></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Saldo Awal</label><input type="number" value={form.saldo} onChange={(e) => setForm({ ...form, saldo: e.target.value })} disabled={!!editing} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 disabled:opacity-60" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Status</label><select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="aktif">Aktif</option><option value="nonaktif">Nonaktif</option></select></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">Nama Orang Tua</label><input value={form.nama_orang_tua} onChange={(e) => setForm({ ...form, nama_orang_tua: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5"><label className="text-sm font-medium">No. HP Orang Tua</label><input value={form.no_hp_orang_tua} onChange={(e) => setForm({ ...form, no_hp_orang_tua: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
              <div className="space-y-1.5 sm:col-span-2"><label className="text-sm font-medium">Alamat</label><textarea value={form.alamat} onChange={(e) => setForm({ ...form, alamat: e.target.value })} rows={2} className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Batal</Button>
              <Button type="submit" disabled={saving}>{saving ? 'Menyimpan...' : 'Simpan'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!qrSiswa} onOpenChange={(v) => !v && setQrSiswa(null)}>
        <DialogContent className="max-w-xs text-center">
          <DialogHeader><DialogTitle>QR Code Siswa</DialogTitle></DialogHeader>
          {qrSiswa && (
            <div className="flex flex-col items-center gap-3 py-4">
              <div className="rounded-xl border-2 border-primary p-4">
                <QRCodeSVG value={qrSiswa.qr_code || qrSiswa.id} size={180} />
              </div>
              <div>
                <p className="font-bold">{qrSiswa.nama}</p>
                <p className="text-sm text-muted-foreground">NIS: {qrSiswa.nis} • {qrSiswa.kelas?.nama}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Siswa?</AlertDialogTitle>
            <AlertDialogDescription>Data siswa dan semua transaksinya akan dihapus permanen.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
