import { useState, useRef, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EmptyState } from '@/components/Loaders';
import { UploadCloud, FileSpreadsheet, CheckCircle2, AlertTriangle, XCircle, FileUp, ArrowLeft, Download } from 'lucide-react';
import { formatRupiah, formatTanggalSingkat } from '@/lib/format';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

type ParsedRow = {
  tanggal: string;
  nisn: string;
  nama: string;
  kelas: string;
  setoran: number;
  penarikan: number;
  keterangan: string;
  saldo?: number;
};

type PreviewRow = ParsedRow & {
  siswaId: string | null;
  status: 'ok' | 'duplikat' | 'nisn_tidak_ditemukan' | 'nominal_nol';
  existingTrxId?: string;
};

type ImportMode = 'transaksi' | 'saldo_awal';

type ImportResult = {
  berhasil: number;
  duplikat: number;
  gagal: number;
};

const COLUMN_ALIASES: Record<string, string[]> = {
  tanggal: ['tanggal', 'tanggal transaksi', 'tgl', 'date', 'tgl transaksi'],
  nisn: ['nisn', 'nomor nisn', 'no nisn', 'nisn siswa'],
  nama: ['nama', 'nama siswa', 'namasiswa', 'name', 'nama lengkap'],
  kelas: ['kelas', 'nama kelas', 'class'],
  setoran: ['setoran', 'setor', 'deposit', 'kredit', 'masuk'],
  penarikan: ['penarikan', 'tarik', 'withdraw', 'debet', 'keluar'],
  keterangan: ['keterangan', 'ket', 'note', 'notes', 'deskripsi', 'description'],
  saldo: ['saldo', 'saldo awal', 'balance', 'total'],
};

function normalizeHeader(h: string): string {
  return h.toLowerCase().trim().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ');
}

function findColumn(headers: string[], key: string): string | null {
  const aliases = COLUMN_ALIASES[key];
  for (const h of headers) {
    const nh = normalizeHeader(h);
    if (aliases.includes(nh)) return h;
  }
  return null;
}

function parseDateValue(val: unknown): string {
  if (!val) return new Date().toISOString().split('T')[0];
  if (val instanceof Date) return val.toISOString().split('T')[0];
  if (typeof val === 'number') {
    const date = new Date(Date.UTC(1899, 11, 30 + val));
    return date.toISOString().split('T')[0];
  }
  const s = String(val).trim();
  const parts = s.split(/[\/\-\.]/);
  if (parts.length === 3) {
    let [a, b, c] = parts.map(Number);
    if (c < 100) c += 2000;
    if (a > 31) { [a, b, c] = [c, b, a]; }
    return `${c}-${String(b).padStart(2, '0')}-${String(a).padStart(2, '0')}`;
  }
  const d = new Date(s);
  if (!isNaN(d.getTime())) return d.toISOString().split('T')[0];
  return new Date().toISOString().split('T')[0];
}

function parseNumber(val: unknown): number {
  if (typeof val === 'number') return val;
  if (!val) return 0;
  const s = String(val).replace(/[^0-9\-]/g, '');
  const n = Number(s);
  return isNaN(n) ? 0 : n;
}

function detectMode(headers: string[]): ImportMode {
  const hasTanggal = findColumn(headers, 'tanggal') !== null;
  const hasSetoran = findColumn(headers, 'setoran') !== null;
  const hasPenarikan = findColumn(headers, 'penarikan') !== null;
  const hasSaldo = findColumn(headers, 'saldo') !== null;
  if (hasSaldo && !hasTanggal && !hasSetoran && !hasPenarikan) return 'saldo_awal';
  if (hasTanggal || hasSetoran || hasPenarikan) return 'transaksi';
  if (hasSaldo) return 'saldo_awal';
  return 'transaksi';
}

export function ImportExcelPage() {
  const { user, profile, logAktivitas } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState('');
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [mode, setMode] = useState<ImportMode>('transaksi');
  const [preview, setPreview] = useState<PreviewRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  const { data: siswaList } = useQuery({
    queryKey: ['all-siswa-for-import'],
    queryFn: async () => {
      const { data, error } = await supabase.from('siswa').select('id, nisn, nama, kelas_id, kelas:kelas(nama)');
      if (error) throw error;
      return (data || []).map((s: any) => ({
        id: s.id as string,
        nisn: (s.nisn || null) as string | null,
        nama: s.nama as string,
        kelas_id: s.kelas_id as string,
        kelas_nama: Array.isArray(s.kelas) ? (s.kelas[0]?.nama || null) : (s.kelas?.nama || null),
      }));
    },
  });

  const { data: existingTrx } = useQuery({
    queryKey: ['all-transaksi-for-dedup'],
    queryFn: async () => {
      const { data, error } = await supabase.from('transaksi').select('id, siswa_id, tanggal, jenis, nominal, keterangan');
      if (error) throw error;
      return data as Array<{ id: string; siswa_id: string; tanggal: string; jenis: string; nominal: number; keterangan: string | null }>;
    },
    enabled: parsedRows.length > 0,
  });

  const handleFile = useCallback((file: File) => {
    setImportResult(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array', cellDates: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: '' });
        if (json.length === 0) {
          toast.error('File Excel kosong atau tidak ada data');
          return;
        }
        const headers = Object.keys(json[0]);
        const colTanggal = findColumn(headers, 'tanggal');
        const colNisn = findColumn(headers, 'nisn');
        const colNama = findColumn(headers, 'nama');
        const colKelas = findColumn(headers, 'kelas');
        const colSetoran = findColumn(headers, 'setoran');
        const colPenarikan = findColumn(headers, 'penarikan');
        const colKeterangan = findColumn(headers, 'keterangan');
        const colSaldo = findColumn(headers, 'saldo');

        if (!colNisn) {
          toast.error('Kolom NISN tidak ditemukan. Pastikan ada kolom "NISN" di file Excel.');
          return;
        }

        const detectedMode = detectMode(headers);
        setMode(detectedMode);

        const rows: ParsedRow[] = json.map((r) => ({
          tanggal: colTanggal ? parseDateValue(r[colTanggal]) : new Date().toISOString().split('T')[0],
          nisn: String(r[colNisn] || '').trim(),
          nama: colNama ? String(r[colNama] || '').trim() : '',
          kelas: colKelas ? String(r[colKelas] || '').trim() : '',
          setoran: colSetoran ? parseNumber(r[colSetoran]) : (detectedMode === 'saldo_awal' && colSaldo ? parseNumber(r[colSaldo]) : 0),
          penarikan: colPenarikan ? parseNumber(r[colPenarikan]) : 0,
          keterangan: colKeterangan ? String(r[colKeterangan] || '').trim() : '',
          saldo: colSaldo ? parseNumber(r[colSaldo]) : undefined,
        })).filter((r) => r.nisn);

        setParsedRows(rows);
        toast.success(`${rows.length} baris data terbaca dari ${file.name}`);
      } catch (err: any) {
        toast.error('Gagal membaca file Excel: ' + (err.message || 'format tidak didukung'));
      }
    };
    reader.readAsArrayBuffer(file);
  }, []);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'xlsx' && ext !== 'xls') {
      toast.error('Hanya file Excel (.xlsx atau .xls) yang didukung');
      return;
    }
    setFileName(file.name);
    setPreview([]);
    setParsedRows([]);
    handleFile(file);
  };

  const handlePreview = () => {
    if (!siswaList) { toast.error('Data siswa belum dimuat'); return; }
    if (parsedRows.length === 0) { toast.error('Belum ada data untuk dipreview'); return; }

    const siswaByNisn = new Map<string, string>();
    for (const s of siswaList) {
      if (s.nisn) siswaByNisn.set(s.nisn.trim(), s.id);
    }

    const existingSet = new Set<string>();
    for (const t of existingTrx || []) {
      existingSet.add(`${t.siswa_id}|${t.tanggal}|${t.jenis}|${t.nominal}|${(t.keterangan || '').trim()}`);
    }

    const rows: PreviewRow[] = parsedRows.map((r) => {
      const siswaId = siswaByNisn.get(r.nisn) || null;
      let status: PreviewRow['status'] = 'ok';
      const setoran = mode === 'saldo_awal' ? (r.saldo || r.setoran || 0) : r.setoran;
      const penarikan = r.penarikan;
      const keterangan = mode === 'saldo_awal' ? (r.keterangan || 'Saldo Awal Import Excel') : r.keterangan;
      const jenis = mode === 'saldo_awal' ? 'setoran' : (setoran > 0 ? 'setoran' : 'penarikan');
      const nominal = mode === 'saldo_awal' ? setoran : (setoran > 0 ? setoran : penarikan);

      if (!siswaId) {
        status = 'nisn_tidak_ditemukan';
      } else if (nominal <= 0) {
        status = 'nominal_nol';
      } else {
        const dedupKey = `${siswaId}|${r.tanggal}|${jenis}|${nominal}|${keterangan.trim()}`;
        if (existingSet.has(dedupKey)) {
          status = 'duplikat';
        }
      }

      return { ...r, setoran, penarikan, keterangan, siswaId, status };
    });

    setPreview(rows);
    const okCount = rows.filter((r) => r.status === 'ok').length;
    const dupCount = rows.filter((r) => r.status === 'duplikat').length;
    const notFoundCount = rows.filter((r) => r.status === 'nisn_tidak_ditemukan').length;
    toast.info(`Preview: ${okCount} siap import, ${dupCount} duplikat, ${notFoundCount} NISN tidak ditemukan`);
  };

  const handleImport = async () => {
    const toImport = preview.filter((r) => r.status === 'ok');
    if (toImport.length === 0) { toast.error('Tidak ada data siap untuk diimport'); return; }

    setImporting(true);
    let berhasil = 0;
    let duplikat = preview.filter((r) => r.status === 'duplikat').length;
    let gagal = 0;

    try {
      const insertBatch: Array<{
        siswa_id: string;
        tanggal: string;
        jenis: string;
        nominal: number;
        keterangan: string;
        petugas_id: string | null;
        petugas_nama: string;
      }> = [];

      for (const r of toImport) {
        if (!r.siswaId) { gagal++; continue; }
        const jenis = mode === 'saldo_awal' ? 'setoran' : (r.setoran > 0 ? 'setoran' : 'penarikan');
        const nominal = mode === 'saldo_awal' ? (r.saldo || r.setoran) : (r.setoran > 0 ? r.setoran : r.penarikan);
        if (nominal <= 0) { gagal++; continue; }
        insertBatch.push({
          siswa_id: r.siswaId,
          tanggal: r.tanggal,
          jenis,
          nominal,
          keterangan: r.keterangan || (mode === 'saldo_awal' ? 'Saldo Awal Import Excel' : `${jenis} Import Excel`),
          petugas_id: user?.id || null,
          petugas_nama: profile?.nama || 'Admin Import',
        });
      }

      // Insert in batches of 100
      for (let i = 0; i < insertBatch.length; i += 100) {
        const batch = insertBatch.slice(i, i + 100);
        const { error } = await supabase.from('transaksi').insert(batch);
        if (error) {
          gagal += batch.length;
          console.error('Import batch error:', error.message);
        } else {
          berhasil += batch.length;
        }
      }

      setImportResult({ berhasil, duplikat, gagal });
      await logAktivitas('Import', 'Excel', `${berhasil} transaksi diimport dari file ${fileName}`);
      toast.success(`Import selesai: ${berhasil} berhasil, ${duplikat} duplikat, ${gagal} gagal`);
      setPreview([]);
      setParsedRows([]);
      setFileName('');
    } catch (err: any) {
      toast.error('Gagal import: ' + (err.message || 'terjadi kesalahan'));
    }
    setImporting(false);
  };

  const handleReset = () => {
    setParsedRows([]);
    setPreview([]);
    setFileName('');
    setImportResult(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  const downloadTemplate = () => {
    const template = mode === 'saldo_awal'
      ? [
          { NISN: '0012345678', 'Nama Siswa': 'Ahmad', Kelas: 'Kelas 4', 'Saldo Awal': 150000 },
          { NISN: '0012345679', 'Nama Siswa': 'Budi', Kelas: 'Kelas 4', 'Saldo Awal': 125000 },
        ]
      : [
          { Tanggal: '01/09/2026', NISN: '0012345678', 'Nama Siswa': 'Ahmad', Kelas: 'Kelas 4', Setoran: 5000, Penarikan: 0, Keterangan: 'Setoran harian' },
          { Tanggal: '02/09/2026', NISN: '0012345678', 'Nama Siswa': 'Ahmad', Kelas: 'Kelas 4', Setoran: 10000, Penarikan: 0, Keterangan: '' },
          { Tanggal: '03/09/2026', NISN: '0012345679', 'Nama Siswa': 'Budi', Kelas: 'Kelas 4', Setoran: 0, Penarikan: 5000, Keterangan: 'Penarikan' },
        ];
    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Tabungan');
    XLSX.writeFile(wb, 'template_tabungan.xlsx');
  };

  const okCount = preview.filter((r) => r.status === 'ok').length;
  const dupCount = preview.filter((r) => r.status === 'duplikat').length;
  const notFoundCount = preview.filter((r) => r.status === 'nisn_tidak_ditemukan').length;
  const zeroCount = preview.filter((r) => r.status === 'nominal_nol').length;

  return (
    <>
      <PageHeader
        title="Import Excel"
        description="Import data tabungan dari file Microsoft Excel"
        action={
          <Button variant="outline" className="gap-2" onClick={downloadTemplate}>
            <Download className="h-4 w-4" /> Template Excel
          </Button>
        }
      />

      <div className="p-6 space-y-4">
        {importResult && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-6 w-6 text-primary" />
                <div>
                  <p className="font-semibold">Import Selesai</p>
                  <p className="text-sm text-muted-foreground">
                    Berhasil: <span className="font-bold text-primary">{importResult.berhasil}</span> transaksi •
                    Duplikat: <span className="font-bold text-amber-600">{importResult.duplikat}</span> •
                    Gagal: <span className="font-bold text-destructive">{importResult.gagal}</span>
                  </p>
                </div>
                <Button variant="outline" size="sm" className="ml-auto" onClick={handleReset}>Import Lagi</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upload area */}
        <Card>
          <CardContent className="p-6">
            <div
              className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-border p-10 text-center transition-colors hover:border-primary/40 hover:bg-primary/5"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const file = e.dataTransfer.files?.[0];
                if (file) {
                  const ext = file.name.split('.').pop()?.toLowerCase();
                  if (ext === 'xlsx' || ext === 'xls') {
                    setFileName(file.name);
                    setPreview([]);
                    setParsedRows([]);
                    handleFile(file);
                  } else {
                    toast.error('Hanya file Excel (.xlsx atau .xls) yang didukung');
                  }
                }
              }}
            >
              <FileSpreadsheet className="mb-3 h-12 w-12 text-primary" />
              <p className="text-base font-medium">Pilih atau drag file Excel ke sini</p>
              <p className="mt-1 text-sm text-muted-foreground">Format .xlsx atau .xls • NISN wajib ada sebagai kolom</p>
              <input ref={fileRef} type="file" accept=".xlsx,.xls" onChange={onFileChange} className="hidden" />
              <Button className="mt-4 gap-2" onClick={() => fileRef.current?.click()}>
                <UploadCloud className="h-4 w-4" /> Pilih File Excel
              </Button>
            </div>

            {fileName && (
              <div className="mt-4 flex items-center justify-between rounded-lg border p-3">
                <div className="flex items-center gap-2">
                  <FileUp className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-medium">{fileName}</p>
                    <p className="text-xs text-muted-foreground">{parsedRows.length} baris terbaca</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                    Mode: {mode === 'saldo_awal' ? 'Saldo Awal' : 'Riwayat Transaksi'}
                  </span>
                  <Button variant="ghost" size="sm" onClick={handleReset}>Hapus</Button>
                </div>
              </div>
            )}

            {parsedRows.length > 0 && !importResult && (
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => setMode(mode === 'transaksi' ? 'saldo_awal' : 'transaksi')}>
                    Ganti Mode: {mode === 'saldo_awal' ? 'Saldo Awal' : 'Riwayat Transaksi'}
                  </Button>
                </div>
                <Button onClick={handlePreview} className="gap-2">
                  <FileSpreadsheet className="h-4 w-4" /> Preview Data
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Preview table */}
        {preview.length > 0 && (
          <>
            {/* Summary stats */}
            <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
              <Card className="border-primary/20"><CardContent className="p-4">
                <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-primary" /><p className="text-xs text-muted-foreground">Siap Import</p></div>
                <p className="mt-1 text-2xl font-bold text-primary">{okCount}</p>
              </CardContent></Card>
              <Card className="border-amber-200"><CardContent className="p-4">
                <div className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-amber-600" /><p className="text-xs text-muted-foreground">Duplikat</p></div>
                <p className="mt-1 text-2xl font-bold text-amber-600">{dupCount}</p>
              </CardContent></Card>
              <Card className="border-destructive/20"><CardContent className="p-4">
                <div className="flex items-center gap-2"><XCircle className="h-4 w-4 text-destructive" /><p className="text-xs text-muted-foreground">NISN Tidak Ditemukan</p></div>
                <p className="mt-1 text-2xl font-bold text-destructive">{notFoundCount}</p>
              </CardContent></Card>
              <Card><CardContent className="p-4">
                <div className="flex items-center gap-2"><XCircle className="h-4 w-4 text-muted-foreground" /><p className="text-xs text-muted-foreground">Nominal Nol</p></div>
                <p className="mt-1 text-2xl font-bold text-muted-foreground">{zeroCount}</p>
              </CardContent></Card>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                      <tr>
                        <th className="px-3 py-3 font-medium">Status</th>
                        <th className="px-3 py-3 font-medium">Tanggal</th>
                        <th className="px-3 py-3 font-medium">NISN</th>
                        <th className="px-3 py-3 font-medium">Nama</th>
                        <th className="px-3 py-3 font-medium">Kelas</th>
                        <th className="px-3 py-3 font-medium text-primary">{mode === 'saldo_awal' ? 'Saldo Awal' : 'Setoran'}</th>
                        {mode === 'transaksi' && <th className="px-3 py-3 font-medium text-destructive">Penarikan</th>}
                        <th className="px-3 py-3 font-medium">Keterangan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {preview.slice(0, 200).map((r, i) => (
                        <tr key={i} className={`hover:bg-muted/30 ${
                          r.status === 'ok' ? '' :
                          r.status === 'duplikat' ? 'bg-amber-50/50 dark:bg-amber-950/10' :
                          r.status === 'nisn_tidak_ditemukan' ? 'bg-destructive/5' :
                          'bg-muted/20'
                        }`}>
                          <td className="px-3 py-2">
                            {r.status === 'ok' && <span className="inline-flex items-center gap-1 text-xs font-medium text-primary"><CheckCircle2 className="h-3.5 w-3.5" /> Siap</span>}
                            {r.status === 'duplikat' && <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600"><AlertTriangle className="h-3.5 w-3.5" /> Duplikat</span>}
                            {r.status === 'nisn_tidak_ditemukan' && <span className="inline-flex items-center gap-1 text-xs font-medium text-destructive"><XCircle className="h-3.5 w-3.5" /> NISN tidak ada</span>}
                            {r.status === 'nominal_nol' && <span className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground"><XCircle className="h-3.5 w-3.5" /> Nol</span>}
                          </td>
                          <td className="px-3 py-2 text-xs">{formatTanggalSingkat(r.tanggal)}</td>
                          <td className="px-3 py-2 text-xs text-muted-foreground">{r.nisn}</td>
                          <td className="px-3 py-2 font-medium">{r.nama || '-'}</td>
                          <td className="px-3 py-2 text-xs">{r.kelas || '-'}</td>
                          <td className="px-3 py-2 font-medium text-primary">
                            {formatRupiah(mode === 'saldo_awal' ? (r.saldo || r.setoran) : r.setoran)}
                          </td>
                          {mode === 'transaksi' && (
                            <td className="px-3 py-2 font-medium text-destructive">{formatRupiah(r.penarikan)}</td>
                          )}
                          <td className="px-3 py-2 text-xs text-muted-foreground">{r.keterangan || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {preview.length > 200 && (
                  <p className="border-t p-3 text-center text-xs text-muted-foreground">
                    Menampilkan 200 dari {preview.length} baris
                  </p>
                )}
                <div className="flex flex-col gap-3 border-t p-4 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-sm text-muted-foreground">
                    {okCount > 0 ? (
                      <>{okCount} transaksi akan diimport • Total: <span className="font-semibold text-primary">{formatRupiah(preview.filter((r) => r.status === 'ok').reduce((s, r) => s + (mode === 'saldo_awal' ? (r.saldo || r.setoran) : r.setoran - r.penarikan), 0))}</span></>
                    ) : 'Tidak ada data siap untuk diimport'}
                  </p>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={handleReset} className="gap-2"><ArrowLeft className="h-4 w-4" /> Batal</Button>
                    <Button onClick={handleImport} disabled={importing || okCount === 0} className="gap-2">
                      <FileUp className="h-4 w-4" /> {importing ? 'Mengimport...' : `Import ${okCount} Data`}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {parsedRows.length === 0 && !importResult && (
          <Card>
            <CardContent className="p-6">
              <div className="mb-4">
                <h3 className="text-sm font-semibold">Format Kolom yang Didukung</h3>
                <p className="mt-1 text-xs text-muted-foreground">Sistem otomatis mengenali variasi nama kolom berikut:</p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  { label: 'Tanggal', aliases: 'tanggal, tgl, tanggal transaksi, date' },
                  { label: 'NISN (wajib)', aliases: 'nisn, nomor nisn, no nisn' },
                  { label: 'Nama Siswa', aliases: 'nama, nama siswa, nama lengkap' },
                  { label: 'Kelas', aliases: 'kelas, nama kelas, class' },
                  { label: 'Setoran', aliases: 'setoran, setor, deposit, kredit' },
                  { label: 'Penarikan', aliases: 'penarikan, tarik, withdraw, debet' },
                  { label: 'Keterangan', aliases: 'keterangan, ket, note, deskripsi' },
                  { label: 'Saldo Awal', aliases: 'saldo, saldo awal, balance' },
                ].map((col) => (
                  <div key={col.label} className="rounded-lg border p-3">
                    <p className="text-sm font-medium">{col.label}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{col.aliases}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 rounded-lg bg-primary/5 p-4">
                <p className="text-sm text-muted-foreground">
                  <span className="font-semibold text-primary">NISN</span> digunakan untuk mencocokkan data Excel dengan siswa yang sudah terdaftar di database.
                  Jika NISN tidak ditemukan, baris tersebut tidak akan diimport. Pastikan siswa sudah terdaftar di menu Siswa sebelum import.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}
