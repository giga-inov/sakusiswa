import { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { usePengaturan, useTahunList } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { queryClient } from '@/lib/queryClient';
import { toast } from 'sonner';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/Loaders';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Save, Settings, School, DatabaseBackup, History, FileSpreadsheet,
  ChevronRight, Upload, Trash2, Eye, X, Mail, Lock, Loader2, ImageIcon,
} from 'lucide-react';
import { BRAND, LOGO_BUCKET, LOGO_PATH, getLogoUrl, bumpLogoVersion } from '@/lib/brand';

export function PengaturanPage() {
  const { data: pengaturan, isLoading, refetch } = usePengaturan();
  const { data: tahunList } = useTahunList();
  const { logAktivitas, user, profile, refreshProfile } = useAuth();

  const [form, setForm] = useState({
    nama_sekolah: '', npsn: '', alamat: '', kecamatan: '', kabupaten_kota: '',
    provinsi: '', email_sekolah: '', no_telepon: '', nama_kepala_sekolah: '',
    nama_bendahara: '', tahun_aktif_id: '', slogan: '', logo_url: '',
    app_name: '', app_subtitle: '', app_tagline: '',
  });
  const [saving, setSaving] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);

  // Logo upload state
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [logoUploading, setLogoUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Admin account state
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminConfirm, setAdminConfirm] = useState('');
  const [emailSaving, setEmailSaving] = useState(false);
  const [passwordSaving, setPasswordSaving] = useState(false);

  useEffect(() => {
    if (pengaturan) {
      setForm({
        nama_sekolah: pengaturan.nama_sekolah || '',
        npsn: pengaturan.npsn || '',
        alamat: pengaturan.alamat || '',
        kecamatan: pengaturan.kecamatan || '',
        kabupaten_kota: pengaturan.kabupaten_kota || '',
        provinsi: pengaturan.provinsi || '',
        email_sekolah: pengaturan.email_sekolah || '',
        no_telepon: pengaturan.no_telepon || '',
        nama_kepala_sekolah: pengaturan.nama_kepala_sekolah || '',
        nama_bendahara: pengaturan.nama_bendahara || '',
        tahun_aktif_id: pengaturan.tahun_aktif_id || '',
        slogan: pengaturan.slogan || '',
        logo_url: pengaturan.logo_url || '',
        app_name: pengaturan.app_name || BRAND.appName,
        app_subtitle: pengaturan.app_subtitle || BRAND.subtitle,
        app_tagline: pengaturan.app_tagline || BRAND.tagline,
      });
      setAdminEmail(user?.email || '');
    }
  }, [pengaturan, user]);

  const handleLogoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/png', 'image/jpeg', 'image/jpg'].includes(file.type)) {
      toast.error('Format logo harus PNG, JPG, atau JPEG.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Ukuran logo maksimal 2MB.');
      return;
    }

    // Show local preview immediately
    const reader = new FileReader();
    reader.onload = () => setLogoPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleLogoUpload = async () => {
    const file = fileInputRef.current?.files?.[0];
    if (!file) {
      toast.error('Pilih file logo terlebih dahulu.');
      return;
    }
    setLogoUploading(true);
    try {
      const { error: upErr } = await supabase.storage
        .from(LOGO_BUCKET)
        .upload(LOGO_PATH, file, { upsert: true, contentType: file.type });
      if (upErr) throw upErr;

      bumpLogoVersion();
      // Mark logo_url as non-empty so the app knows to show the logo
      const { error: dbErr } = await supabase
        .from('pengaturan')
        .update({ logo_url: LOGO_PATH, updated_at: new Date().toISOString() })
        .eq('id', 1);
      if (dbErr) throw dbErr;

      await logAktivitas('Edit', 'Pengaturan', 'Upload logo sekolah');
      toast.success('Logo sekolah berhasil diunggah.');
      setLogoPreview(null);
      refetch();
      queryClient.invalidateQueries({ queryKey: ['pengaturan'] });
    } catch (err: any) {
      toast.error(err.message || 'Gagal mengunggah logo.');
    }
    setLogoUploading(false);
  };

  const handleLogoRemove = async () => {
    setLogoUploading(true);
    try {
      await supabase.storage.from(LOGO_BUCKET).remove([LOGO_PATH]);
      const { error: dbErr } = await supabase
        .from('pengaturan')
        .update({ logo_url: null, updated_at: new Date().toISOString() })
        .eq('id', 1);
      if (dbErr) throw dbErr;

      await logAktivitas('Edit', 'Pengaturan', 'Hapus logo sekolah');
      toast.success('Logo sekolah dihapus.');
      setLogoPreview(null);
      refetch();
      queryClient.invalidateQueries({ queryKey: ['pengaturan'] });
    } catch (err: any) {
      toast.error(err.message || 'Gagal menghapus logo.');
    }
    setLogoUploading(false);
  };

  const handleReset = useCallback(() => {
    if (pengaturan) {
      setForm({
        nama_sekolah: pengaturan.nama_sekolah || '',
        npsn: pengaturan.npsn || '',
        alamat: pengaturan.alamat || '',
        kecamatan: pengaturan.kecamatan || '',
        kabupaten_kota: pengaturan.kabupaten_kota || '',
        provinsi: pengaturan.provinsi || '',
        email_sekolah: pengaturan.email_sekolah || '',
        no_telepon: pengaturan.no_telepon || '',
        nama_kepala_sekolah: pengaturan.nama_kepala_sekolah || '',
        nama_bendahara: pengaturan.nama_bendahara || '',
        tahun_aktif_id: pengaturan.tahun_aktif_id || '',
        slogan: pengaturan.slogan || '',
        logo_url: pengaturan.logo_url || '',
        app_name: pengaturan.app_name || BRAND.appName,
        app_subtitle: pengaturan.app_subtitle || BRAND.subtitle,
        app_tagline: pengaturan.app_tagline || BRAND.tagline,
      });
      setLogoPreview(null);
    }
  }, [pengaturan]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase.from('pengaturan').update({
        nama_sekolah: form.nama_sekolah,
        npsn: form.npsn || null,
        alamat: form.alamat,
        kecamatan: form.kecamatan || null,
        kabupaten_kota: form.kabupaten_kota || null,
        provinsi: form.provinsi || null,
        email_sekolah: form.email_sekolah || null,
        no_telepon: form.no_telepon || null,
        nama_kepala_sekolah: form.nama_kepala_sekolah || null,
        nama_bendahara: form.nama_bendahara || null,
        tahun_aktif_id: form.tahun_aktif_id || null,
        slogan: form.slogan,
        app_name: form.app_name || BRAND.appName,
        app_subtitle: form.app_subtitle || BRAND.subtitle,
        app_tagline: form.app_tagline || BRAND.tagline,
        updated_at: new Date().toISOString(),
      }).eq('id', 1);
      if (error) throw error;
      await logAktivitas('Edit', 'Pengaturan', 'Update identitas sekolah');
      toast.success('Pengaturan identitas sekolah berhasil disimpan.');
      refetch();
      queryClient.invalidateQueries({ queryKey: ['pengaturan'] });
    } catch (err: any) {
      toast.error(err.message || 'Gagal menyimpan pengaturan.');
    }
    setSaving(false);
  };

  // Admin email change
  const handleEmailChange = async () => {
    if (!adminEmail.trim()) return;
    if (adminEmail === user?.email) {
      toast.info('Email tidak berubah.');
      return;
    }
    setEmailSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({ email: adminEmail.trim() });
      if (error) throw error;
      await logAktivitas('Edit', 'Pengaturan', `Perubahan email admin ke ${adminEmail.trim()}`);
      toast.success('Permintaan perubahan email dikirim. Verifikasi email baru untuk menyelesaikan perubahan. Admin tetap bisa login dengan email lama sampai verifikasi selesai.');
      await refreshProfile();
    } catch (err: any) {
      toast.error(err.message || 'Gagal mengubah email.');
    }
    setEmailSaving(false);
  };

  // Admin password change
  const handlePasswordChange = async () => {
    if (!adminPassword) {
      toast.error('Password baru wajib diisi.');
      return;
    }
    if (adminPassword.length < 6) {
      toast.error('Password minimal 6 karakter.');
      return;
    }
    if (adminPassword !== adminConfirm) {
      toast.error('Konfirmasi password tidak cocok.');
      return;
    }
    setPasswordSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: adminPassword });
      if (error) throw error;
      await logAktivitas('Ganti Password', 'Pengaturan', 'Admin mengganti password login');
      toast.success('Password admin berhasil diubah.');
      setAdminPassword('');
      setAdminConfirm('');
    } catch (err: any) {
      toast.error(err.message || 'Gagal mengubah password.');
    }
    setPasswordSaving(false);
  };

  if (isLoading) return (
    <>
      <PageHeader title="Pengaturan" description="Konfigurasi aplikasi dan sekolah" />
      <div className="p-6"><Skeleton className="h-96 w-full" /></div>
    </>
  );

  const adminTools = [
    { label: 'Backup & Restore Database', path: '/admin/backup', icon: DatabaseBackup, desc: 'Cadangkan dan pulihkan data' },
    { label: 'Riwayat Aktivitas', path: '/admin/aktivitas', icon: History, desc: 'Log semua aktivitas pengguna' },
    { label: 'Import Data Excel', path: '/admin/import-excel', icon: FileSpreadsheet, desc: 'Import data siswa dari Excel' },
    { label: 'Tahun Pelajaran', path: '/admin/tahun-pelajaran', icon: School, desc: 'Kelola tahun pelajaran' },
  ];

  const hasLogo = !!form.logo_url;
  const displayLogo = logoPreview || (hasLogo ? getLogoUrl() : null);

  return (
    <>
      <PageHeader title="Pengaturan" description="Konfigurasi aplikasi dan identitas sekolah" />
      <div className="p-6 space-y-6">
        {/* Admin Tools */}
        <div className="grid gap-3 sm:grid-cols-2">
          {adminTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Link key={tool.path} to={tool.path}>
                <Card className="transition-all hover:shadow-md hover:border-primary/30">
                  <CardContent className="flex items-center gap-4 p-4">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary shrink-0">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{tool.label}</p>
                      <p className="text-xs text-muted-foreground">{tool.desc}</p>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        {/* Identitas Sekolah */}
        <div className="mx-auto max-w-3xl">
          <Card>
            <CardContent className="p-6">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary"><School className="h-6 w-6" /></div>
                <div><h3 className="font-semibold">Identitas Sekolah</h3><p className="text-sm text-muted-foreground">Data ini tampil otomatis di seluruh halaman aplikasi dan laporan</p></div>
              </div>
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Logo Upload */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Logo Sekolah</label>
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
                    <div className="flex h-28 w-28 shrink-0 items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-primary/30 bg-primary/5">
                      {displayLogo ? (
                        <img src={displayLogo} alt="Logo sekolah" className="h-full w-full object-contain p-2" />
                      ) : (
                        <div className="flex flex-col items-center gap-1 text-muted-foreground">
                          <ImageIcon className="h-8 w-8" />
                          <span className="text-[10px]">Belum ada logo</span>
                        </div>
                      )}
                    </div>
                    <div className="flex-1 space-y-2">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/png,image/jpeg,image/jpg"
                        onChange={handleLogoSelect}
                        className="hidden"
                      />
                      <div className="flex flex-wrap gap-2">
                        <Button type="button" variant="outline" size="sm" className="gap-2" onClick={() => fileInputRef.current?.click()}>
                          <Upload className="h-4 w-4" /> {hasLogo ? 'Ganti Logo' : 'Upload Logo'}
                        </Button>
                        {hasLogo && (
                          <Button type="button" variant="outline" size="sm" className="gap-2 text-destructive hover:text-destructive" onClick={handleLogoRemove} disabled={logoUploading}>
                            <Trash2 className="h-4 w-4" /> Hapus Logo
                          </Button>
                        )}
                        {logoPreview && (
                          <Button type="button" size="sm" className="gap-2" onClick={handleLogoUpload} disabled={logoUploading}>
                            {logoUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                            {logoUploading ? 'Mengunggah...' : 'Simpan Logo'}
                          </Button>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">Format: PNG, JPG, JPEG. Maksimal 2MB. Logo ditampilkan dengan rasio penuh (object-contain) agar tidak terpotong.</p>
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">Nama Sekolah</label>
                    <input value={form.nama_sekolah} onChange={(e) => setForm({ ...form, nama_sekolah: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">NPSN</label>
                    <input value={form.npsn} onChange={(e) => setForm({ ...form, npsn: e.target.value })} placeholder="Nomor Pokok Sekolah Nasional" className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium">Alamat Sekolah</label>
                  <textarea value={form.alamat} onChange={(e) => setForm({ ...form, alamat: e.target.value })} rows={2} className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="space-y-1.5"><label className="text-sm font-medium">Kecamatan</label><input value={form.kecamatan} onChange={(e) => setForm({ ...form, kecamatan: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Kabupaten/Kota</label><input value={form.kabupaten_kota} onChange={(e) => setForm({ ...form, kabupaten_kota: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Provinsi</label><input value={form.provinsi} onChange={(e) => setForm({ ...form, provinsi: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5"><label className="text-sm font-medium">Email Sekolah</label><input type="email" value={form.email_sekolah} onChange={(e) => setForm({ ...form, email_sekolah: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Nomor Telepon Sekolah</label><input value={form.no_telepon} onChange={(e) => setForm({ ...form, no_telepon: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5"><label className="text-sm font-medium">Nama Kepala Sekolah</label><input value={form.nama_kepala_sekolah} onChange={(e) => setForm({ ...form, nama_kepala_sekolah: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Nama Bendahara</label><input value={form.nama_bendahara} onChange={(e) => setForm({ ...form, nama_bendahara: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5"><label className="text-sm font-medium">Tahun Aktif</label><select value={form.tahun_aktif_id} onChange={(e) => setForm({ ...form, tahun_aktif_id: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="">Pilih Tahun</option>{tahunList?.map((t) => <option key={t.id} value={t.id}>{t.nama}</option>)}</select></div>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Slogan / Tagline Sekolah</label><input value={form.slogan} onChange={(e) => setForm({ ...form, slogan: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                </div>

                {/* App identity (optional override) */}
                <div className="rounded-lg border border-primary/20 bg-primary/5 p-4 space-y-3">
                  <p className="text-sm font-semibold text-primary">Identitas Aplikasi</p>
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="space-y-1.5"><label className="text-xs font-medium">Nama Aplikasi</label><input value={form.app_name} onChange={(e) => setForm({ ...form, app_name: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                    <div className="space-y-1.5"><label className="text-xs font-medium">Subjudul</label><input value={form.app_subtitle} onChange={(e) => setForm({ ...form, app_subtitle: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                    <div className="space-y-1.5"><label className="text-xs font-medium">Tagline Aplikasi</label><input value={form.app_tagline} onChange={(e) => setForm({ ...form, app_tagline: e.target.value })} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                  </div>
                </div>

                <div className="flex flex-col gap-2 pt-2 sm:flex-row sm:justify-end">
                  <Button type="button" variant="outline" className="gap-2" onClick={() => setPreviewOpen(true)}>
                    <Eye className="h-4 w-4" /> Pratinjau Identitas
                  </Button>
                  <Button type="button" variant="outline" className="gap-2" onClick={handleReset}>
                    <X className="h-4 w-4" /> Batal
                  </Button>
                  <Button type="submit" disabled={saving} className="gap-2">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    {saving ? 'Menyimpan...' : 'Simpan Pengaturan'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Pengaturan Akun Administrator */}
        <div className="mx-auto max-w-3xl">
          <Card>
            <CardContent className="p-6">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary"><Settings className="h-6 w-6" /></div>
                <div><h3 className="font-semibold">Pengaturan Akun Administrator</h3><p className="text-sm text-muted-foreground">Ubah email dan password login administrator</p></div>
              </div>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-1.5"><Mail className="h-4 w-4 text-muted-foreground" /> Email Login</label>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} placeholder={user?.email || 'admin@email.com'} className="h-10 flex-1 rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                    <Button type="button" className="gap-2" onClick={handleEmailChange} disabled={emailSaving}>
                      {emailSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                      {emailSaving ? 'Memproses...' : 'Ubah Email'}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Perubahan email memerlukan verifikasi. Anda tetap bisa login dengan email lama sampai email baru diverifikasi.</p>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-1.5"><Lock className="h-4 w-4 text-muted-foreground" /> Password Baru</label>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <input type="password" value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)} placeholder="Password baru (min. 6 karakter)" className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                    <input type="password" value={adminConfirm} onChange={(e) => setAdminConfirm(e.target.value)} placeholder="Konfirmasi password" className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                  <div className="flex justify-end">
                    <Button type="button" className="gap-2" onClick={handlePasswordChange} disabled={passwordSaving}>
                      {passwordSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                      {passwordSaving ? 'Memproses...' : 'Ubah Password'}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Password disimpan secara aman melalui Supabase Authentication, tidak dalam teks biasa.</p>
                </div>
                <p className="text-xs text-muted-foreground">Akun aktif: <span className="font-medium text-foreground">{profile?.email}</span></p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Preview Modal */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Eye className="h-5 w-5 text-primary" /> Pratinjau Identitas Sekolah</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4 py-6 text-center">
            {displayLogo ? (
              <img src={displayLogo} alt="Logo sekolah" className="h-20 w-20 rounded-xl object-contain bg-primary/5 p-2 ring-1 ring-primary/20" />
            ) : (
              <div className="flex h-20 w-20 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg">
                <span className="text-2xl font-bold">S</span>
              </div>
            )}
            <div>
              <p className="text-lg font-bold text-primary">{form.nama_sekolah || 'Nama Sekolah belum diisi'}</p>
              <p className="text-sm font-semibold">{form.app_name || BRAND.appName}</p>
              <p className="text-xs text-muted-foreground">{form.app_subtitle || BRAND.subtitle}</p>
            </div>
            <p className="text-xs italic text-muted-foreground">"{form.app_tagline || form.slogan || BRAND.tagline}"</p>
            {form.alamat && <p className="text-xs text-muted-foreground">{form.alamat}</p>}
            <div className="text-xs text-muted-foreground space-y-0.5">
              {form.npsn && <p>NPSN: {form.npsn}</p>}
              {form.email_sekolah && <p>{form.email_sekolah}</p>}
              {form.no_telepon && <p>{form.no_telepon}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewOpen(false)}>Tutup</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
