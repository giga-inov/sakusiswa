import { useState } from 'react';
import { useTahunList, useSiswaList } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { TableSkeleton, EmptyState } from '@/components/Loaders';
import { Plus, CalendarDays, CheckCircle2, Trash2, ArrowUpCircle } from 'lucide-react';
import { TahunPelajaran } from '@/types';
import { formatTanggal } from '@/lib/format';

export function TahunPelajaranPage() {
  const { data: tahunList, isLoading, refetch } = useTahunList();
  const { data: siswaList } = useSiswaList();
  const { logAktivitas } = useAuth();
  const [open, setOpen] = useState(false);
  const [nama, setNama] = useState('');
  const [saving, setSaving] = useState(false);
  const [naikKelasTahun, setNaikKelasTahun] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim()) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('tahun_pelajaran').insert({ nama: nama.trim(), aktif: false });
      if (error) throw error;
      await logAktivitas('Tambah', 'Tahun Pelajaran', `Tambah tahun: ${nama}`);
      toast.success('Tahun pelajaran ditambahkan');
      setOpen(false);
      setNama('');
      refetch();
    } catch (err: any) {
      toast.error(err.message);
    }
    setSaving(false);
  };

  const setAktif = async (id: string) => {
    try {
      await supabase.from('tahun_pelajaran').update({ aktif: false }).neq('id', id);
      const { error } = await supabase.from('tahun_pelajaran').update({ aktif: true }).eq('id', id);
      if (error) throw error;
      await supabase.from('pengaturan').update({ tahun_aktif_id: id }).eq('id', 1);
      await logAktivitas('Edit', 'Tahun Pelajaran', 'Mengaktifkan tahun pelajaran');
      toast.success('Tahun pelajaran diaktifkan');
      refetch();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleNaikKelas = async () => {
    if (!naikKelasTahun) return;
    try {
      const { error } = await supabase.rpc('naik_kelas', { p_tahun_baru: naikKelasTahun });
      if (error) throw error;
      await logAktivitas('Kenaikan Kelas', 'Siswa', 'Naik kelas semua siswa');
      toast.success('Kenaikan kelas berhasil dilakukan');
      setNaikKelasTahun(null);
      refetch();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const t = tahunList?.find((x) => x.id === deleteId);
    const { error } = await supabase.from('tahun_pelajaran').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    await logAktivitas('Hapus', 'Tahun Pelajaran', `Hapus tahun: ${t?.nama}`);
    toast.success('Tahun pelajaran dihapus');
    setDeleteId(null);
    refetch();
  };

  return (
    <>
      <PageHeader
        title="Tahun Pelajaran"
        description="Kelola tahun ajaran dan kenaikan kelas"
        action={<Button onClick={() => setOpen(true)} className="gap-2"><Plus className="h-4 w-4" /> Tambah Tahun</Button>}
      />

      <div className="p-6 space-y-6">
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="flex items-center justify-between p-5">
            <div>
              <h3 className="flex items-center gap-2 font-semibold"><ArrowUpCircle className="h-5 w-5 text-primary" /> Kenaikan Kelas Otomatis</h3>
              <p className="mt-1 text-sm text-muted-foreground">Naikkan seluruh siswa sekaligus ke kelas berikutnya. Kelas 6 akan menjadi alumni.</p>
              <p className="mt-1 text-xs text-muted-foreground">Siswa aktif saat ini: {siswaList?.length || 0}</p>
            </div>
            <Button onClick={() => {
              const nonAktif = tahunList?.find((t) => !t.aktif);
              if (nonAktif) setNaikKelasTahun(nonAktif.id);
              else toast.error('Buat tahun pelajaran baru terlebih dahulu');
            }} className="gap-2"><ArrowUpCircle className="h-4 w-4" /> Naik Kelas</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            {isLoading ? <div className="p-4"><TableSkeleton rows={3} /></div> : (tahunList || []).length === 0 ? (
              <EmptyState icon={<CalendarDays className="h-6 w-6" />} title="Belum ada tahun pelajaran" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                    <tr><th className="px-4 py-3 font-medium">Tahun Pelajaran</th><th className="px-4 py-3 font-medium">Status</th><th className="px-4 py-3 font-medium">Dibuat</th><th className="px-4 py-3 text-right font-medium">Aksi</th></tr>
                  </thead>
                  <tbody className="divide-y">
                    {tahunList?.map((t) => (
                      <tr key={t.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 font-medium">{t.nama}</td>
                        <td className="px-4 py-3">
                          {t.aktif ? <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary"><CheckCircle2 className="h-3 w-3" /> Aktif</span> : <span className="text-xs text-muted-foreground">Nonaktif</span>}
                        </td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{formatTanggal(t.created_at)}</td>
                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-2">
                            {!t.aktif && <Button variant="outline" size="sm" onClick={() => setAktif(t.id)}>Aktifkan</Button>}
                            {!t.aktif && <Button variant="ghost" size="icon" onClick={() => setDeleteId(t.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Tambah Tahun Pelajaran</DialogTitle></DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Nama Tahun Pelajaran</label>
              <input value={nama} onChange={(e) => setNama(e.target.value)} placeholder="Contoh: 2026/2027" className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <DialogFooter><Button type="button" variant="outline" onClick={() => setOpen(false)}>Batal</Button><Button type="submit" disabled={saving}>{saving ? 'Menyimpan...' : 'Simpan'}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!naikKelasTahun} onOpenChange={(v) => !v && setNaikKelasTahun(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Konfirmasi Kenaikan Kelas?</AlertDialogTitle>
            <AlertDialogDescription>
              Semua siswa akan naik ke kelas berikutnya. Siswa kelas 6 akan menjadi alumni dan tidak dapat melakukan transaksi lagi. Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={handleNaikKelas} className="bg-primary text-primary-foreground hover:bg-primary/90">Ya, Naik Kelas</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Hapus Tahun Pelajaran?</AlertDialogTitle><AlertDialogDescription>Tindakan ini tidak dapat dibatalkan.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Batal</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Hapus</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
