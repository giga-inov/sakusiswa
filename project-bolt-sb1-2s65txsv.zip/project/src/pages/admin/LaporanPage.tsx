import { useState } from 'react';
import { useSiswaList, useKelasList, usePengaturan } from '@/hooks/queries';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { PageHeader } from '@/components/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EmptyState } from '@/components/Loaders';
import { FileBarChart, Download, FileText, Printer } from 'lucide-react';
import { formatRupiah, formatTanggalSingkat } from '@/lib/format';
import { BRAND, getLogoUrl } from '@/lib/brand';

type Period = 'hari' | 'rentang' | 'bulan' | 'tahun' | 'kelas' | 'siswa';
type JenisFilter = 'semua' | 'setoran' | 'penarikan';

export function LaporanPage() {
  const { data: kelasList } = useKelasList();
  const { data: siswaList } = useSiswaList();
  const { data: pengaturan } = usePengaturan();
  const { logAktivitas } = useAuth();
  const [period, setPeriod] = useState<Period>('hari');
  const [tanggal, setTanggal] = useState(new Date().toISOString().split('T')[0]);
  const [tanggalMulai, setTanggalMulai] = useState(new Date().toISOString().split('T')[0]);
  const [tanggalAkhir, setTanggalAkhir] = useState(new Date().toISOString().split('T')[0]);
  const [bulan, setBulan] = useState(new Date().toISOString().slice(0, 7));
  const [tahun, setTahun] = useState(String(new Date().getFullYear()));
  const [kelasId, setKelasId] = useState('');
  const [siswaId, setSiswaId] = useState('');
  const [jenisFilter, setJenisFilter] = useState<JenisFilter>('semua');
  const [result, setResult] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);

  const applyJenisFilter = (data: any[]) => {
    if (jenisFilter === 'semua') return data;
    return data.filter((t) => t.jenis === jenisFilter);
  };

  const generateReport = async () => {
    setLoading(true);
    try {
      let q = supabase.from('transaksi').select('*, siswa(*, kelas(*))').eq('status', 'aktif').order('tanggal', { ascending: false });
      if (period === 'hari') q = q.eq('tanggal', tanggal);
      else if (period === 'rentang') q = q.gte('tanggal', tanggalMulai).lte('tanggal', tanggalAkhir);
      else if (period === 'bulan') q = q.gte('tanggal', `${bulan}-01`).lte('tanggal', `${bulan}-31`);
      else if (period === 'tahun') q = q.gte('tanggal', `${tahun}-01-01`).lte('tanggal', `${tahun}-12-31`);
      else if (period === 'kelas') {
        const { data } = await q.limit(10000);
        const filtered = applyJenisFilter((data || []).filter((t: any) => t.siswa?.kelas_id === kelasId));
        setResult(filtered);
        setLoading(false);
        await logAktivitas('Laporan', 'Laporan', `Laporan per kelas`);
        return;
      } else if (period === 'siswa') {
        q = q.eq('siswa_id', siswaId);
      }
      const { data, error } = await q.limit(10000);
      if (error) throw error;
      setResult(applyJenisFilter(data || []));
      await logAktivitas('Laporan', 'Laporan', `Laporan ${period}`);
    } catch (err: any) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  const exportCSV = () => {
    if (!result || result.length === 0) return;
    const headers = ['Tanggal', 'Siswa', 'Kelas', 'Jenis', 'Nominal', 'Saldo Setelah', 'Petugas', 'Keterangan'];
    const rows = result.map((t) => [
      formatTanggalSingkat(t.tanggal), t.siswa?.nama || '', t.siswa?.kelas?.nama || '',
      t.jenis, t.nominal, t.saldo_setelah || '', t.petugas_nama || '', t.keterangan || '',
    ]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `laporan-sakusiswa-${period}-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('File Excel/CSV berhasil diunduh');
    logAktivitas('Export', 'Laporan', 'Export CSV laporan');
  };

  const printReport = () => {
    window.print();
    logAktivitas('Export', 'Laporan', 'Cetak PDF laporan');
  };

  const totalSetoran = (result || []).filter((t: any) => t.jenis === 'setoran').reduce((s: number, t: any) => s + Number(t.nominal), 0);
  const totalPenarikan = (result || []).filter((t: any) => t.jenis === 'penarikan').reduce((s: number, t: any) => s + Number(t.nominal), 0);
  const totalSaldo = totalSetoran - totalPenarikan;

  return (
    <>
      <PageHeader title="Laporan" description="Cetak dan export laporan transaksi" />

      <div className="p-6 space-y-4">
        <Card>
          <CardContent className="p-5">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Jenis Laporan</label>
                <select value={period} onChange={(e) => { setPeriod(e.target.value as Period); setResult(null); }} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                  <option value="hari">Per Hari</option>
                  <option value="rentang">Rentang Tanggal</option>
                  <option value="bulan">Per Bulan</option>
                  <option value="tahun">Per Tahun</option>
                  <option value="kelas">Per Kelas</option>
                  <option value="siswa">Per Siswa</option>
                </select>
              </div>
              {period === 'hari' && <div className="space-y-1.5"><label className="text-sm font-medium">Tanggal</label><input type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>}
              {period === 'rentang' && (
                <>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Tanggal Mulai</label><input type="date" value={tanggalMulai} onChange={(e) => setTanggalMulai(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                  <div className="space-y-1.5"><label className="text-sm font-medium">Tanggal Akhir</label><input type="date" value={tanggalAkhir} onChange={(e) => setTanggalAkhir(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>
                </>
              )}
              {period === 'bulan' && <div className="space-y-1.5"><label className="text-sm font-medium">Bulan</label><input type="month" value={bulan} onChange={(e) => setBulan(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>}
              {period === 'tahun' && <div className="space-y-1.5"><label className="text-sm font-medium">Tahun</label><input type="number" value={tahun} onChange={(e) => setTahun(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" /></div>}
              {period === 'kelas' && <div className="space-y-1.5"><label className="text-sm font-medium">Kelas</label><select value={kelasId} onChange={(e) => setKelasId(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="">Pilih Kelas</option>{kelasList?.map((k) => <option key={k.id} value={k.id}>{k.nama}</option>)}</select></div>}
              {period === 'siswa' && <div className="space-y-1.5"><label className="text-sm font-medium">Siswa</label><select value={siswaId} onChange={(e) => setSiswaId(e.target.value)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"><option value="">Pilih Siswa</option>{siswaList?.map((s) => <option key={s.id} value={s.id}>{s.nama} - {s.kelas?.nama}</option>)}</select></div>}
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Filter Jenis</label>
                <select value={jenisFilter} onChange={(e) => setJenisFilter(e.target.value as JenisFilter)} className="h-10 w-full rounded-lg border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30">
                  <option value="semua">Semua</option>
                  <option value="setoran">Setoran</option>
                  <option value="penarikan">Penarikan</option>
                </select>
              </div>
              <div className="flex items-end gap-2">
                <Button onClick={generateReport} disabled={loading} className="gap-2"><FileBarChart className="h-4 w-4" /> {loading ? 'Memuat...' : 'Buat Laporan'}</Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {result !== null && (
          <Card>
            <CardContent className="p-0">
              <div className="flex flex-col gap-3 border-b p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="font-semibold">Hasil Laporan</h3>
                  <p className="text-sm text-muted-foreground">
                    {result.length} transaksi • Setoran: {formatRupiah(totalSetoran)} • Penarikan: {formatRupiah(totalPenarikan)} • Saldo: {formatRupiah(totalSaldo)}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-1" onClick={exportCSV} disabled={result.length === 0}><Download className="h-4 w-4" /> Excel</Button>
                  <Button variant="outline" size="sm" className="gap-1" onClick={printReport} disabled={result.length === 0}><Printer className="h-4 w-4" /> PDF</Button>
                </div>
              </div>
              {result.length === 0 ? (
                <EmptyState icon={<FileText className="h-6 w-6" />} title="Tidak ada data" description="Tidak ada transaksi pada periode ini." />
              ) : (
                <div className="overflow-x-auto">
                  <div className="print-header mb-4 hidden text-center print:block">
                    {pengaturan?.logo_url && <img src={getLogoUrl()} alt="Logo" className="mx-auto mb-2 h-16 w-16 object-contain" />}
                    <p className="text-lg font-bold">{pengaturan?.nama_sekolah || BRAND.appName}</p>
                    <p className="text-sm text-muted-foreground">{pengaturan?.app_name || BRAND.appName} — {pengaturan?.app_subtitle || BRAND.subtitle}</p>
                    <p className="text-xs italic text-muted-foreground">"{pengaturan?.app_tagline || pengaturan?.slogan || BRAND.tagline}"</p>
                    {pengaturan?.alamat && <p className="text-xs text-muted-foreground">{pengaturan.alamat}</p>}
                    <hr className="mx-auto my-3 w-1/2" />
                  </div>
                  <table className="w-full text-sm print-table">
                    <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                      <tr><th className="px-4 py-3 font-medium">Tanggal</th><th className="px-4 py-3 font-medium">Siswa</th><th className="px-4 py-3 font-medium">Kelas</th><th className="px-4 py-3 font-medium">Jenis</th><th className="px-4 py-3 font-medium">Nominal</th><th className="px-4 py-3 font-medium">Saldo</th><th className="px-4 py-3 font-medium">Keterangan</th></tr>
                    </thead>
                    <tbody className="divide-y">
                      {result.map((t: any) => (
                        <tr key={t.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3 text-xs">{formatTanggalSingkat(t.tanggal)}</td>
                          <td className="px-4 py-3 font-medium">{t.siswa?.nama}</td>
                          <td className="px-4 py-3">{t.siswa?.kelas?.nama}</td>
                          <td className="px-4 py-3"><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${t.jenis === 'setoran' ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>{t.jenis}</span></td>
                          <td className={`px-4 py-3 font-semibold ${t.jenis === 'setoran' ? 'text-primary' : 'text-destructive'}`}>{t.jenis === 'setoran' ? '+' : '-'}{formatRupiah(t.nominal)}</td>
                          <td className="px-4 py-3 text-xs font-medium">{formatRupiah(t.saldo_setelah || 0)}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{t.keterangan || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <style>{`@media print { body * { visibility: hidden; } .print-header, .print-header *, .print-table, .print-table * { visibility: visible; } .print-header { position: absolute; left: 0; top: 0; width: 100%; } .print-table { position: absolute; left: 0; top: 140px; width: 100%; } }`}</style>
    </>
  );
}
