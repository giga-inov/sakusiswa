import { useEffect, useState, type ReactNode } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { queryClient } from '@/lib/queryClient';
import { AuthProvider, useAuth, getDashboardPath } from '@/context/AuthContext';
import { ThemeProvider } from '@/context/ThemeContext';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { AppLayout } from '@/components/AppLayout';

import { LoginPage, ForgotPasswordPage, ResetPasswordPage } from '@/pages/auth/LoginPage';
import { SetupWizardPage } from '@/pages/auth/SetupWizardPage';
import { supabase } from '@/lib/supabase';
import { ChangePasswordPage } from '@/pages/auth/ChangePasswordPage';
import { CekTabunganPage } from '@/pages/public/CekTabunganPage';

import { AdminDashboard } from '@/pages/admin/AdminDashboard';
import { GuruPage } from '@/pages/admin/GuruPage';
import { SiswaPage } from '@/pages/admin/SiswaPage';
import { KelasPage } from '@/pages/admin/KelasPage';
import { TahunPelajaranPage } from '@/pages/admin/TahunPelajaranPage';
import { LaporanPage } from '@/pages/admin/LaporanPage';
import { BackupPage, AktivitasPage } from '@/pages/admin/BackupAktivitas';
import { PengaturanPage } from '@/pages/admin/PengaturanPage';

import { GuruDashboard, GuruSiswaPage } from '@/pages/guru/GuruDashboard';
import { GuruTabunganPage } from '@/pages/guru/GuruTabunganPage';
import { InputTabunganAdminPage, TransaksiAdminPage } from '@/pages/admin/InputTabunganAdminPage';
import { ImportExcelPage } from '@/pages/admin/ImportExcelPage';
import { GuruKelasPage } from '@/pages/admin/GuruKelasPage';
import { GuruTransaksiPage } from '@/pages/guru/GuruTransaksiPage';
import { GuruLaporanPage } from '@/pages/guru/GuruLaporanPage';

import { SiswaDashboard, SiswaTransaksiPage } from '@/pages/siswa/SiswaDashboard';
import { ProfilPage } from '@/pages/ProfilPage';

function SetupGate({ children }: { children: ReactNode }) {
  const [setupComplete, setSetupComplete] = useState<boolean | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    supabase.rpc('get_setup_status').then(({ data, error: statusError }) => {
      if (statusError || typeof data !== 'boolean') {
        setError(true);
        return;
      }
      setSetupComplete(data);
    });
  }, []);

  if (error) return <div className="flex min-h-screen items-center justify-center p-6 text-center"><div><h1 className="text-xl font-semibold">Aplikasi belum dapat terhubung</h1><p className="mt-2 text-sm text-muted-foreground">Periksa koneksi database lalu muat ulang halaman ini.</p></div></div>;
  if (setupComplete === null) return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  if (!setupComplete) return <SetupWizardPage onComplete={() => setSetupComplete(true)} />;
  return <>{children}</>;
}

function RootRedirect() {
  const { session, profile, loading } = useAuth();
  if (loading) return null;
  if (!session) return <Navigate to="/login" replace />;
  return <Navigate to={getDashboardPath(profile?.role || 'admin')} replace />;
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <QueryClientProvider client={queryClient}>
          <AuthProvider>
            <BrowserRouter>
              <Toaster position="top-right" richColors closeButton />
              <SetupGate>
                <Routes>
                  <Route path="/" element={<RootRedirect />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/cek-tabungan" element={<CekTabunganPage />} />
                <Route path="/lupa-password" element={<ForgotPasswordPage />} />
                <Route path="/reset-password" element={<ResetPasswordPage />} />

                <Route path="/first-login" element={
                  <ProtectedRoute>
                    <ChangePasswordPage />
                  </ProtectedRoute>
                } />
                <Route path="/ganti-password" element={
                  <ProtectedRoute>
                    <ChangePasswordPage />
                  </ProtectedRoute>
                } />

                <Route element={
                  <ProtectedRoute>
                    <AppLayout />
                  </ProtectedRoute>
                }>
                  {/* Admin */}
                  <Route path="/admin/dashboard" element={<ProtectedRoute roles={['admin']}><AdminDashboard /></ProtectedRoute>} />
                  <Route path="/admin/guru" element={<ProtectedRoute roles={['admin']}><GuruPage /></ProtectedRoute>} />
                  <Route path="/admin/guru-kelas" element={<ProtectedRoute roles={['admin']}><GuruKelasPage /></ProtectedRoute>} />
                  <Route path="/admin/siswa" element={<ProtectedRoute roles={['admin']}><SiswaPage /></ProtectedRoute>} />
                  <Route path="/admin/kelas" element={<ProtectedRoute roles={['admin']}><KelasPage /></ProtectedRoute>} />
                  <Route path="/admin/tahun-pelajaran" element={<ProtectedRoute roles={['admin']}><TahunPelajaranPage /></ProtectedRoute>} />
                  <Route path="/admin/laporan" element={<ProtectedRoute roles={['admin']}><LaporanPage /></ProtectedRoute>} />
                  <Route path="/admin/backup" element={<ProtectedRoute roles={['admin']}><BackupPage /></ProtectedRoute>} />
                  <Route path="/admin/aktivitas" element={<ProtectedRoute roles={['admin']}><AktivitasPage /></ProtectedRoute>} />
                  <Route path="/admin/pengaturan" element={<ProtectedRoute roles={['admin']}><PengaturanPage /></ProtectedRoute>} />
                  <Route path="/admin/input-tabungan" element={<ProtectedRoute roles={['admin']}><InputTabunganAdminPage /></ProtectedRoute>} />
                  <Route path="/admin/transaksi" element={<ProtectedRoute roles={['admin']}><TransaksiAdminPage /></ProtectedRoute>} />
                  <Route path="/admin/import-excel" element={<ProtectedRoute roles={['admin']}><ImportExcelPage /></ProtectedRoute>} />

                  {/* Guru */}
                  <Route path="/guru/dashboard" element={<ProtectedRoute roles={['guru']}><GuruDashboard /></ProtectedRoute>} />
                  <Route path="/guru/siswa" element={<ProtectedRoute roles={['guru']}><GuruSiswaPage /></ProtectedRoute>} />
                  <Route path="/guru/tabungan" element={<ProtectedRoute roles={['guru']}><GuruTabunganPage /></ProtectedRoute>} />
                  <Route path="/guru/transaksi" element={<ProtectedRoute roles={['guru']}><GuruTransaksiPage /></ProtectedRoute>} />
                  <Route path="/guru/laporan" element={<ProtectedRoute roles={['guru']}><GuruLaporanPage /></ProtectedRoute>} />
                  <Route path="/guru/profil" element={<ProtectedRoute roles={['guru']}><ProfilPage /></ProtectedRoute>} />

                  {/* Siswa */}
                  <Route path="/siswa/dashboard" element={<ProtectedRoute roles={['siswa']}><SiswaDashboard /></ProtectedRoute>} />
                  <Route path="/siswa/saldo" element={<ProtectedRoute roles={['siswa']}><SiswaDashboard /></ProtectedRoute>} />
                  <Route path="/siswa/transaksi" element={<ProtectedRoute roles={['siswa']}><SiswaTransaksiPage /></ProtectedRoute>} />
                  <Route path="/siswa/profil" element={<ProtectedRoute roles={['siswa']}><ProfilPage /></ProtectedRoute>} />
                </Route>

                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </SetupGate>
            </BrowserRouter>
          </AuthProvider>
        </QueryClientProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
