export const BRAND = {
  appName: 'SAKU SISWA',
  subtitle: 'Sistem Tabungan Digital Siswa',
  tagline: 'Menabung Mudah, Terpantau dan Terpercaya.',
} as const;

export const LOGO_BUCKET = 'logo-sekolah';
export const LOGO_PATH = 'logo.png';

export function getLogoUrl(): string {
  const url = import.meta.env.VITE_SUPABASE_URL;
  return `${url}/storage/v1/object/public/${LOGO_BUCKET}/${LOGO_PATH}?t=${(pengaturanCacheVersion())}`;
}

let cacheVersion = 0;
export function bumpLogoVersion() {
  cacheVersion += 1;
}
function pengaturanCacheVersion() {
  return cacheVersion;
}
